> ![](media/image1.png){width="3.150054680664917in" height="1.5104166666666667in"}

FICHES MÉTHODOLOGIQUES DE RÉDACTION DU JUGEMENT CIVIL

> **Septembre 2019**
>
> **AVERTISSEMENT**
>
> Ce document est le fruit d\'une réflexion engagée dans le cadre d\'un groupe de travail constitué en octobre 2012, présidé par Madame ARENS, présidente du tribunal de grande instance de Paris, et par ailleurs composé de Madame Bourgeois de Ryck, vice-présidente et chargée de mission au tribunal de grande instance de Paris, Madame Farthouat, première vice-présidente au tribunal de grande instance de Paris, Monsieur Alain Lacour, conseiller à la cour d\'appel de Grenoble et magistrat enseignant associé à l\'ENM, Mesdames Nicole Combot (jusqu\'en juin 2013) puis Agnès Deletang (à compter de septembre 2013), en leur qualité de coordonnatrices de formation continue et animatrices du pôle processus de décision et de formalisation de la justice civile à l\'ENM Paris, Mesdames Stéphane Hodara-Dupouy (jusqu\'en juin 2013) et Véronique Cadoret en leur qualité de coordonnatrices de formation initiale et animatrices du pôle processus de décision et de formalisation de la justice civile à l\'ENM Bordeaux, Mesdames Audrey Derieux-Boitaud (à compter de septembre 2013), Emmanuelle Leboucher-Cabelguenne, Corinne Miot, Anne Mure et Sophie Vignaud, coordonnatrices de formation initiale à l\'ENM Bordeaux.
>
> Le groupe de travail s'est penché sur l\'enseignement de la méthodologie de rédaction du jugement civil à l\'ENM, une autre étude ayant été simultanément réalisée au sein du tribunal de grande instance de Paris sur la qualité des jugements civils.
>
> Les résultats de cette dernière étude ont nourri la réflexion du groupe de travail précité.
>
> Ce document, réalisé sous forme de fiches méthodologiques portant chacune sur l\'une des parties essentielles du jugement civil ou sur une question importante de procédure civile comme l\'office du juge, est le fruit de travaux ainsi menés d\'octobre 2012 à janvier 2014.
>
> Il est régulièrement actualisé par les coordonnateurs de formation initiale de l'ENM Bordeaux.
>
> 1

# TABLE DES MATIERES

# 

[TABLE DES MATIERES 2](#table-des-matieres)

[FICHE I : LES FAITS CONSTANTS 4](#fiche-i-les-faits-constants)

[*EXEMPLES D'EXPOSES DE FAITS CONSTANTS ET PERTINENTS* 7](#exemples-dexposes-de-faits-constants-et-pertinents)

[FICHE II : LES ELEMENTS DE PROCEDURE 11](#fiche-ii-les-elements-de-procedure)

[*EXEMPLES D'EXPOSES DES ELEMENTS DE LA PROCEDURE* 14](#exemples-dexposes-des-elements-de-la-procedure)

[FICHE III : LES PRETENTIONS ET MOYENS RESPECTIFS DES PARTIES 17](#fiche-iii-les-pretentions-et-moyens-respectifs-des-parties)

[*EXEMPLES D\'EXPOSES DE PRETENTIONS ET DE MOYENS* 24](#exemples-dexposes-de-pretentions-et-de-moyens)

[FICHE IV: LA DISTINCTION ENTRE MOYENS ET ARGUMENTS 29](#fiche-iv-la-distinction-entre-moyens-et-arguments)

[*EXEMPLE D\'UN EXERCICE DE SELECTION DES MOYENS DANS UN EXPOSE DU LITIGE* 34](#exemple-dun-exercice-de-selection-des-moyens-dans-un-expose-du-litige)

[FICHE V : LE PROCESSUS D\'ANALYSE ET DE RAISONNEMENT 37](#fiche-v-le-processus-danalyse-et-de-raisonnement)

[A - LA PRISE EN MAIN ET L\'ANALYSE DU DOSSIER 37](#a---la-prise-en-main-et-lanalyse-du-dossier)

1)  [*Comment lire et que lire ? 37*](#comment-lire-et-que-lire)

2)  [*Que sélectionner ? 38*](#que-sélectionner)

3)  [*Comment récapituler les éléments sélectionnés ? Suggestion : le tableau analytique 39*](#comment-récapituler-les-éléments-sélectionnés-suggestion-le-tableau-analytique)

[B - LA CONSTRUCTION DU RAISONNEMENT ET LA RECHERCHE DES SOLUTIONS JURIDIQUES 40](#b---la-construction-du-raisonnement-et-la-recherche-des-solutions-juridiques)

[C - L\'ORDONNANCEMENT DES QUESTIONS ET L\'ÉLABORATION DU PLAN DU JUGEMENT 42](#c---lordonnancement-des-questions-et-lélaboration-du-plan-du-jugement)

[FICHE VI : L\'OFFICE DU JUGE 46](#fiche-vi-loffice-du-juge)

[FICHE VII : LA MOTIVATION 57](#fiche-vii-la-motivation)

[A -- LES REGLES GENERALES DE LA MOTIVATION CARACTERES 57](#_bookmark18)

[B -- LE SYLLOGISME JURIDIQUE 62](#b-le-syllogisme-juridique)

1)  [*Pour la prémisse majeure 63*](#pour-la-prémisse-majeure)

2)  [*Pour la prémisse mineure 64*](#pour-la-prémisse-mineure)

3)  [*Pour la conclusion du syllogisme 65*](#pour-la-conclusion-du-syllogisme)

[*EXEMPLES DE SYLLOGISMES SIMPLES* 66](#exemples-de-syllogismes-simples)

[*EXEMPLE DE SYLLOGISME PLUS COMPLEXE* 71](#exemple-de-syllogisme-plus-complexe)

[*EXEMPLE DE SYLLOGISME SIMPLIFIE* 72](#exemple-de-syllogisme-simplifie)

[*EXEMPLE DE SYLLOGISME IMPLICITE OU INVERSE* 73](#exemple-de-syllogisme-implicite-ou-inverse)

[C- L\'ORDRE D\'EXAMEN DES PRETENTIONS 74](#c--lordre-dexamen-des-pretentions)

> [FICHE VIII : LE DISPOSITIF 76](#fiche-viii-le-dispositif)

[FICHE IX : LA FORME ET LE STYLE DES JUGEMENTS 90](#fiche-ix-la-forme-et-le-style-des-jugements)

[A -- LE CHOIX DU STYLE DIRECT OU INDIRECT 90](#a-le-choix-du-style-direct-ou-indirect)

[B -- LE CHOIX DU VOCABULAIRE 92](#b-le-choix-du-vocabulaire)

[C- L'ADOPTION D'UN PLAN DE MOTIVATION APPARENT 93](#c--ladoption-dun-plan-de-motivation-apparent)

[D -- LE RESPECT DES RÈGLES DE SAISIE ET DE TYPOGRAPHIE 94](#d-le-respect-des-règles-de-saisie-et-de-typographie)

[E - RAPPEL DES PRINCIPALES RECOMMANDATIONS 95](#e---rappel-des-principales-recommandations)

# FICHE I : LES FAITS CONSTANTS

> **FONDEMENT TEXTUEL** :
>
> L'article 455 du code de procédure civile, qui fixe la composition du jugement civil, mentionne l'exposé succinct par le juge des prétentions respectives des parties et de leurs moyens mais ne fait pas référence à un exposé des faits constants.
>
> Toutefois, la bonne compréhension du jugement rend préférable une ou plusieurs phrases introductives sur le contexte de l'affaire qui saisit le tribunal et sur les faits de la cause. Il convient cependant de se limiter, à ce stade du jugement, aux seuls éléments de fait qui ne sont pas contestés et sont utiles à la compréhension et à la solution du litige.
>
> **DEFINITION** :
>
> **C**'est un exposé des faits qui ne sont contestés par aucune des parties et qui sont pertinents, c'est-à-dire nécessaires ou utiles à la compréhension et à la solution du litige.
>
> *[Exemple]{.underline} : dans une action en garantie des vices cachés sur un véhicule automobile, à raison d\'un dysfonctionnement du bloc moteur, la couleur du bien ou ses équipements de confort ne sont en aucun cas des éléments utiles à la compréhension et à la solution d\'un litige fondé sur la notion de vices cachés affectant le fonctionnement de ce véhicule.*
>
> *A l\'inverse, dans une action fondée sur un défaut de conformité du véhicule, à raison de tel accessoire que l\'acquéreur prétend avoir été convenu et n\'avoir pas équipé le véhicule livré, cet accessoire revêt une importance certaine dans le débat et s\'avère utile à la compréhension et la solution du litige. Il ne pourra toutefois être porté dans l\'exposé des faits constants et pertinents (« Le\..., X a passé commande auprès de la société Y, pour le prix de\... , d\'un véhicule automobile de telle marque équipé de tel accessoire ») que si ce dernier point n\'est ni contesté par le vendeur ni démenti par les pièces versées aux débats. A défaut, la mention de l\'accessoire devant équiper le véhicule devra être réservée à l\'exposé des moyens de l\'acheteur.*
>
> *La mention du prix, que l\'action soit une action fondée sur des vices cachés ou une action fondée sur un défaut de conformité, est utile à la compréhension et la solution du litige dès lors que le demandeur sollicite la restitution du prix ou de partie du prix.*
>
> **CARACTERES :**
>
> Cet exposé des faits constants doit être synthétique, objectif, neutre et précis.
>
> *[Exemple :]{.underline} dans l\'exemple précité donnant lieu à cet exposé des faits constants et pertinents : « Le\... , X a passé commande auprès de la société Y, pour le prix de\... , d\'un véhicule automobile de telle marque équipé de tel accessoire*
>
> *», la date de la commande, son objet, les noms respectifs des parties au contrat litigieux, le prix convenu, les caractéristiques élémentaires du véhicule (à adapter en fonction de l\'objet du litige et des contestations des parties)*
>
> *suffisent à situer les éléments utiles à la compréhension et la solution du litige. L\'exclusion des éléments contestés comme des éléments inutiles (ex: couleur du véhicule) permet un exposé synthétique et neutre tout en étant précis.*
>
> **EMPLACEMENT** :
>
> Dans la mesure où il doit faciliter la bonne compréhension des éléments à l'origine du litige, l'exposé des faits constants introduit le jugement et en constitue en conséquence ses premières phrases.
>
> **STYLE ET TEMPS** :
>
> **L**'exposé du litige est rédigé en style direct et avec l'emploi du passé (passé composé de préférence à l'imparfait), sauf pour les éléments de fait toujours d'actualité au jour du jugement, pour lesquels peut être employé le temps du présent.
>
> **RECOMMANDATIONS**
>
> Ne doivent pas être exposés à ce stade du jugement :

- Les faits qui font l'objet de contestations par l'une ou l'autre des parties, que ces contestations soient fondées ou non

- Les faits dont la relation par les parties est démentie par les pièces du dossier

- Les faits qui, bien qu'exposés par les deux parties sans contestation entre elles, ne sont pas utiles à la compréhension du litige ou à sa solution.

> Plus délicate est la question des faits sur lesquels l'une des parties garde silence. Ils ne pourront constituer des faits constants et être exposés comme tels en introduction au jugement que si ce silence peut être assimilé à une reconnaissance implicite de ces faits.
>
> Dans certaines affaires complexes, la bonne compréhension du litige peut imposer un exposé des faits constants assez développé. En règle générale, dans les affaires simples, l'exposé des faits se limite à une ou quelques phrases.
>
> A l'inverse, dans les quelques affaires où tous les éléments sont contestés, aucun exposé des faits constants ne sera possible et le jugement débutera par un rappel des éléments de la procédure.
>
> La nature même du litige commande parfois la nécessité d'exposer certains faits, sous réserve qu'ils ne soient pas contestés, compte-tenu de leur incidence sur la solution du litige ou encore de leur utilité à l\'accomplissement de certaines diligences antérieures ou postérieures au jugement.
>
> Ainsi,

- De la date de signature du procès-verbal de réception des travaux dans un litige portant sur le contentieux de la construction,

- De la date de délivrance du commandement d'avoir à payer les loyers dans un litige en résiliation d'un bail d'habitation,

- De la lettre de déchéance du terme et de mise en demeure de payer dans un litige en paiement d'un solde de crédit.

## *EXEMPLES D'EXPOSES DE FAITS CONSTANTS ET PERTINENTS*

> **[Dans un litige de nature contractuelle]{.underline}**
>
> *Mme X propriétaire d'un appartement a consenti le 16 avril 2016 à l'agence immobilière Y un mandat de vente sans exclusivité.*
>
> *Un acquéreur aux conditions prévues au mandat lui était présenté par l'agence le 28 avril 2016.*
>
> *Mme X déclinait la proposition. L'agence Y l'attrayait devant le tribunal pour obtenir sa condamnation au paiement d'une somme de 10 000 euros à titre de dommages et intérêts.*
>
> *L'agence Y expose dans ses dernières écritures :*

- s'être *vu consentir par Mme X un mandat de vente le 16 avril 2016, pour un prix de vente convenu de 210 000 euros, rémunération du mandataire incluse de 5 %*

- *avoir trouvé un acquéreur au prix du mandat dès le 23 avril 2016*

- *en avoir immédiatement informé Mme X*

- *lui avoir notifié l'offre par lettre R.AR du 28 avril 2016 reçue le lendemain*

- *avoir reçu de Mme X le 30 avril une lettre l'informant qu'elle avait elle-même trouvé des acquéreurs et que « le mandat n'avait plus lieu d'être »*

- *avoir adressé à Mme X une nouvelle lettre R.A.R. le 5 mai 2016 lui notifiant que faute par elle de respecter les termes du mandat, elle entendait obtenir une indemnisation égale au montant des honoraires contractuellement prévus.*

> *Mme X dans ses dernières écritures :*

- *ne conteste pas la date de signature et le contenu du mandat, ni les correspondances reçues de l'agence*

- *allègue avoir dès le 28 avril 2016, soit antérieurement à la réception de la lettre recommandée du même jour, avisé téléphoniquement l'agence de ce qu'elle avait elle-même trouvé un acquéreur*

> *[Quels sont les faits constants et pertinents ?]{.underline}*
>
> *Le litige repose sur un contrat signé par les deux parties, et sur des correspondances échangées en R.A.R. Il a pour objet la sanction du défaut d'exécution de ce contrat.*
>
> *L'ensemble des faits relatés par l'agence demanderesse mérite d'être rappelé : date du mandat, précision de ce qu'il était consenti [sans exclusivité]{.underline} (incidence directe sur la solution du litige), prix et rémunération du mandataire, contenu et dates des lettres échangées, essentiellement de celles des 28 avril et 30 avril 2016.*
>
> *Les dates de ces correspondances ont leur importance, dès lors qu'elles sont très proches dans le temps et qu'il sera nécessaire de rétablir la chronologie des faits afin de savoir si Mme X a dénoncé ou non le mandat avant d'être avisée de l'existence d'un acquéreur potentiel.*
>
> *En revanche, l'affirmation de l'agence Y selon laquelle elle aurait avisé dès le 23 avril Mme X de ce qu'elle avait trouvé un acquéreur, et celle de Mme X selon laquelle elle aurait téléphoné à l'agence dès le 28 avril*
>
> *pour l'informer qu'elle ne donnait pas suite au mandat, sont de simples allégations qui ne reposent sur aucun élément de preuve.*
>
> *Ces éléments n'ont donc pas à être repris.*

###### *Proposition de rédaction :*

> *Par contrat de mandat sans exclusivité du 16 avril 2016, d'une durée de trois mois renouvelable, Madame X a confié à la société en nom collectif... exerçant sous l'enseigne « AGENCE Y » la vente d'un bien lui appartenant sur la commune de MACON au prix de 210 000 €, rémunération du mandataire incluse.*
>
> *Le 28 avril 2016, l'agence Y a informé sa mandante qu'elle détenait une offre d'achat au prix demandé.*
>
> *Par lettre du 30 avril 2016, Madame X a porté à la connaissance de l'agence qu'ayant elle-même trouvé un acquéreur, elle n'entendait pas donner suite à l'offre présentée et que le contrat n'avait plus lieu d'être.*
>
> *C'est dans ces conditions que l'agence Y, considérant comme fautif le comportement de sa mandante, l'a faite assigner devant le tribunal de grande instance de MACON par acte du 4 juin 2016.*
>
> **[Dans un autre litige de nature contractuelle]{.underline}**
>
> *Alors qu\'ils séjournaient pour des vacances en métropole et observaient des fuites d\'huile à répétition sur les lieux de stationnement de leur véhicule, les époux X l\'ont déposé pour réparation auprès de la société Y, située\..., le matin du....Dans la nuit suivante, le véhicule a fait l\'objet d\'un vol dans les locaux de ladite société. Ce vol donne lieu à un procès-verbal de police produit aux débats par les demandeurs.*
>
> *Les époux X assignent la société Y en paiement de la somme de z euros, expliquant avoir été remboursés par leur assureur à hauteur de la valeur argus du véhicule mais n\'avoir pas été indemnisés de tous les chefs de préjudice (montant de la franchise, coût de la location d\'un véhicule de remplacement, préjudice de jouissance). La société Y s\'oppose à cette prétention en contestant toute responsabilité dans le vol.*
>
> *Le fait que les époux Y résident outre-mer et déposent leur véhicule auprès de la société X lors d\'un séjour en métropole peut être constant mais n\'est pas nécessairement pertinent. Dans un éventuel débat portant exclusivement sur le remboursement du montant de la franchise, un tel fait est indifférent pour la compréhension comme pour la solution du litige.*
>
> *Dans un débat portant sur des préjudices autres liés au vol du véhicule (ex : un préjudice de jouissance tel que, privés du véhicule, la date de départ de la métropole des époux Y a été retardée et un surcoût a dû être supporté sur leur billet de retour outre-mer), c\'est un fait utile à la solution liée à la réparation de ce chef de préjudice. Pour autant, si ce chef de demande est accessoire dans les débats, ce fait peut tout aussi bien être placé dans l\'exposé des moyens des époux X.*
>
> *Le seul fait de ne pas rapporter un élément dans l\'exposé des faits constants et pertinents n\'empêche pas le juge, au stade de la motivation, si cet élément est effectivement constant, de le considérer comme tel.*
>
> *Ni la notion de dépôt, ni sa date ni la réalité du vol dans la nuit suivant le dépôt ne sont contestés. Ils sont même confirmés par les pièces versées aux débats, dont le procès-verbal de police. Ce sont des faits constants et des faits pertinents en ce qu\'ils ont une incidence directe sur la solution du litige.*
>
> *S\'ils étaient contestés par une partie, quand bien même le procès-verbal de police tendrait à confirmer la thèse des époux X, ils ne pourraient être portés dans l\'exposé des faits constants.*
>
> *Le lieu du dépôt, non contesté, est utile à indiquer en ce qu\'il permet de vérifier que le véhicule était sous la garde du dépositaire sur le temps et le lieu du vol.*

###### *Proposition de rédaction :*

> *Le\..., les époux X ont déposé leur véhicule pour réparation auprès de la société Y, située\.... Dans la nuit suivante, le véhicule a fait l\'objet d\'un vol dans les locaux de ladite société.*

###### *[Dans un litige en responsabilité délictuelle :]{.underline}*

> *Le 4 février 2015, deux skieuses sont entrées en collision. L'une d'entre elle a été blessée et a donc saisi le tribunal pour obtenir réparation.*
>
> *Mme X demanderesse expose dans ses dernières écritures :*

- *avoir été heurtée à l'arrière par Mme Y, skieuse amont*

- *avoir ensuite percuté un canon à neige,*

- *victime d'une fracture de l'humérus, avoir été admise au centre hospitalier de Moutiers, puis transférée à l'hôpital de Clermont-Ferrand, plus proche de son domicile Mme Y défenderesse expose de son côté :*

- *s'être trouvée en aval de Mme X lors de la collision*

- *s'être trouvée dans l'obligation pour éviter la collision de remonter la pente et ainsi de passer sur l'arrière des skis de Mme X*

> *[Faits constants méritant d'être relatés]{.underline} :*
>
> *L'événement*

- *une collision entre les deux skieuses avec précision du lieu et du jour. La position des deux skieuses est contestée, chacune prétendant s'être trouvée en amont de l'autre. Il ne sera donc pas fait état de leur positionnement respectif. Celui-ci sera déterminé dans la partie « motivation*

> *» au vu des pièces versées aux débats.*

- *Mme Y reconnaît néanmoins dans ses écritures « être passée sur l'arrière des skis de Mme X », tout en attribuant cette circonstance à sa tentative de manœuvre d'évitement. Le fait stricto sensu est constant, mais pour autant ne constitue pas une reconnaissance de responsabilité.*

- *En résumé, il est suffisant d'indiquer que tel jour à tel endroit, deux skieuses sont entrées en collision.*

> *Les conséquences de l'événement :*

- *Il est seulement nécessaire de rappeler qu'à la suite de sa chute, Mme X a subi une fracture de l'humérus ayant entraîné son hospitalisation. Le lieu de l'hospitalisation initial et le transfert dans un autre hôpital pour des raisons de rapprochement familial sont sans intérêt pour la solution du litige.*

###### *Proposition de rédaction :*

> *Le 4 février 2015, deux skieuses qui évoluaient sur une piste de la station de Courchevel (73), Mme X et Mme Y, se sont heurtées en se croisant.*
>
> *Mme X est tombée et a percuté un canon à neige.*
>
> *Elle a subi une fracture de l\'extrémité supérieure de l\'humérus gauche et a été hospitalisée. Par acte d\'huissier .......*
>
> **[Dans un litige de nature familiale]{.underline}**
>
> *Monsieur Armand LEDRU et Madame Armelle DUPOND se sont connus alors qu'ils avaient respectivement 30 et 25 ans. Ils ont vécu en union libre pendant deux années puis se sont mariés le 12 mai 2010 à Arcachon, sans contrat de mariage.*
>
> *Alors que le couple vivait à Rouen, est né Florian le 15 mai 2012. Le couple a ensuite déménagé à Rennes où sont nées les jumelles Aglaë et Noémie le 25 mars 2014.*
>
> *Le couple s'est séparé le 8 décembre 2016, Mme ayant quitté le domicile conjugal.*
>
> *[Quels sont les faits constants et pertinents]{.underline} ?*
>
> *La date de mariage des époux avec ou sans contrat, le nombre des enfants nés pendant le mariage sont assurément des éléments constants et pertinents : ces éléments ont une incidence sur le divorce, les aspects liquidatifs de celui-ci, l'exercice de l'autorité parentale et les modalités à prendre relativement aux enfants.*
>
> *Toutefois le fait d'indiquer que Madame a quitté le domicile conjugal n'a pas à figurer dans les faits constants car il peut y avoir discussion sur l'origine de ces faits.*

###### *Proposition de rédaction :*

> *Monsieur Armand LEDRU et Madame Armelle DUPOND se sont unis par mariage le 12 mai 2010 à Arcachon (Gironde), sans contrat préalable.*
>
> *De cette union sont nés trois enfants, Florian né le 15 mai 2012 à Rouen, Aglaë et Noémie le 25 mars 2014 à Rennes.*
>
> *Par requête en date du .........*

# FICHE II : LES ELEMENTS DE PROCEDURE

> **FONDEMENT TEXTUEL**
>
> L'exposé des éléments de procédure n'est pas imposé par l'article 455 précité du code de procédure civile mais il est habituel d'y procéder. Il a pour objet de préciser les conditions de saisine du juge, les étapes du cheminement procédural du dossier. Il doit enfin aider à comprendre les éventuelles difficultés procédurales soulevées par les parties.
>
> **DEFINITION :**
>
> C'est un exposé des éléments de procédure (notamment acte introductif d'instance, décisions ou mesures antérieures prises entre les mêmes parties, dans la même instance ou dans une ou plusieurs instances distinctes) dans la mesure où leur rappel est utile à la compréhension du litige ou à l'examen ultérieur de questions de procédure.
>
> **CARACTERES** :
>
> **C**et exposé des éléments de procédure doit être synthétique et précis.
>
> **EMPLACEMENT** :
>
> **D**ans la grande majorité des dossiers et spécialement dans les dossiers simples, le rappel des éléments de procédure s'inscrit logiquement à la suite de l'exposé des faits constants et avant celui des prétentions respectives des parties.
>
> Dans les dossiers où tous les faits sont contestés, dans ceux où une précédente décision soit de sursis à statuer soit d'expertise a été prononcée, le rappel de l'acte introductif d'instance ou de la décision antérieure de sursis ou d'expertise peut utilement introduire l'exposé du litige.
>
> Le procédé tendant à rappeler les éléments de procédure au fur et à mesure de l'exposé du litige, en suivant le cheminement procédural du dossier, est à réserver aux dossiers plus complexes, spécialement aux affaires avec des interventions successives et des demandes additionnelles multiples.
>
> **STYLE ET TEMPS** :
>
> **L**'exposé des éléments de procédure est rédigé en style direct et avec l'emploi du passé composé.
>
> **RECOMMANDATIONS**
>
> Les éléments de procédure utiles à exposer dépendent de la nature du litige, du cheminement procédural du dossier, de sa complexité, des questions de procédure soulevées par les parties.
>
> Ils portent pour l'essentiel sur :

- Les conditions de saisine de la juridiction et d'introduction de l'instance ou d'intervention (nature, date, auteur et destinataire(s) de l'acte introductif d'instance, assignation en intervention forcée, conclusions d'intervention volontaire, jugement d'incompétence d'une autre juridiction au profit de ce tribunal, ordonnance d'injonction de payer, sa signification et l'opposition à cette ordonnance)

- Certaines décisions ou mesures d'administration judiciaire déjà prises dans la même instance ou dans une instance distincte (ex : jonction, disjonction d'instances, mesure d'expertise ou provision ordonnées par le juge des référés ou par le juge de la mise en état, mesure d'expertise ordonnée avant dire droit par la juridiction du fond, décision de sursis à statuer) et certaines étapes procédurales antérieures a fortiori si elles sont obligatoires (ordonnance de non conciliation préalable à l'assignation en divorce, procès-verbal de non conciliation et renvoi à l'audience de jugement du tribunal paritaire des baux ruraux)

- Dans la mesure où elles seraient utiles à la compréhension du litige, certaines autres décisions antérieurement prononcées, en lien avec le même litige (ainsi, dans une affaire en modification d'une pension alimentaire, de la dernière décision fixant le montant de la pension litigieuse).

> S'agissant de l'ordonnance de clôture dans les dossiers soumis à la procédure écrite, sa mention n'est pas impérative mais il est d'usage de la rappeler, ce qui permet de fixer la date au-delà de laquelle les pièces et conclusions nouvelles ne sont plus recevables. Cette mention sera alors faite en toute fin d'exposé du litige en ces termes *« L'ordonnance de clôture est intervenue le... » ou « a été rendue le « ou « Une ordonnance en date du\... (date de l\'ordonnance) a fixé la clôture de l'instruction de l'affaire au\... (date de la clôture fixée par ladite ordonnance) »,* la clôture pouvant être décalée et donc fixée à une date postérieure à celle de l\'ordonnance).
>
> S'agissant des parties non comparantes, il est nécessaire de préciser les modalités selon lesquelles elles ont été citées afin de permettre un contrôle sur la qualification donnée au jugement^1^ . Cette mention peut être portée en fin d'exposé du litige en ces termes *« Y, partie défenderesse régulièrement assignée à (modalité ddélivrance de la citation), n'a pas comparu (en procédure orale) ou n'a pas constitué avocat (en procédure écrite)».*
>
> A l'inverse, ne doivent pas être exposés à ce stade du jugement :

- Les éléments de procédure dont la lecture du dossier et des actes de procédure ne permet de s'assurer ni de l'existence, ni de la forme, ni de l'objet

- Les éléments de procédure qui ne sont pas utiles à la compréhension du litige (ex : mesure de radiation ou de retrait de l'affaire puis de réinscription au rôle des affaires en cours ; première

> *^1^ En ce sens, une jurisprudence constante de la Cour de cassation et notamment Civ. 1 20 novembre 2001, BC I n° 283 ; Soc. 28 mai 1991, BC V, n° 268 ; Civ 2^ème^ 22 février 1989, BC II n° 45.*
>
> ordonnance de clôture ensuite révoquée et suivie d'une nouvelle ordonnance de clôture : seule cette dernière ordonnance est à mentionner).

## *EXEMPLES D'EXPOSES DES ELEMENTS DE LA PROCEDURE*

- **[Dans un litige de construction]{.underline}**

> Monsieur et Madame S ont confié à la S.A.R.L GDIMOB, placée ultérieurement en liquidation judiciaire, la mise en œuvre des travaux de construction d'une maison à ossature bois dont la conception a été réalisée par la société MODULEX. Insatisfaits de cette réalisation, les époux S ont fait dresser un procès-verbal de constat de malfaçons par huissier de justice puis ont saisi leur assureur GROUPAMA, lequel concluait après expertise amiable à la nécessité d'une action judiciaire contre le constructeur. Après expertise judiciaire ordonnée par le juge des référés et étendue à l\'association PROMOTELEC, sous-traitant de la société GDIMOB, les époux S ont fait assigner les défendeurs. La Mutuelle des Architectes Français est intervenue volontairement à la procédure aux fins de garantie de la société MODULEX.
>
> **Proposition de rédaction**
>
> Par actes des 29 et 30 octobre 2015 et du 4 novembre 2015, les époux S ont fait assigner la S.A.R.L. GDIMOB, la SCP PIMOUGUET et LEURET ès qualités de liquidateur de la S.A.R.L GDIMOB, la M.A.A.F Assurances en qualité d'assureur de la S.A.R.L GDIMOB et la société MODULEX devant le Président du tribunal de grande instance statuant en référé aux fins de voir ordonner une expertise de l'immeuble.
>
> Par ordonnance du 15 janvier 2016, le juge des référés a fait droit à leur demande et a désigné Monsieur C, remplacé par ordonnance du 29 janvier 2016 par Monsieur F, pour procéder à l'expertise ordonnée, mesure étendue par ordonnance du 3 juin 2016 à l'association PROMOTELEC appelée en la cause.
>
> L'expert a remis son rapport le 12 mai 2016.
>
> Par actes en date des 31 août 2016, 7 et 18 septembre 2016, les époux S ont fait assigner la
>
> S.A.R.L.GDIMOB, la SCP PIMOUGUET et LEURET ès qualités de liquidateur de la S.A.R.L GDIMOB, la M.A.A.F Assurances en qualité d'assureur de la S.A.R.L GDIMOB et la société MODULEX devant le tribunal de grande instance de Périgueux aux fins d'obtenir leur condamnation au paiement des frais de réfection de l'immeuble.
>
> Par conclusions signifiées le 18 octobre 2016, la Mutuelle des Architectes Français est intervenue volontairement à la procédure aux fins de garantie de la société MODULEX.
>
> **N.B :**

1.  La procédure de référé expertise, le nom de l'expert, les parties associées à la mesure d'expertise et la date du dépôt du rapport sont à exposer dans la mesure où, bien qu'ordonnée dans une instance distincte de l'instance au fond, cette expertise constitue un élément essentiel du débat au fond. Ces mentions permettent notamment de vérifier son caractère judiciaire, son caractère contradictoire à l'égard de toutes ou de certaines seulement des parties, l'auteur du rapport et son ancienneté. Il n'est en revanche pas utile de développer à ce stade les conclusions de l'expert judiciaire, l'exposé du litige devant rester

> synthétique. L'intervention volontaire doit être mentionnée en ce que la Mutuelle des Architectes Français entend être ainsi partie au litige.

2.  Le placement en liquidation judiciaire de la société GDIMOB n\'est pas à mentionner dans les éléments de procédure, s\'agissant d\'un fait constant antérieur à l\'introduction de l\'instance.

    - **[Dans un litige de servitude]{.underline}**

> [Contexte factuel :]{.underline} les époux X sont propriétaires d\'un ensemble immobilier situé commune de..., et la congrégation Y est propriétaire d\'un ensemble voisin. Les deux ensembles proviennent de la division d\'un ensemble unique, division à l\'occasion de laquelle une servitude de passage a été créée au profit de la parcelle appartenant à la congrégation, sur la parcelle acquise par les époux X.
>
> Les parties sont en litige depuis plusieurs années et deux décisions de justice sont intervenues :

- Une ordonnance de référé du 22 juin 2013, confirmée par la cour d\'appel de CAEN (enjoindre aux époux X de libérer le chemin d\'accès et autoriser la congrégation à procéder à la réfection du chemin indivis pour le compte de l\'indivision)

- Un jugement du TA de CAEN annulant un permis de construire accordé à la Congrégation en vue de la construction d\'un temple.

> Les époux X ont fait assigner la congrégation Y devant le tribunal par acte en date du 25 février
>
> 2016\.
>
> La partie «procédure» n'est en fait constituée que de la seule assignation au fond délivrée par les époux X à la congrégation, en vue d'obtenir la suppression de la servitude de passage grevant leur fonds.
>
> L'ordonnance de référé et l'arrêt confirmatif de la cour n'ont pas lieu d'être rappelés.
>
> Si ces indications permettent d\'appréhender le climat conflictuel existant entre les parties depuis quasiment l\'origine, elles n\'apportent rien à la solution du litige. Le juge des référés ne s\'est pas prononcé sur le fond, il a seulement constaté qu\'une servitude existait et que les époux X s\'étaient rendus coupables d\'une voie de fait en en interdisant l\'accès.
>
> Le fait que la congrégation ait vu le permis de construire d'un temple annulé par le tribunal administratif ne constitue pas non plus [un élément de procédure]{.underline} utile à la solution du litige.
>
> Cet événement constituera [éventuellement]{.underline}, après analyse du dossier dans son ensemble, un moyen utile pour l'une ou l'autre des parties quant à l'intérêt du maintien ou non de la servitude grevant le fonds des époux X.
>
> Les éléments de procédure se réduisent donc dans ce dossier à l\'assignation.
>
> **Proposition de rédaction :**
>
> Considérant que l\'usage par la congrégation du droit de passage sur leur propriété ne se justifiait plus, les époux X ont fait assigner celle-ci devant le tribunal de .... par acte en date du 25 février 2016.

- **[Dans un litige de nature familiale]{.underline}**

> Monsieur Arthur Jean et Madame Sophie Durand se sont mariés le 22 avril 2007 à BREST, sans contrat de mariage. Deux enfants sont issus de cette union, Paul né le 12 mars 2008 et Quentin né le 15 juillet 2010. Monsieur Jean a quitté le domicile conjugal en septembre 2015. Madame a saisi le juge aux affaires familiales de Quimper d\'une requête en divorce le 5 février 2016. Les époux ont été convoqués devant le juge aux affaires familiales aux fins de tentative de conciliation le 25 avril 2016. Il a rendu une ordonnance de non conciliation le 12 mai 2016, aux termes de laquelle il a constaté la non-conciliation des époux et prononcé les mesures afférentes aux époux et aux modalités d'exercice de l\'autorité parentale.
>
> Madame Sophie Durand a fait assigner son époux devant le tribunal de grande instance de QUIMPER en divorce pour faute.
>
> Saisi postérieurement à l'assignation par Madame Durand, d\'un incident sur le droit de visite du père, le juge de la mise en état a ordonné avant dire droit une enquête sociale et a décidé que le père verrait désormais les enfants dans le cadre d\'un espace rencontre, chaque premier samedi du mois de 14 heures à 16 heures.

###### *Proposition de rédaction*

> Monsieur Arthur Jean et Madame Sophie Durand se sont mariés le 22 avril 2007 à BREST, sans contrat de mariage.
>
> Deux enfants sont issus de cette union, Paul né le 12 mars 2008 et Quentin né le 15 juillet 2010.
>
> A la suite de la requête en divorce déposée le 5 février 2016 par Madame Sophie Durand, le juge aux affaires familiales du même tribunal, par ordonnance de non conciliation en date du 12 mai 2016, a fixé la résidence séparée des époux ainsi que les mesures provisoires relatives aux époux et aux enfants:
>
> Par acte en date du 14 août 2016, Madame Durand a fait assigner son conjoint en divorce sur le fondement des dispositions des articles 242 et suivants du code civil. *(Ces éléments sont importants à rappeler dans la mesure où l\'ordonnance de non conciliation va autoriser les époux à assigner au fond dans les 30 mois de l\'ordonnance de non conciliation sous peine de caducité et ce nonobstant appel. Par ailleurs le demandeur à la requête en divorce n\'est pas nécessairement celui qui assigne au fond, le demandeur initial ayant le privilège d\'assigner dans les 3 mois du prononcé de l'ordonnance de non-conciliation).*
>
> Saisi postérieurement à l'assignation par Madame Durand, d\'un incident sur le droit de visite du père, le juge de la mise en état a, par ordonnance en date du 20 décembre 2016, prononcé une mesure d'enquête sociale et organisé dans l'attente du dépôt du rapport, un droit de visite du père au sein d'un espace de rencontres**(cet élément mérite d'être signalé dans la mesure où des éléments de l'ordonnance de non-conciliation ont pu être modifiés par une ordonnance du juge de la mise en état *= mesures prises au titre de l\'article 255 du code civil*).**

# FICHE III : LES PRETENTIONS ET MOYENS RESPECTIFS DES PARTIES

> **FONDEMENT TEXTUEL**
>
> Aux termes de l'article 455 du code de procédure civile, le jugement doit exposer succinctement les prétentions respectives des parties et leurs moyens. Cet exposé peut revêtir la forme d'un visa des conclusions des parties avec l'indication de leur date.
>
> Aux termes de l'article 4 du même code, l'objet du litige est déterminé par les prétentions respectives des parties. Ces prétentions sont fixées par l'acte introductif d'instance et par les conclusions en défense. Toutefois l'objet du litige peut être modifié par des demandes incidentes lorsque celles-ci se rattachent aux prétentions originaires par un lien suffisant.
>
> L\'objet du litige, selon la définition qui en est donnée par Henri MOTULSKY, est « *le but économique ou social recherché par les parties ».*
>
> **DEFINITION**
>
> Les deux termes de prétentions et de moyens peuvent être définis comme suit : « D\'un côté, l\'objet de la demande, la finalité poursuivie, de l\'autre les justifications de cette demande, les moyens pour la faire accueillir par le juge »^2^.
>
> *Les prétentions*
>
> Au sens strict, la prétention renvoie à une notion juridique distincte de celle de « demande » avec laquelle elle est souvent confondue dans le langage commun. La prétention constitue l'objet de la demande (c'est ce à quoi prétend telle partie, ex: annulation d'un contrat, allocation de dommages et intérêts) tandis que la demande est l'acte du procès qui saisit le juge d'une prétention (c'est ce par quoi est formulée la prétention, ex : demande initiale, matérialisée sous la forme d'une assignation, d'une requête ou d'une déclaration au greffe, ou demande incidente, c'est-à-dire reconventionnelle, additionnelle ou intervention, matérialisée en procédure écrite sous la forme de conclusions).
>
> Les prétentions respectives des parties déterminent l'objet du litige et fixent les limites de l'intervention du juge, lequel en effet « doit se prononcer sur tout ce qui est demandé et seulement sur ce qui est demandé » (art 5 CPC). Il est donc essentiel de les exposer de façon exhaustive et sans les dénaturer.
>
> *Les moyens*
>
> Les moyens, qui peuvent être de droit ou de fait, viennent au soutien des prétentions et sont à distinguer de l'argument.
>
> *^2^ Raymond MARTIN, dans un article paru au JCP G 1976, n° 2768 sous le titre « Sur la notion de moyen »*
>
> Les moyens sont des considérations de droit (moyens de droit) ou des circonstances de fait (moyens de fait), invoquées par une partie à l'appui de ses prétentions et tendant à l'application des règles juridiques.
>
> En d\'autres termes^3^,

- Une partie fonde sa prétention sur des moyens de fait, allégation dont elle a la charge en application de l\'article 6 du code de procédure civile (*« A l\'appui de leurs prétentions, les parties ont la charge de l\'allégation des faits propres à les fonder »*) et en dehors de laquelle le juge ne peut fonder sa décision (*art.7 CPC : « le juge ne peut fonder sa décision sur des faits qui ne sont pas dans les débats*

> *»*) ;

- La même partie propose un moyen de droit, charge partagée avec le juge qui, en application de l\'article 12 du code de procédure civile, « *tranche le litige conformément aux règles de droit qui lui sont applicables ».*

> Moyens de droit ou moyens de fait, ils s'inscrivent en conséquence dans un raisonnement juridique, par opposition à l'argument, simple élément de discussion sans caractère opérant sur l'application de la règle juridique.
>
> La distinction entre moyen et argument, parfois subtile, est importante puisque l'exposé que l'article 455 précité impose au juge de réaliser est un exposé des seuls prétentions et moyens, auxquels seuls devra répondre la motivation. A l'inverse, les arguments n'ont pas à être exposés et n'appellent pas de réponse dans la motivation.
>
> *[Exemple]{.underline} : soit une demande en paiement d\'une somme de 2 000 euros faite par un particulier X à l\'encontre d\'un autre particulier Y au motif que 1°) ladite somme aurait été prêtée à ce dernier quelques années plus tôt et n\'aurait jamais été remboursée.*
>
> *Y sollicite le rejet de cette prétention en faisant valoir 1°) qu\'il appartient à X de rapporter une preuve écrite de l\'obligation dont il se prévaut, 2°) qu\'en l\'espèce les seules pièces qu\'il verse aux débats sont insuffisantes à constituer la preuve du prétendu prêt, 3°) que ce prêt serait du reste déjà ancien et 4°) que la présente réclamation aurait été précédée d\'autres demandes de la part de X pour d\'autres prétendues créances tout aussi imaginaires.*
>
> *X réplique 2°) faire la preuve de l\'obligation notamment par une reconnaissance de dette signée par Y, 3°) auquel il appartient de prouver s\'être libéré depuis lors de sa dette.*
>
> *En résumé,*

- *[Pour X, moyens de fait]{.underline} : un prêt de 2 000 euros consenti à Y, qui résulte d\'une reconnaissance de dette signée par ce dernier, ce prêt n\'ayant jamais été remboursé / [moyen de droit]{.underline}: la preuve de l\'obligation étant rapportée, c\'est à Y qu\'il appartient de justifier s\'être libéré de sa dette (c\'est un rappel de l\'ancien article 1315 alinéa 2 du code civil /article 1353 nouveau du code civil et donc un moyen de droit)*

- *[Pour Y, moyens de droit]{.underline} : la charge de l\'obligation pèse sur celui qui l\'invoque et la preuve doit être écrite (c\'est un rappel des anciens articles 1315 alinéa 1^er^ et 1341 du code civil/articles 1353 nouveau et 1359 nouveau du code civil) [moyen de fait]{.underline} : en l\'espèce, aucune preuve suffisante n\'est rapportée.*

> *^3^ cf. l\'article précité de R.MARTIN.*
>
> **CARACTERES** : cet exposé des prétentions et des moyens doit être :

- **Complet** puisqu'en effet le juge devra se prononcer, dans la motivation, « sur tout ce qui est demandé » (art. 5 CPC)

  - Aussi toutes les prétentions, même celles présentées par les parties comme étant subsidiaires, doivent être rapportées par le juge ;

  - Si une prétention est qualifiée par la partie de subsidiaire et telle autre d'accessoire, ces qualificatifs sont à reproduire à l'identique car ils fixent les limites de la saisine du juge ; peuvent toutefois être exclues de l'exposé les demandes non destinées à produire un effet juridique (ex : certaines demandes de donner acte).

  - Il est commencé par l'exposé des prétentions du demandeur principal et ce, dans l'ordre où elles sont présentées par celui-ci ; le juge doit ainsi respecter la chronologie adoptée par la partie^4^ ;ainsi, dans l'hypothèse d'une demande en paiement, il ne pourra être considéré que la demande subsidiaire en délai de paiement constitue un aveu de la qualité de débiteur par celui qui la forme.;

  - La décision doit exposer les prétentions et moyens de toutes les parties ; il convient à cet égard d\'être vigilant dans les dossiers où notamment les défendeurs sont multiples, où certains d\'entre eux peuvent ne développer qu\'un moyen de défense tendant au rejet des prétentions adverses soutenues à leur encontre et ne formuler reconventionnellement qu\'une demande de dommages et intérêts pour procédure abusive et/ou une demande d\'indemnité au titre de l\'article 700 du code de procédure civile qui, par erreur, peuvent être omises dans l\'exposé des prétentions, ce qui risque ensuite de se traduire par une omission de statuer ;

> *^4^ En ce sens, Cass. ass. plén, 29 mai 2009, n° 07-20.913*.

- L'exposé des moyens doit porter sur l'ensemble des moyens, de droit et de fait, soutenus par les parties à l'appui de leurs prétentions respectives ou en réponse aux prétentions adverses ; à ce stade du jugement, il n\'y a pas lieu de sélectionner les seuls moyens pertinents pour ignorer les autres ; dès lors que l\'élément invoqué a valeur de moyen, il doit être rapporté ; l\'appréciation de sa pertinence relève de la seule motivation ;

- En procédure écrite, les prétentions et moyens sont contenus dans les dernières conclusions des parties (art. 753 al. 2 CPC pour les instances introduites avant le 11 mai 2017, art. 753 al. 3 CPC pour les instances introduites à compter du 11 mai 2017) ;

> Le décret n° 2017-892 du 6 mai 2017 a introduit une nouveauté applicable aux instances introduites à compter du 11 mai 2017 en précisant dans l'article 753 alinéa 2 nouveau du CPC que seules les prétentions contenues dans le dispositif des conclusions des parties saisissent le juge.
>
> Si le demandeur ne conclut pas à nouveau après l'assignation, les prétentions et moyens contenus dans cette assignation, qui vaut conclusions, sont la base de l\'exposé des prétentions et moyens du demandeur.

- En procédure orale, le principe est que les prétentions et moyens sont ceux soutenus oralement à l'audience et qui résultent de la note d'audience ou ceux présentés dans un écrit auquel la partie s'est référée à l'audience (article 446-1 alinéa 1 CPC)^5^.

> Par exception au principe de l'oralité, l'article 446-2 du CPC permet au juge d'organiser une procédure écrite dite simplifiée si les conditions posées par ce texte sont réunies . Dans ses dispositions issues du décret n° 2017-892 du 6 mai 2017, applicables aux instances introduites à compter du 11 mai 2017, cet article impose au magistrat de ne statuer que sur les prétentions énoncées au dispositif des dernières conclusions des parties.

- **Synthétique**, caractère qui ressort des termes mêmes de l'article 455 du code de procédure civile (exposé « succinct » des prétentions et moyens respectifs des parties)

<!-- -->

- L'effort de synthèse porte essentiellement sur l'exposé des moyens et suppose, d'une part de distinguer entre moyens et arguments dans les développements des parties, pour n'exposer que les seuls moyens, d'autre part de se détacher de la lettre des conclusions des parties pour s'approprier le litige et être en capacité de résumer les positions respectives des parties ;

- Il suffit, aux termes de la jurisprudence de la Cour de cassation, que cet exposé soit « suffisamment révélateur » des moyens et prétentions des parties^6^ ; pour autant, le jugement ne se comprendra bien et la motivation ne se construira bien que si cet exposé, tout en étant synthétique, est suffisamment rigoureux dans sa construction et exhaustif dans l\'énoncé des différents moyens, de droit et de fait, venant au soutien des prétentions préalablement rappelées.

> *^5^ Sous réserve de certaines exceptions permettant la formulation par écrit de prétentions et moyens sans nécessité de se présenter à l'audience pour les soutenir oralement ; ainsi, en application de l'art. 847-2 du CPC, pour une demande incidente de délais de paiement devant le tribunal d'instance.*
>
> *^6^ En ce sens, Civ. 2, 22 mai 1995, BC 1995 II, n° 147 et Cass. Soc., 7 nov. 2001, GP 9-10 oct. 2002, p. 41, Perdriau.*

- **Objectif**

> A ce stade, comme tout au long de l'exposé du litige, le juge doit s'interdire de prendre position ; aussi, il peut introduire l'exposé des moyens par l'emploi des termes suivants *: « X expose que ..., soutient que ... ; Y réplique au moyen tiré de ... que ... ; il fait encore valoir que ... » (ce que l'on nomme le style indirect).*

- **Fidèle**

> Le résumé des prétentions et moyens ne doit pas conduire à altérer ni dénaturer les positions respectives des parties, auxquelles le juge doit s'efforcer de rester parfaitement fidèle dans son exposé.
>
> La rigueur de l'exercice intellectuel d'analyse et de synthèse, à ce stade du jugement, conditionne de façon certaine la qualité de la motivation et de la décision.
>
> **EMPLACEMENT** : l
>
> L'article 455 précité du code de procédure civile n'assigne pas de place précise à cet exposé.
>
> Il est satisfait aux exigences de cet article 455 dès lors que la décision comporte un rappel succinct des prétentions et moyens respectifs des parties, quelle que soit la forme sous laquelle est faite cette mention et quelle que soit la partie du jugement où elle prend place.

*prétentions*

> *de X* ») ou de ses dernières conclusions (« *Par acte en date du ... X a fait assigner Y devant le ... en garantie des vices cachés. Dans ses dernières conclusions signifiées le... X demande au tribunal de ...*
>
> *prétentions de X* ») et de poursuivre sur la présentation des moyens venant au soutien des différentes prétentions.
>
> **LA FORME DE L'EXPOSE**
>
> L'exposé des prétentions et moyens respectifs des parties peut prendre une forme littérale ou celle d'un visa de conclusions.
>
> *L'exposé littéral*
>
> En l'absence d'utilisation par le juge du visa des conclusions, l\'exposé littéral des prétentions et des moyens respectifs des parties peut être réalisé selon deux méthodes de rédaction :

- Soit la rédaction par blocs, consistant à exposer successivement, pour chaque partie, ses prétentions et, directement à la suite de celles-ci, les moyens venant au soutien desdites prétentions, de même que la réplique aux moyens en défense des autres parties et aux demandes reconventionnelles ; cette méthode permet de réaliser un exposé plus synthétique et expose moins à l'oubli de certaines demandes et des moyens ;

- Soit la rédaction dite événementielle qui épouse l'ordre dans lequel sont soutenus les prétentions et moyens des différentes parties et conduit à un « chassé-croisé » entre les parties (prétentions du demandeur principal, ses moyens, les moyens en défense de la partie adverse, les prétentions reconventionnelles de celle-ci et les moyens qui les appuient, les moyens en réplique du demandeur principal à ces prétentions).

> *Le visa de conclusions*
>
> En son alinéa 2^ème^, l'article 455 permet de donner à l'exposé des prétentions et des moyens respectifs des parties la forme d'un visa des conclusions avec l'indication de leur date.
>
> Cet exposé par visa est admis y compris en procédure orale, lorsqu'une partie a formalisé des prétentions et moyens dans un écrit, auquel elle s'est référée à l'audience (en ce cas, la date à mentionner est la date de l'audience à laquelle l'écrit est soutenu oralement, de telles écritures ayant pour date celle de l'audience).
>
> En procédure écrite, la date à mentionner sera la date de signification ou de notification des écritures à la partie adverse qui permet de vérifier le respect du principe du contradictoire, de préférence à la date de leur dépôt au greffe ou de leur rédaction.
>
> En cette procédure écrite, ce sont les dernières conclusions des parties qui font l'objet du visa avec l'indication de leur date. Un visa de conclusions sans mention de date ne respecterait pas les exigences de l'article 455 précité et ne dispenserait pas le juge d'un exposé littéral des prétentions et des moyens respectifs des parties.
>
> L'utilisation du visa de conclusions avec leur date allège incontestablement l'exposé du litige et en réduit le temps de rédaction. Toutefois, elle peut rendre la décision moins lisible et elle ne dispense pas le juge du travail intellectuel d'analyse et de synthèse des prétentions et moyens, préparatoire à la rédaction de la motivation et essentiel pour la qualité de celle-ci.
>
> Pour restaurer la lisibilité de sa décision le juge pourra limiter le visa aux seuls moyens et ainsi rapporter les prétentions dans l\'exposé du litige (ex : *Vu les dernières conclusions de X signifiées le \..., auxquelles il convient de se référer pour l'exposé des moyens, aux fins de condamnation de Y à ... suit le rappel des prétentions de X et il en sera de même pour Y).* En outre il pourra, dans le corps de la motivation et en début d'examen de chacun des chefs de prétention, réaliser le résumé, qui n'a pas été fait dans l'exposé du litige, des moyens des parties venant au soutien de ladite prétention ou en réplique à celle-ci.
>
> *[Exemple]{.underline} : soit une demande de dommages et intérêts, examinée dans un jugement où l\'exposé des moyens a été construit par visa des dernières conclusions. L\'examen de ce chef de demande dans la motivation peut être ainsi introduit :*
>
> *[Sur la demande en paiement de dommages et intérêts]{.underline}*
>
> *Au soutien de sa demande, X fait valoir que (moyens de X venant au soutien de ce chef de prétention).... Y réplique en opposant ... (moyens de Y en réplique à la prétention et aux moyens adverses).*
>
> *En droit\..... En l\'espèce... (suit alors le syllogisme juridique avec, en premier lieu, le rappel par le juge de la règle applicable puis l\'examen des moyens au regard de cette règle et des pièces du dossier).*
>
> Cet emploi du visa est de préférence à réserver aux dossiers complexes comportant de multiples chefs de prétentions et, pour chacun d\'eux, de multiples moyens, de sorte que le rappel de ces moyens au plus près de leur examen, donc au plus près de la partie motivation qui leur est consacrée, peut être utile le cas échéant.
>
> **STYLE ET TEMPS** :
>
> **L**'exposé des prétentions et moyens est rédigé en style indirect et avec l'emploi du présent dans la mesure en effet où seuls sont exposés les prétentions et moyens soutenus dans les dernières conclusions ou dans le dernier état des débats, à l'exclusion des prétentions et moyens abandonnés en cours d'instance par telle ou telle partie.
>
> **RECOMMANDATIONS**
>
> L'une des difficultés de cet exposé réside dans la distinction nécessaire à réaliser entre moyens, qui seuls doivent être exposés et auxquels seuls il sera répondu dans la motivation, et arguments. En cas de doute persistant sur le développement d'une partie, sur le point de savoir s'il s'agit d'un moyen ou d'un simple argument, il est préférable d'exposer cet élément et, le cas échéant, d'y répondre dans la motivation.

## *EXEMPLES D\'EXPOSES DE PRETENTIONS ET DE MOYENS*

###### *[En matière de responsabilité]{.underline}*

###### *Contexte factuel*

> *Une personne qui assistait à un thé dansant organisé par une association, chute sur le sol alors qu\'elle dansait et subit une fracture du poignet. Elle recherche la responsabilité de l\'association sur le fondement délictuel. L\'association conteste sa responsabilité et indique qu\'en tout état de cause, l\'action ne pourrait être intentée que sur un fondement contractuel.*

###### *Proposition de rédaction*

###### *Après avoir rappelé les faits constants et pertinents ainsi que la procédure, l\'exposé des* prétentions et des moyens peut être formalisé comme suit :

> ***(Prétentions de Madame X)** Madame X a fait assigner Y et la caisse primaire d\'assurance-maladie de la Gironde devant le tribunal de grande instance de Bordeaux aux fins d\'obtenir réparation intégrale de son préjudice.*
>
> *Selon dernières conclusions signifiées le 18 mars 2017, elle sollicite au titre de ses préjudices extrapatrimoniaux, la somme de 28 056 euros se décomposant comme suit :*

- *600 euros au titre de l\'incapacité temporaire totale,*

- *2 856 euros au titre de l\'incapacité temporaire partielle pendant 238 jours,*

- *1 200 euros au titre de la gêne dans les activités ludiques pendant 17 mois,*

- *14 400 euros au titre du déficit fonctionnel permanent, - 5 000 euros au titre des souffrances endurées, - 4 000 euros au titre du préjudice d\'agrément.*

> *Elle demande en outre la condamnation de Y au paiement d\'une somme de 1 500 euros sur le fondement de l\'article 700 du code de procédure civile, ainsi qu\'aux dépens comprenant les frais de référé et d\'expertise avec droit de recouvrement direct au profit de Me Z, le tout sous le bénéfice de l\'exécution provisoire.*
>
> ***(Moyens de Madame X)** Madame X fait valoir à titre principal que la responsabilité de l'association est engagée sur le fondement de l'article 1242du code civil. Elle soutient que l'existence d'un contrat la liant à Y n'est pas établie, de sorte qu'elle est fondée à agir au titre de la responsabilité délictuelle. Elle expose qu'elle a chuté en raison d'un sol anormalement glissant, situation qu'elle impute à Y, laquelle détenait le pouvoir d\'usage, de contrôle et de direction de la manifestation dans la salle des fêtes mise à sa disposition. Elle conteste tout comportement fautif de sa part, rappelant que plusieurs témoins ont confirmé qu'elle dansait sur une cadence non rapide.*
>
> *A titre subsidiaire, elle estime qu'à défaut de responsabilité délictuelle, la responsabilité contractuelle de Y est engagée sur le fondement de l'article 1231-1du code civil en raison de l'obligation de sécurité incombant à l'organisateur d'événements sportifs ou de loisirs et du manque d'informations délivrées par Y sur les caractéristiques du sol de la salle.*
>
> *Enfin, pour justifier sa demande en indemnisation des préjudices, elle se réfère aux conclusions de l'expert.*
>
> ***(Prétentions de Y)** Par dernières conclusions signifiées le 7 mai 2017, Y conclut au rejet de la demande fondée sur des dispositions de l\'article 1242 du code civil et subsidiairement à son rejet sur le fondement de l'article 1231-1du code civil.*
>
> *À titre plus subsidiaire encore, Y demande au tribunal de limiter à la somme de 14 600 euros l\'indemnisation des préjudices à caractère extrapatrimonial de l\'intéressée et de la débouter de sa demande présentée sur le fondement de l\'article 700 du code de procédure civile.*
>
> ***(Moyens de Y)** Y considère que sa responsabilité ne peut être engagée sur le fondement de l'article 1242 du code civil dès lors qu'un contrat s'était formé entre les parties, Madame X ayant acquitté un droit d'entrée pour participer à la manifestation.*
>
> *À titre subsidiaire, elle estime qu\'elle n\'a commis aucun manquement à son obligation contractuelle de sécurité et rappelle que les organisateurs de bals ne sont soumis qu'à une obligation de moyen compte tenu de la liberté de mouvement des danseurs. Y indique que la chute de Madame X n'est donc due qu'à sa maladresse.*
>
> *S'agissant des préjudices invoqués par Madame X, Y précise que Madame X ne justifie ni de la gêne au titre des activités ludiques ni de son préjudice d'agrément.*
>
> *Sur les autres préjudices, Y considère que les indemnités sollicitées doivent être ramenées à des sommes plus raisonnables.*

###### *[En matière de vente d\'un bien]{.underline}*

###### *Contexte factuel :*

> *Un particulier vend une moto de faible kilométrage à une société. Quelques mois plus tard, la société constate des dysfonctionnements. Elle entend rechercher la responsabilité du particulier pour obtenir restitution du prix outre des dommages et intérêts.*

###### *Proposition de rédaction :*

###### *Après avoir rappelé les faits constants et pertinents ainsi que la procédure, l\'exposé des prétentions et des* moyens peut être formalisé comme suit :

> ***(Prétentions de X)** Dans ses dernières écritures signifiées le 10 avril 2017, la société X sollicite**,** sous le bénéfice de l\'exécution provisoire, et au visa des articles 1641 et suivants et 1133 du code civil, de voir prononcer :*

- *A titre principal, la résolution de la vente pour vices cachés et la condamnation de Monsieur Y à restituer de la somme de 12 500 euros avec intérêts au taux légal à compter du 13 février 2016 et restitution du véhicule par la société X,*

- *A titre subsidiaire, la nullité de la vente pour erreur sur les qualités substantielles du véhicule avec les mêmes conséquences (remboursement du prix d'achat et restitution du véhicule),*

- En tout état de cause :

  - *la condamnation de Monsieur Y au paiement de la somme de 10 000 euros en réparation de son préjudice financier,*

  - *la condamnation de Monsieur Y au paiement de la somme de 5 000 euros en application des dispositions de l'article 700 du code de procédure civile,*

  - *la condamnation de Monsieur Y aux dépens avec application des dispositions de l'article 699 du code de procédure civile.*

> ***(Moyens de X)** En application des articles 1641 et suivants du code civil, la société X expose que des désordres (apparition de dysfonctionnements et bruits suspects peu de temps après son acquisition) affectent la moto et la rendent impropre à l'usage auquel elle était destinée, à savoir l\'activité de livraison express de ses clients.*
>
> *Outre la résolution de la vente, la société X sollicite l'indemnisation, en application de l'article 1645 du code civil, de son préjudice financier (frais engendrés par l'immobilisation du véhicule), dans la mesure où elle estime que le vendeur avait nécessairement connaissance des vices présentés par le véhicule au moment de la vente et où elle ne l'aurait pas acquis si elle en avait eu connaissance.*
>
> *Subsidiairement, au visa de l'article 1133 du code civil, elle soutient qu\'elle a été victime d\'une erreur sur les qualités substantielles de ce véhicule destinée à effectuer des livraisons pour sa clientèle en ce que Monsieur Y ne l'a pas informé lors de la transaction des antécédents du véhicule.*
>
> *En toute hypothèse, même en cas de nullité pour erreur, la société X demande l'allocation des dommages et intérêts susvisés.*
>
> ***(Prétentions de Y)** Aux termes de ses dernières conclusions signifiées le 2 juin 2017, Monsieur Y sollicite le rejet de l\'ensemble des demandes et reconventionnellement la condamnation de la société X à lui payer la somme de 2 000 euros en application des dispositions de l'article 700 du code de procédure civile ainsi qu'aux dépens avec application des dispositions de l'article 699 du code de procédure civile.*
>
> ***(Moyens de Y)** Monsieur Y fait valoir que la vente ne peut être résolue car la société X ne rapporte pas la preuve que les vices qu'elle allègue sont de nature à rendre le véhicule impropre à sa destination.*
>
> *Il s'oppose enfin à la nullité du contrat, faisant valoir qu\'à sa connaissance, le véhicule n\'a jamais connu de dysfonctionnement ou d\'avarie.*
>
> ***Autre hypothèse :** si une question de procédure est soulevée, la rédaction sera la suivante :*
>
> ***(Prétentions de la société X)** Dans ses dernières écritures signifiées le 10 avril 2017, la société X conclut à la recevabilité de ses demandes et sollicite\... **On termine alors sur les autres prétentions.***
>
> ***(Moyens de la société X)** En réponse à la fin de non-recevoir opposée par Monsieur Y, la société X soutient que ... **Suivent les moyens au fond**.*
>
> ***(Prétentions de Monsieur Y) Aux termes de ses dernières conclusions signifiées le 2 juin 2017,** Monsieur Y demande que la société X soit déclarée irrecevable en ses demandes ... **Suivent alors les autres prétentions au fond du défendeur.***
>
> ***(Moyens de Monsieur Y)** Monsieur Y fait valoir que ... **suivent les moyens au soutien de chacune de ses prétentions***

###### *En effet, dans les cas où le défendeur soulève une exception de procédure ou une fin de non-recevoir, il est* plus logique d\'aborder ces éléments avant les autres dans les moyens car c\'est dans cet ordre que commencera la discussion. Ensuite suivront les éléments débattus au fond.

> *Attention, néanmoins, cet ordre logique ne devra être retenu que dans la mesure où il ne tend pas à modifier l'objet du litige tel que voulu par les parties. Si une partie soulève une exception de procédure après s'être défendue sur le fond, il convient d'exposer cette exception après les moyens sur le fond car cette présentation a une incidence sur le sens de la décision puisque les exceptions de procédure , pour être recevables, doivent être soulevées avant toutes défenses au fond ou fin de non recevoir..*

###### *[En matière de contentieux familial]{.underline}*

> ***Contexte factuel** : reprise de l\'exemple précédent Madame Sophie Durand*

###### *Proposition de rédaction :*

###### *Dans ce type de contentieux, il pourra être possible de ne développer que les moyens liés à la demande en* divorce de manière à ne pas alourdir l\'exposé, de sorte que les autres moyens seront développés au stade de la discussion.

> *Par dernières conclusions signifiées le 24 septembre 2016, Madame Durand sollicite :*

- *le prononcé du divorce aux torts exclusifs de son époux,*

- *une somme de 5000,00 € au titre de l\'article 266 du code civil outre une somme de 5000,00 € au titre de l\'article 1382 du code civil,*

- *la fixation des effets du divorce à la date du 18 septembre 2009,*

- *le maintien des dispositions de l\'ordonnance de non-conciliation quant aux mesures liées aux enfants à l\'exception du droit de visite qui sera organisé dans un espace rencontre conformément à l\'ordonnance du juge de la mise en état ....*

> *Sur le fondement des dispositions des articles 242 et suivants du code civil, Madame Durand fait valoir que son époux a quitté le domicile conjugal en septembre 2012 pour s\'installer avec sa maîtresse avec laquelle il avait une relation débutée en juin 2011, ce dont attestent plusieurs témoins. Elle précise à cet égard que ces attestations, si elles ne sont pas conformes aux exigences de l\'article 202 du code de procédure civile, permettent d\'identifier leur auteur et sont suffisamment probantes.*
>
> *Elle indique par ailleurs que son époux a mis en péril les intérêts du ménage en contractant de nombreux prêts pour l\'achat de véhicules et de mobilier uniquement pour le bien-être de sa maîtresse, comme en attestent les nombreuses factures versées aux débats ainsi que les relevés bancaires .*
>
> *Par dernières conclusions signifiées le 18 octobre 2016, Monsieur Jean sollicite le rejet de la demande en divorce pour faute et sollicite reconventionnellement le prononcé du divorce aux torts partagés.*
>
> *Il fait valoir que les liens étaient distendus avec son épouse depuis de nombreuses années et conteste l\'existence d\'une relation adultère. A cet effet, il rappelle que les attestations produites sont irrégulières, puisque ne revêtant pas la signature de leur auteur et aucune pièce d\'identité n\'étant annexée. Il reconnaît avoir quitté le domicile conjugal compte tenu d\'un climat très conflictuel mais ce de manière concertée avec son épouse et non pour s\'installer avec une tierce personne. Il indique que Madame l\'insultait régulièrement devant les enfants et lui manquait de respect devant des tiers, ce dont attestent de nombreuses personnes.*

# FICHE IV: LA DISTINCTION ENTRE MOYENS ET ARGUMENTS

> **DEFINITION**
>
> Le moyen n\'a pas de définition légale mais il peut être décrit comme « un *raisonnement* qui, partant d\'un fait, d\'un acte ou d\'un texte, *aboutit à une conclusion juridique propre à justifier une prétention* présentée en demande ou en défense »^7^.
>
> Il peut donc être constitué d\'une considération de droit (moyen de droit) ou d\'une circonstance de fait (moyen de fait) venant au soutien d\'une prétention émise par une partie ou en réplique à une prétention adverse, sa caractéristique principale tenant au fait que « *l\'énonciation en cause s\'insère dans un raisonnement juridique* c\'est à dire que les conclusions tirent, en droit, des conséquences de cette énonciation »^8^, conséquences de nature à justifier la prétention, qu\'elle soit présentée en demande ou en défense.
>
> Ainsi, à la différence de l'argument, le moyen tend à la production d'un effet juridique et donc à l'application de règles juridiques. A l'inverse, l'argument est un simple élément de discussion sans caractère opérant sur l'application desdites règle juridiques. L\'allégation est elle-même une sous-catégorie de l\'argument et consiste en une affirmation qui n'est assortie d\'aucune offre de preuve.
>
> **INTERÊT DE LA DISTINCTION**
>
> La distinction à opérer entre les moyens et les arguments est certaine en ce que :

- Si les parties ont l'obligation de présenter leurs moyens de droit et de fait dans l'acte introductif d'instance^9^ et, en procédure écrite ou orale (dans ce dernier cas, seulement si les parties sont toutes représentées ou assistées et dans le cadre d'une mise en état simplifiée prévue par l'article 446-2 al. 2 du CPC), dans leurs conclusions ou leurs dernières conclusions, cette obligation ne porte que sur les moyens, à l'exclusion des arguments ;

- Dans cette hypothèse, les moyens doivent, à compter du 11 mai 2017, être distingués s'ils sont nouveaux et être invoqués dans la discussion au soutien des prétentions sous peine de ne pas être examinés par le juge^10^, ce qui renforce l'importance de bien les identifier ;

- L'obligation du juge consiste dès lors, en application de l'article 455 du code de procédure civile, à faire un exposé succinct des prétentions respectives des parties et de leurs moyens et à répondre auxdites prétentions et aux moyens, à l'exclusion des arguments ;

> *^7^* Définition donnée dans l\'ouvrage « Droit et pratique de la cassation en matière civile », LexisNexis, édition de juin 2012, page 220
>
> ^8^ « Droit et pratique de la cassation en matière civil », LexisNexis, édition de juin 2012, page 220.
>
> ^9^ L'assignation contient, à peine de nullité, « l'objet de la demande avec un exposé des moyens en fait et en droit » (art. 56 2° CPC), même si cette mention n'est sanctionnée que par une nullité de forme (Civ. 2^ème^, 27 juin 2013, n° 12-20929) ; de même, doivent comporter un « exposé sommaire des motifs » tant la déclaration au greffe devant le tribunal d'instance (art. 843 CPC), que la requête devant le juge aux affaires familiales (art. 1137 et 1136-3 CPC, sous réserve de la demande initiale en divorce qui ne peut mentionner les faits à l'origine de la demande ni, dans le divorce contentieux, le fondement juridique de la demande, art. 1090 et 1106 CPC).
>
> ^10^ Articles 753 et 446-2 al 2 CPC dans leur nouvelle version issue du décret n° 2017-892 du 6 mai 2017.

- La possibilité pour le juge de soulever d'office un moyen est logiquement réservée aux moyens soit de fait (si du moins le fait est dans le débat même s'il n'a pas été spécialement invoqué par les parties, art. 7 al. 2^ème^ CPC) soit de droit, sous réserve du respect du principe de la contradiction^11^ ;

- Si les arguments, qui ne tendent à produire aucun effet juridique, encombrent souvent les actes introductifs d'instance et les conclusions des parties, pour autant ils n'ont pas à être repris par le juge dans la partie exposé du litige de son jugement et n'appellent, dans la motivation du même jugement et a fortiori dans le dispositif, aucun développement ni aucune réponse.

> Aussi, la distinction est essentielle à la qualité de l'analyse attendue du juge et de sa décision. En effet,

- La qualité de l'exposé du litige qui, entre autres caractères, doit être synthétique et complet sur les prétentions et moyens mais sur les seules prétentions et les seuls moyens, dépend nécessairement de la pertinence de cette distinction préalable entre moyens et arguments ; un exposé du litige mentionnant y compris de simples arguments ne peut être l'exposé « succinct » qu\'impose l'article 455 du code de procédure civile ;

- La qualité de la motivation elle-même dépend de la rigueur de l'exercice intellectuel d'analyse et de synthèse au stade de l\'exposé du litige ; un tel exposé du litige encombré d'arguments ne prépare pas utilement le travail intellectuel du juge dans la motivation, où une réponse inutile aux simples arguments risque de masquer les moyens, leur pertinence voire même de conduire le juge à une absence de réponse à l'un ou l'autre de ceux-ci ; aussi, la motivation va perdre en cohérence, en pertinence et pourra même s\'avérer incomplète.

> **CRITERES DE DISTINCTION**
>
> Le moyen vient au soutien des prétentions et, qu'il soit de droit ou de fait, s'inscrit dans un raisonnement juridique, par opposition à l'argument.
>
> Le juge doit donc rechercher, à la lecture des écritures des parties, si celles-ci attribuent ou non un effet juridique à l'élément invoqué au soutien de telle ou telle prétention.
>
> Dans la négative, cet élément n'est qu'un simple argument voire même, s'il ne repose sur aucune offre de preuve, qu'une simple allégation, que le juge n'a pas à rapporter dans l'exposé du litige et auxquels il n'a pas à répondre.
>
> Ainsi, dans une action notamment en paiement d\'un solde de créance ou en reconnaissance d\'une servitude, le défendeur qui à titre subsidiaire fait valoir le temps écoulé depuis la naissance de la prétendue créance ou celle de la prétendue servitude, sans aucun usage ni aucune revendication de celle-ci, doit encore développer la conséquence juridique à tirer de ce fait, à le supposer établi, sur la solution du litige et spécialement faire valoir l\'extinction de ladite créance ou de ladite servitude pour cause de prescription. Ne le faisant pas, il ne présente là qu\'un moyen inabouti et donc un élément auquel le juge n\'est pas tenu de répondre ni même d\'exposer dans la partie du jugement réservée à l\'exposé du litige.
>
> ^11^ Sur cette question de l'office du juge, cf la fiche du présent document réservée à cette question.
>
> *Exemple 1 : la SCI X et Y ne peuvent reprocher utilement aux juges du fond d\'avoir déclaré les intervenants à l\'instance recevables et d\'avoir accueilli leurs demandes au motif qu\'il n\'aurait pas été répondu au fait, soutenu dans les conclusions de la SCI précitée et de Y, que depuis 40 ans l\'immeuble litigieux avait été affecté à l\'usage de bureau. En effet, la SCI X et Y ne tirant pas de conséquences juridiques de ce fait allégué par elles et tenant à l\'affectation de l\'immeuble, le juge du fond n\'avait pas à répondre à leurs conclusions.* ^12^
>
> *Exemple 2 : une partie demande condamnation solidaire de deux défendeurs, Monsieur X et Madame X, au paiement d'une somme au motif que la dette est une dette ménagère, contractée pour les besoins du ménage par l'un des époux, en l\'espèce Madame X.*
>
> *Le caractère ménager de la dette soutenu par le demandeur est assurément un moyen auquel le juge doit répondre, puisqu\'en effet son énonciation s\'inscrit dans un raisonnement tendant à faire reconnaître l\'obligation solidaire à la dette des deux époux.*
>
> *Monsieur X conteste le caractère ménager de la dette, en ce qu'elle était destinée à couvrir une dépense de loisir de son épouse et non une dépense de la famille ce, d\'autant qu'à l'époque les époux étaient séparés et en procédure de divorce.*
>
> *Seul l'élément premier tiré de la nature de la dépense (dépense de loisir ou dépense pour l'entretien du ménage ou les besoins des enfants au sens de l'article 220 du code civil) est un moyen et doit à ce titre être exposé et appeler une réponse dans la motivation. La séparation et l'instance en divorce, évoquées sans qu'aucun effet juridique n'en soit tiré, ne constituent qu'un argument, voire qu\'une allégation si elles ne sont assorties d'aucune preuve ni offre de preuve, et ne viennent en fait qu\'illustrer l\'unique moyen tenant à la qualification de la dépense.*
>
> Ainsi, la Cour de cassation rappelle que le juge du fond n\'est pas tenu de suivre les parties dans le détail de leur argumentation, ni de s\'expliquer précisément sur chacun des faits allégués, sur chacun des documents produits ni a fortiori de répondre à une simple allégation dépourvue d\'offre de preuve.^13^
>
> De plus, le juge n\'est pas tenu de répondre à une considération dépourvue d\'influence juridique et non déterminante sur la solution juridique et comme telle inopérante.^14^
>
> *Exemple précité 2 : le dernier élément invoqué en défense par Monsieur X, tiré de l\'existence prétendue d\'une procédure de divorce au jour de l\'engagement de la dépense, est un élément au surplus inopérant, en ce que l'obligation solidaire des époux dure jusqu'à ce que le divorce soit opposable aux tiers par accomplissement des formalités de mentions en marge, prescrites par les règles de l'état civil. Or, à supposer que Monsieur X ait tiré une conséquence de cette énonciation, à savoir une inapplication des règles de la solidarité ménagère motif pris de la séparation du couple matérialisée par une procédure de divorce, l\'énonciation en cause restait sans caractère déterminant sur la solution du litige de sorte que le juge du fond n\'était pas même tenu, dans un tel cas d\'espèce, de répondre à cet élément des conclusions dépourvu d\'influence juridique.*
>
> Non seulement un fait ou un acte peuvent être évoqués sans que la partie qui en fait état n\'en tire aucune conséquence juridique sur la solution du litige ni ne les inscrive dans un raisonnement juridique, de
>
> *^12^* En ce sens, Civ. 3^ème^, 8 février 1995, n° 92-18.959.
>
> ^13^ En ce sens, notamment Civ. 2^ème^, 21 juin 2001, n° 99-20.384.
>
> ^14^ En ce sens notamment Civ. 1^ère^, 12 juin 2001, n° 99-13.509.
>
> sorte que ce fait ou cet acte ne sont au mieux que des moyens inaboutis auxquels le juge n\'a pas à répondre, mais un texte peut parfois être visé par une partie dans ses conclusions, notamment en fin de conclusions juste avant le rappel de ses prétentions, sans qu\'aucun raisonnement juridique n\'ait été articulé par elle sur la base de cet article. Aussi, ce seul visa ne peut constituer un moyen de droit et le juge n\'a pas à y répondre.
>
> *Exemple 3 : soit une action fondée sur les mécanismes de la responsabilité contractuelle de l'article 1792-4 du code civil et, subsidiairement, sur le manquement à l'obligation de délivrance pour défaut de conformité du bien livré en violation de l'article 1604 du code civil. La partie demanderesse vise par ailleurs, dans le dispositif de ses conclusions, l'article 1641 du code civil mais ne réserve aucun développement à cet article.*
>
> *En fondant expressément son action sur l'article 1792-4 et à défaut sur l'article 1604 du code civil, le demandeur a ôté toute portée au simple visa de l'article 1641 dans le dispositif de ses conclusions, de sorte que le juge n'a pas à statuer sur les dispositions de cet article 1641 du code civil.* ^15^
>
> La distinction est parfois subtile. Toutefois il est fréquent que, précisément, lors de la rédaction de la motivation et de la recherche d'une réponse à l'élément dont a priori la nature, soit de moyen soit d\'argument, n\'était pas évidente, il apparaisse qu\'il n'était destiné à produire aucun effet juridique autonome et qu\'il ne constituait qu'une digression ou tout au plus une façon pour la partie d'illustrer son propos, le moyen devant se résumer autrement.
>
> *Exemple précité 2 : l\'élément invoqué en défense par Monsieur X, tiré de l\'existence prétendue d\'une procédure de divorce au jour de l\'engagement de la dépense, n\'est en réalité qu\'une façon d\'appuyer le fait que la dépense, engagée par son épouse, ne pouvait être une dépense ménagère au sens de l\'article 220 du code civil et était contractée pour d\'autres besoins que ceux de la famille qui précisément se disloquait et n\'était plus, selon lui, au centre des préoccupations de l\'épouse.*
>
> Si persiste un doute sur la nature soit de moyen soit d\'argument invoqué par telle ou telle partie, il y a lieu de tenir l\'élément en cause pour un moyen, donc de l\'exposer et d\'y répondre dans la motivation. En effet, si le juge n\'est pas tenu de répondre aux simples arguments, qui souvent prennent la forme de moyens inaboutis, ni a fortiori aux simples allégations, à l\'inverse il doit répondre aux éléments qui effectivement constituent des moyens, plus précisément encore à tous les moyens en demande quand il rejette la prétention et à tous les moyens en réplique quand il fait droit à la prétention. Pour ne pas affaiblir la qualité de la décision il est donc préférable, dans le doute, d\'analyser la considération ou la circonstance invoquées comme un moyen.
>
> **RECOMMANDATIONS**
>
> Au stade de l\'exposé du litige, le juge doit garder à l\'esprit l\'exigence de synthèse posée à l\'article 455 du Code de procédure civile. S\'il se contente de recopier les conclusions des parties ou des passages de celles-ci sans s\'approprier les éléments du litige ni les résumer dans ses propres termes, il sera inévitablement conduit à reproduire ce qui n\'est qu\'argument ou allégation et se privera, au détriment de la qualité de la décision, du travail intellectuel indispensable de recherche de la nature des éléments invoqués par les parties et de sélection des seuls moyens.
>
> L'importance des développements à consacrer à tel ou tel moyen dans l'exposé du litige peut varier en fonction du moyen, de sa complexité mais aussi de la façon dont il y sera répondu dans la motivation. Il
>
> ^15^ En ce sens, Civ. 3^ème^, 28 mars 2012, n° 11-11.391.
>
> est inutile en effet de réserver de longs développements à tel moyen dans l'exposé, quand les mêmes développements doivent être repris dans le corps de la motivation. En ce cas, un simple énoncé du moyen suffira en première partie du jugement.
>
> *[Exemple :]{.underline} soit une action engagée pour de prétendus désordres par un particulier, maître de l\'ouvrage, contre le professionnel auquel il a eu recours pour des travaux entrepris sur son immeuble ; a fortiori si les désordres invoqués sont nombreux et donnent lieu à de longues descriptions et de longs développements de la part des parties, il est préférable, dans l\'exposé des moyens, de se limiter à rappeler le fondement juridique de l\'action (ex : garantie décennale) et la nature des désordres invoqués, de citer de façon synthétique leurs lieux respectifs de situation et de rapporter très sommairement la description qui en est faite par le demandeur à l\'instance.*
>
> *L\'exposé des moyens du demandeur peut alors se réduire à ceci : « X fait valoir l\'existence de différents désordres au niveau d\'une part de... se traduisant par différentes fissures, d\'autre part de... consistant en des traces d\'infiltration importantes... et soutient que ces désordres relèvent de la garantie décennale de l\'article 1792 du code civil ».*
>
> *Dans la motivation, chacun de ces désordres sera repris dans le détail et ils donneront alors lieu, éventuellement sur la base des constatations d\'un rapport d\'expertise produit aux débats, à des descriptions et analyses détaillées. Ces analyses se comprendront d\'autant mieux que précisément le rappel des désordres et leur description seront réalisés dans le même trait de temps (pour une proposition de rédaction de la motivation dans une telle hypothèse, cf. infra fiche sur la motivation).*
>
> De même, l\'exposé des moyens se rapportant aux questions de fond pourra être très synthétique quand notamment, dans la motivation, à raison d\'une exception de nullité de l\'assignation ou d\'une fin de non recevoir qui seraient fondées, le juge rend une décision mettant fin à l\'instance sans qu\'il y ait lieu de se prononcer sur ces autres questions de fond.

## *EXEMPLE D\'UN EXERCICE DE SELECTION DES MOYENS DANS UN EXPOSE* DU LITIGE

> L'agence TIM, considérant comme fautif le comportement de Madame Dupont qui lui avait donné mandat de vente d'un immeuble, l'a faite assigner devant le tribunal de grande instance de MACON par acte du 4 juin 2015 aux fins de paiement de l'indemnité forfaitaire prévue au contrat.
>
> **[Prétentions telles qu'elles ressortent des dernières conclusions de l'agence immobilière :]{.underline}**
>
> Dans ses dernières écritures signifiées le 24 mars 2016, l'agence TIM sollicite, sous le bénéfice de l'exécution provisoire, la condamnation de Madame Dupont au paiement des sommes de 10 000 € à titre de dommages et intérêts et 3 000 € en application de l'article 700 du code de procédure civile, outre sa condamnation aux entiers dépens, recouvrés directement par la société d'avocats.
>
> **[Moyens et/ou arguments et/ou allégations : quels sont les moyens ?]{.underline}**
>
> Au soutien de ses prétentions, et au visa des articles 1984 et 1134 du code civil, dans leur version en vigueur lors de l'introduction de l'instance, l'agence TIM fait valoir que Madame Dupont a commis une faute contractuelle d'une part en omettant de l'aviser, dans les formes prévues au contrat, de son intention de ne pas donner suite à l'offre qui lui avait été présentée, et d'autre part en ne lui notifiant pas dans le délai prévu les coordonnées exactes de l'acquéreur avec lequel elle entendait finalement contracter.
>
> Elle expose qu'elle a avisé dès le 23 avril Madame Dupont de ce qu'elle avait trouvé un acquéreur et que cette dernière a téléphoné à l'agence le 28 avril pour l'informer qu'elle ne donnait plus suite au mandat. Elle a confirmé sa position par courrier en date du 30 avril.
>
> Elle ajoute qu'elle a rencontré Madame Dupont le 12 mai et que cette dernière devait rappeler pour indiquer la date de libération de l'appartement.
>
> Elle s'estime donc fondée à obtenir, comme prévu au contrat de mandat, une indemnité forfaitaire d'un montant égal à la rémunération qu'elle aurait perçue si la vente s'était réalisée. Elle considère, en outre, que cette absence de bonne foi dans l'exécution du contrat justifie le versement à son profit de l'intégralité de l'indemnité forfaitaire prévue au contrat.
>
> Elle s'oppose à une quelconque réduction de cette indemnité, considérant s'être montrée particulièrement diligente dans la recherche puis la découverte d'un acquéreur sérieux au bénéfice de Madame Dupont. Selon l'agence immobilière, cette rapidité démontre son efficacité pour parvenir au résultat attendu, seul élément qui doit être pris en compte, et ce d'autant plus que l'agence a réalisé un travail en amont, a assumé des charges.
>
> Elle estime avoir subi du fait du revirement de cette dernière un préjudice financier certain et non seulement éventuel dès lors qu'elle disposait d'une offre d'achat ferme et non assortie d'une quelconque condition suspensive.
>
> **[Analyse des éléments invoqués par le demandeur, l'agence TIM :]{.underline}**
>
> *Elle expose qu'elle a avisé dès le 23 avril Madame Dupont de ce qu'elle avait trouvé un acquéreur et que cette dernière a téléphoné à l'agence dès le 28 avril pour l'informer qu'elle ne donnait pas suite au mandat :*
>
> ce sont des allégations car la demanderesse ne fournit pas d'éléments de preuve à l'appui de ce qu'elle affirme.
>
> *Elle ajoute qu\'elle a rencontré Madame DUPONT le 12 mai et que cette dernière devait rappeler pour indiquer la date de la libération de l\'appartement* : là encore, il s'agit d'une allégation car aucun élément de preuve n'est produit au soutien de cette affirmation.
>
> *Selon l'agence immobilière, cette rapidité démontre son efficacité pour parvenir au résultat attendu, seul élément qui doit être pris en compte, et ce d'autant plus que l'agence a réalisé un travail en amont, a assumé des charges* : il s'agit d'un argument car l'agence n'en tire aucune conséquence juridique.
>
> **[Prétentions de Madame DUPONT]{.underline}** :
>
> Dans ses dernières conclusions signifiées le 18 janvier 2016, Madame DUPONT sollicite à titre principal le rejet de toutes les prétentions de l'agence TIM.
>
> Subsidiairement, elle demande à ce que l'indemnité réclamée soit qualifiée de clause pénale et réduite à un euro symbolique.
>
> En tout état de cause, elle sollicite la condamnation de la demanderesse au paiement d'une somme de 2.500
>
> € en application de l'article 700 du code de procédure civile.
>
> **[Moyens et/ou arguments et/ou allégations : quels sont les moyens ?]{.underline}**
>
> Madame DUPONT conteste avoir commis une faute contractuelle engageant sa responsabilité, dès lors qu'en consentant à l'agence un mandat sans exclusivité, elle se réservait légitimement la possibilité de trouver un acquéreur par ses propres moyens.
>
> Elle indique avoir téléphoniquement informé l'agence de ce qu'elle avait trouvé un acquéreur. Elle ajoute qu'il importe peu à cet égard qu'elle n'ait finalement pas conclu la vente envisagée en raison de la non-obtention d'un prêt par l'acquéreur potentiel, Madame Mama ACHACHERA.
>
> Subsidiairement, au visa de l'article 1152 du code civil, dans sa version en vigueur lors de l'introduction de l'instance, elle sollicite la réduction de l'indemnité forfaitaire contractuellement prévue.
>
> Elle considère à cet égard que cette somme est disproportionnée par rapport au préjudice réellement subi par l'agence et qu'il ne s'agit, en outre, que d'un préjudice éventuel, rien n'indiquant que la vente projetée se soit réalisée. Madame DUPONT considère que son montant est manifestement excessif au regard du peu de temps consacré par l'agence au mandat, en l'espèce moins de quinze jours.
>
> **[Analyse des éléments invoqués en défense par Madame DUPONT]{.underline}** :
>
> *Elle indique avoir téléphoniquement informé l'agence de ce qu'elle avait trouvé un acquéreur* : c'est une allégation car aucune preuve n'est apportée par la défenderesse.
>
> *Elle ajoute qu'il importe peu à cet égard qu'elle n'ait finalement pas conclu la vente envisagée en raison de la non-obtention d'un prêt par l'acquéreur potentiel, Madame Mama ACHACHERA* : c'est un argument car la non-obtention du prêt par Madame ACHACHERA n'a pas de conséquence sur la question de la rupture fautive ou non du mandat.
>
> *Madame DUPONT considère que son montant est manifestement excessif au regard du peu de temps consacré par l'agence au mandat, en l'espèce moins de quinze jours* : c'est un argument car le préjudice subi est en lien avec l'absence de vente réalisée entre la demanderesse et les acquéreurs présentés par l'agence, et, non constitué par le travail effectué par l'agence pour rechercher un acquéreur.

# FICHE V : LE PROCESSUS D\'ANALYSE ET DE RAISONNEMENT

> Trois phases, aussi essentielles l\'une que l\'autre, doivent se succéder et être réalisées avec une plus ou moins grande facilité selon le niveau de difficulté juridique du dossier et la qualité des conclusions des parties : la prise en main et l\'analyse du dossier (A), la construction du raisonnement et la recherche des solutions juridiques (B), l\'élaboration du plan du jugement (C).

#### A - LA PRISE EN MAIN ET L\'ANALYSE DU DOSSIER

##### Comment lire et que lire ?

> \*Comment lire un dossier :
>
> Un dossier se lit à l'envers. Il débute généralement par les pièces de procédure que sont l'assignation, la requête ou la déclaration au greffe (tamponnées et datées voire horodatées par le greffe : important pour déterminer l'antériorité de la saisine dans les contentieux internationaux ou dans les cas de litispendance). Selon le contentieux, y figurent des éléments essentiels comme ceux relatifs à l'état civil des parties.
>
> **Procédure écrite** : après l'assignation, suivent normalement la constitution de l'avocat, les conclusions des avocats avec les bordereaux de communication des pièces (sauf l'hypothèse de la mise en état électronique), avec le calendrier des orientations ou renvois du juge de la mise en état jusqu'à l'ordonnance de clôture (et ses éventuelles révocations). Le dossier se termine sur la note d'audience.
>
> Pour les dossiers dans lesquels l'assignation est délivrée à compter du 11 mai 2017, l'article 753 alinéa 1 du code de procédure civile est modifié en ce que doivent être indiquées désormais, pour chaque prétention formulée dans les conclusions, les pièces sur lesquelles elle est fondée et leur numérotation ; en outre *« les conclusions comprennent distinctement un exposé des faits et de la procédure, une discussion des prétentions et des moyens ainsi qu'un dispositif récapitulant les prétentions. Les moyens qui n'auraient pas été formulés dans les conclusions précédentes doivent être présentés de manière formellement distincte. Le tribunal ne statue que sur les prétentions énoncées au dispositif et n'examine les moyens au soutien de ces prétentions que s'ils sont invoqués dans la discussion* ».
>
> Cette structuration des écritures des parties imposée par l'article 753 du code de procédure civile modifié par le décret n° 2017-892 du 6 mai 2017 doit en principe simplifier le travail de prise en main et d'analyse du dossier puisque les prétentions qui saisissent le juge figurent désormais exclusivement au dispositif, et qu'il n'examine que les moyens invoqués dans la discussion au soutien de ces prétentions.
>
> **Procédure orale** : le dossier peut n'être composé que de la requête ou de la déclaration au greffe. Il peut être complété d'écritures transmises par les parties avant l'audience ou déposées à l'audience. En ce cas, les parties pourront s'y référer à l'audience ou les compléter. La note d'audience revêt une importance particulière en procédure orale. Rédigée par le greffier sous le contrôle du juge, elle reprend les demandes des parties ainsi que les moyens développés à l\'audience ou fait mention de ce que telle partie, à cette audience, se réfère à ses écritures.
>
> NB : Il doit être noté que le décret du 6 mai 2017 n° 2017-892 précité a également prévu la même structuration des écritures en procédure orale en modifiant l'article 446-2, alinéa 2 du code de procédure civile dans les cas de renvoi d'une affaire par le juge avec mise en place d'un calendrier des échanges et de communications entre les parties, lorsque toutes les parties comparantes formulent leurs prétentions et moyens par écrit et sont assistées ou représentées par un avocat (il s'agit alors d'une forme de procédure écrite simplifiée) .
>
> Puis seront adjoints les dossiers des avocats (composés soit des seules pièces soit de côtes de plaidoirie et des pièces), étant précisé que la lecture des cotes de plaidoiries revêt un intérêt procédural très limité. En effet, seules les écritures, soit régulièrement notifiées aux autres parties en procédure écrite, soit reprises contradictoirement à l\'audience en procédure orale, sont dans les débats. Aussi, si les cotes de plaidoirie développent un moyen nouveau, a fortiori une prétention nouvelle, qui ne sont pas dans les débats, le juge ne peut que les ignorer faute d\'en être régulièrement saisi (a fortiori pour les affaires introduites après le 11 mai 2017, en procédure écrite, compte tenu des nouvelles prescriptions de l'article 753 du CPC).
>
> \*Que lire dans un dossier ?
>
> Lors de la prise en main du dossier, il n'est pas nécessaire de tout lire. Il convient de parcourir le dossier en sélectionnant les informations importantes. Or, l'intérêt de lire tel ou tel élément du dossier dépend de l'objectif poursuivi : si la première lecture a pour objectif la rédaction de l'exposé du litige, alors la vérification des dates des actes de procédure, de leur auteur et le contenu des dernières conclusions est utile. En revanche, la lecture du contenu d'un rapport d'expertise et des pièces des parties sera plus utile, dans un deuxième temps, pour rédiger la motivation du jugement.

##### Que sélectionner ?

> **Afin de préparer la formalisation de la décision, il est nécessaire de procéder à une lecture attentive et sélective du dossier.**
>
> **S\'agissant des faits,** leur version par les parties, complétée par une lecture des pièces, permet de se déterminer sur ceux d\'entre eux susceptibles de constituer les faits constants et pertinents à rapporter en première partie de jugement.
>
> **Toutefois,** les faits relevés lors d\'une première lecture des seules écritures des parties et/ou du seul procès-verbal d\'audience seront éventuellement à reprendre, pour y ajouter ou y retrancher, après une analyse complète du dossier en ce compris des pièces versées aux débats (tel fait pourra être rapporté et présenté par l\'une des parties comme constant, ne pas être contesté par la seconde et cette relation être contredite
>
> par l\'analyse des pièces ; tel autre fait, certes constant, pourra se révéler ne pas être pertinent, en ce qu\'il n\'est pas utile à la solution du litige).
>
> **S'agissant des éléments de procédure** : il faut uniquement reprendre l'acte introductif, sa date, vérifier les formes de citation du défendeur (importance sur la détermination du ressort), les éléments importants de la mise en état en procédure écrite (incidents), et concernant les rapports d'expertises et les enquêtes sociales, il convient de ne retenir que l'acte par lequel ils ont été ordonnés, la date du dépôt du rapport, l'identité de son auteur et un bref résumé de sa mission.
>
> En procédure écrite, on se réfère uniquement aux dernières conclusions (article 753 alinéa 3 dans sa rédaction actuelle et maintenue après le 11 mai 2017 : « *les parties doivent reprendre dans leurs dernières conclusions les prétentions et moyens présentés ou invoqués dans leurs conclusions antérieures. A défaut, elles sont réputées les avoir abandonnés et le tribunal ne statue que sur les dernières conclusions déposées*
>
> »). On vérifiera la date de l'ordonnance de clôture afin de s'assurer qu'aucune conclusion ou pièce n'a été déposée postérieurement à celle-ci.
>
> La lecture du bordereau de communication de pièces permet enfin de s\'assurer que les pièces contenues au dossier de telle partie ont bien été communiquées à la partie adverse et, qu\'inversement, les pièces listées au bordereau sont bien contenues au dossier.
>
> En procédure orale, sont pris en compte l\'acte introductif d\'instance (assignation, déclaration au greffe ou requête) et les éventuelles écritures postérieures du demandeur comme du défendeur, dans la mesure où leur auteur les a repris oralement à l\'audience ou s\'y est expressément référé, de même que les notes d\'audience prises par le greffier.
>
> **S\'agissant des prétentions et moyens des parties,** comme indiqué ci-dessus ce sont les dernières conclusions des parties en procédure écrite et les développements, souvent repris dans des écritures, soutenus à l\'audience en procédure orale, qui permettent de se déterminer.
>
> Leur recensement constitue un élément essentiel qui conditionne la qualité du raisonnement ensuite conduit par le juge.
>
> Il est au cœur du principe dispositif et impose au juge une grande rigueur afin de rester exhaustif et fidèle aux écritures des parties donc aux faits, demandes et moyens que celles-ci entendent apporter aux débats et soumettre au juge.
>
> **Aussi,** comme dans la suite de l\'analyse qui doit conduire à la construction de la motivation et à la prise de décision, il est essentiel de se doter d\'outils simples pour ce travail préparatoire à la rédaction.

##### Comment récapituler les éléments sélectionnés ? Suggestion : le tableau analytique

> La lecture du dossier se fait normalement sur la base de prise de notes, manuscrites ou dactylographiées. Il importe, a fortiori pour un dossier complexe, que celle-ci soit organisée. Aussi, on peut utilement présenter les éléments soit sous forme de fiches soit sous forme d\'un tableau analytique ainsi constitué :

+----------+-------------------------+----------+------------------+--------------------+------------------------------+
|          | > Prétentions formulées | > Moyens | > Moyens opposés | > Pièces analysées | > Solution et moyens retenus |
+==========+=========================+==========+==================+====================+==============================+

+---------------+----------+-----+----------+----------+----------------+
| > X demandeur |          |     |          |          |                |
+===============+==========+=====+==========+==========+================+
| > Y défendeur |          |     |          |          |                |
+---------------+----------+-----+----------+----------+----------------+
| > Z défendeur |          |     |          |          |                |
+---------------+----------+-----+----------+----------+----------------+

> Les deux dernières colonnes de ce tableau seront complétées au fur et à mesure de l\'élaboration du raisonnement à tenir sur chacune des questions juridiques posées par le dossier.

#### B - LA CONSTRUCTION DU RAISONNEMENT ET LA RECHERCHE DES SOLUTIONS JURIDIQUES

> Construire le raisonnement et rechercher les solutions juridiques suppose une démarche consistant à identifier

- Les questions juridiques posées par la ou les prétentions des parties

- La ou les règles de droit susceptibles de trouver application relativement à ces questions

- Les conditions d\'application de ces règles Puis à

- Analyser les pièces

- Vérifier cette application des règles aux faits de la cause, afin de se déterminer et de conclure sur la solution juridique.

> Ce travail d\'identification, d\'analyse et de recherche est à mener dans un cadre contraint par :

- L'objet du litige, défini par les prétentions des parties, que le juge ne peut pas modifier (art. 4 CPC)

- Le fondement juridique ou les moyens de droit s'ils sont expressément invoqués par les parties et que le juge se doit d\'examiner

- L'ensemble des moyens de fait des parties, auxquels le juge doit répondre en tout ou partie

- Le principe de la contradiction, que le juge doit respecter et faire respecter (art. 16 CPC)

- Les règles gouvernant l\'office du juge, qui notamment doivent le conduire à qualifier ou restituer aux faits et actes litigieux leur exacte qualification, à rechercher les conditions d\'application de la règle invoquée et les règles de preuve applicables.

> Aussi, une prétention a priori simple peut renvoyer à plusieurs questions, à autant de règles et à un raisonnement plus ou moins élaboré selon les pièces produites aux débats et les moyens en défense et en demande.

+----------+---------------+----------+-----------+-------------+------------------+
|          | > Prétentions | > Moyens | > Moyens  | > Pièces    | > Solution et    |
|          | >             |          | >         | >           | >                |
|          | > formulées   |          | > opposés | > analysées | > moyens retenus |
+==========+===============+==========+===========+=============+==================+

+---------------+--------------------------+----------------------------------------------------------------------------------+--------------------------------------------------------------+-------------------------+-----------------------------------------------------------------------------------------------------------------------------------------------------------------+
| > X demandeur | > Paiement solde du prix | > Contrat liant les parties                                                      | > Absence de contrat écrit et donc d\'engagement contractuel | > Chèque d'acompte      | > Le chèque est un commencement de preuve par écrit complété par divers courriers (1362 CC, ancien                                                              |
|               |                          |                                                                                  |                                                              | >                       | >                                                                                                                                                               |
|               |                          |                                                                                  |                                                              | > Courrier du défendeur | > article 1347                                                                                                                                                  |
+===============+==========================+:================================================================================:+==============================================================+=========================+:===============================================================================================================================================================:+
|               |                          | > Aucune preuve des prétendues inexécution ou mauvaise exécution des prestations | > Pas d\'exécution des prestations                           | > Aucune pièce          | > L\'exception d\'inexécution invoquée en défense n\'est pas justifiée alors que c\'est à la partie qui l\'invoque de la prouver ( 1353 CC, ancien article 1315 |
|               |                          |                                                                                  |                                                              |                         | >                                                                                                                                                               |
|               |                          |                                                                                  |                                                              |                         | > al.2)                                                                                                                                                         |
+---------------+--------------------------+----------------------------------------------------------------------------------+--------------------------------------------------------------+-------------------------+-----------------------------------------------------------------------------------------------------------------------------------------------------------------+

> *Reprenons les questions juridiques et les règles auxquelles elles renvoient :*

+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
| > *[Conclusion intermédiaire]{.underline} : la preuve de ce qui fonde l\'obligation au paiement est rapportée en demande.*                                                                                                 |
+============================================================================================================================================================================================================================+
|                                                                                                                                                                                                                            |
+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
| > *Comment s\'analyse le moyen de défense tendant à soutenir l\'absence d\'exécution des prestations ?*                                                                                                                    |
| >                                                                                                                                                                                                                          |
| > *Une exception d\'inexécution. Qui doit prouver quoi ? C\'est à celui qui invoque cette exception de rapporter la preuve des*                                                                                            |
| >                                                                                                                                                                                                                          |
| > *faits susceptibles de la fonder (application jurisprudentielle de l\'article - 1353 al. 2 CC-ancien article 1315 al.2) Cette preuve est-elle rapportée en défense ? Elle ne résulte pas des pièces versées aux débats.* |
+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
|                                                                                                                                                                                                                            |
+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+

> *N.B : si le défendeur ne comparaît pas ou s\'en rapporte à justice sur la demande principale en paiement (ce qui constitue une forme de contestation) et éventuellement formule à titre subsidiaire une demande reconventionnelle de délais de paiement, le raisonnement à tenir par le juge est exactement le même.*
>
> Cet exemple nous montre que le juge ne peut se dispenser de:

- Qualifier les faits (exception d\'inexécution) et actes (contrat) juridiques invoqués

- Rechercher les règles juridiques et de preuve qui s\'y attachent et qui sont déterminantes pour la solution juridique

- Tenir un raisonnement ordonnancé qui, logiquement, restituera le plan de la motivation sur ce chef de prétention que constitue la demande principale en paiement :

> 1°) sur la preuve du contrat
>
> 2°) sur l\'exécution de la prestation 3°) sur le solde de prix demandé.
>
> Il peut être construit un syllogisme juridique pour chacune de ces questions comme il peut être combiné plusieurs syllogismes successifs en un. Dans les deux cas, la conclusion sera la même et donnera la solution à la demande principale en paiement, solution ensuite reproduite au dispositif du jugement.

#### C - L\'ORDONNANCEMENT DES QUESTIONS ET L\'ÉLABORATION DU PLAN DU JUGEMENT

> **La construction d\'un plan détaillé et apparent**
>
> Le plan du jugement suivra très souvent l\'ordre logique d\'examen des questions précédemment énoncées dans la fiche «motivation» en sa partie C/ (mesures d\'administration judiciaire, exceptions de procédure, fins de non-recevoir, prétentions au fond du demandeur puis prétentions au fond du défendeur puis dépens/article 700/exécution provisoire), sous les réserves exposées dans cette même fiche.
>
> Toutefois, pour l\'examen d\'une même prétention, le juge peut devoir parfois décomposer son raisonnement et trancher successivement différentes questions, en construisant autant de syllogismes juridiques, avant de parvenir à poser la solution finale tendant à faire droit ou à rejeter la prétention en question.
>
> *[Ainsi d\'une demande principale en exécution forcée d\'un contrat, qui soulève en défense des contestations sur la]{.mark} [qualification de ce contrat, subsidiairement sur son interprétation quant aux obligations respectives des parties, par]{.mark} [ailleurs sur la réalité de la non-exécution, enfin sur la possibilité d\'une exécution en nature.]{.mark}*

- *[donner ou restituer l\'exacte qualification du contrat en composant une sous-partie ainsi intitulée 1°) « sur la]{.mark} [qualification du contrat en cause »]{.mark}*

- *[interpréter la ou les clauses litigieuses du contrat en composant une seconde sous-partie 2°) « sur les]{.mark} [obligations respectives des parties prévues au contrat » ce, en rappelant la lettre du contrat et en recherchant la]{.mark} [commune intention des parties]{.mark}*

- *[vérifier la réalité de la prétendue inexécution du contrat par le défendeur dans une troisième sous-partie 3° «]{.mark} [sur l\'inexécution prétendue du contrat », sous-partie elle-même décomposée en un examen de la charge de la preuve]{.mark} [puis de la réalité de la prétendue inexécution]{.mark}*

- *[en cas d\'inexécution constatée, se prononcer dans une quatrième sous-partie 4°) « sur la possibilité de]{.mark} [réparation en nature » et, dans la négative, sur les conséquences à en tirer en l\'état des prétentions du demandeur.]{.mark}*

> Ce sont parfois les questions de fait elles-mêmes qui amènent à décomposer la motivation, pour l\'examen d\'une même prétention, en différentes sous-parties.
>
> *Ainsi, dans un litige de construction, sur la question première des désordres, la motivation peut être ainsi construite :*
>
> *«Aux termes de l\'article 1792 du code civil\... .*
>
> *En l\'espèce, X invoque différents désordres tant au niveau de... que de\... 1°) Sur les désordres au niveau de\...*
>
> *Il résulte du rapport d\'expertise judiciaire réalisée par... qu\'à cet endroit de l\'immeuble... (le rapport d\'expertise est alors repris en sa partie consacrée à la description par l\'expert desdits désordres et en l\'avis de l\'expert sur leur nature ; il en suit une analyse par le juge de ces désordres au regard des termes précités du rapport et de tous autres éléments de preuve produits aux débats, aux fins de les qualifier et de se déterminer sur leur nature et le régime juridique dont ils relèvent)*
>
> *2°) Sur les désordres au niveau de\...*
>
> *Il résulte du rapport d\'expertise judiciaire réalisée par... qu\'à cet endroit de l\'immeuble... (rappel des termes du rapport et analyse par le juge des pièces produites aux débats et notamment du rapport d\'expertise) En conséquence, \...*
>
> Aussi, pour faciliter la compréhension de la décision de même que sa relecture par le juge, il est très souvent utile de faire apparaître le plan de construction adopté, donc de numéroter les parties et les sous-parties de la motivation et de permettre au lecteur de les identifier très distinctement par des titres et des sous-titres insérés dans le corps de la motivation et marqués en caractères gras ou soulignés.
>
> Seuls les dossiers très simples, où la motivation ne porte que sur une question principale et sur les mesures accessoires, peuvent dispenser le juge de ce plan détaillé et facilement repérable.
>
> **L\'élaboration du plan : une étape indispensable de réflexion**
>
> L\'élaboration du plan nécessite un temps de réflexion après une analyse détaillée du dossier et après une prise de notes permettant le relevé des prétentions et, pour chacune d\'elles, des différents moyens et éléments de preuve venant à l\'appui. Cette étape de réflexion et de recherche d\'une logique de construction de la motivation est indispensable pour parvenir à un ordonnancement cohérent des différentes questions litigieuses et pour structurer son raisonnement sur chacune des questions. Loin d\'être inutile, elle évitera au stade de la rédaction des répétitions, des contradictions sinon des hésitations, qu\'une solution insuffisamment réfléchie ou recherchée encore au fil de la rédaction trahirait nécessairement.
>
> Aussi, la rédaction de la décision et spécialement de la motivation doit être l\'aboutissement de la réflexion, au cours de laquelle un plan de construction des motifs est arrêté, et non la première étape de cette réflexion.
>
> Les grilles d\'analyse préalable du dossier, exposées plus haut, sont fort utiles à l\'élaboration de ce plan et permettent de vérifier que chacune des prétentions trouve place dans le plan qui se dessine et que les
>
> moyens, se rattachant à telle ou telle prétention, sont de même traités à l\'intérieur du syllogisme construit pour ladite prétention.
>
> Ce plan, aisé à trouver dans certains contentieux simples ou de masse, où le juge peut du reste s\'aider de trames de rédaction contenant déjà un plan de motivation et le rappel de certaines majeures sur les questions juridiques les plus habituelles, sera moins évident sur des dossiers plus complexes et supposera de s\'adapter à la spécificité du dossier en cause.

###### *Quelques exemples de plans susceptibles d\'être adoptés :*

- *Dans un contentieux de responsabilité et de liquidation de préjudices, il est préférable sur les préjudices, une fois traitée la question de ladite responsabilité, de rapporter en premier lieu les conclusions du rapport d\'expertise médicale puis, poste de préjudice par poste de préjudice, de confronter ces conclusions aux éventuels autres éléments de preuve produits par les parties, d\'examiner les moyens s\'y rapportant avant de déterminer la réalité du préjudice et de décider de la réparation; ainsi, le plan des motifs pourra être celui-ci :*

A)  *Sur la responsabilité*

B)  *Sur la liquidation des préjudices*

> *Il résulte du rapport d\'expertise médicale du Docteur... en date du\... que\...*
>
> *1°) sur tel élément de préjudice (discussion sur la réalité et l\'ampleur du préjudice -- fixation du montant de la réparation)*
>
> *2°) sur tel autre élément de préjudice (discussion sur la réalité et l\'ampleur du préjudice -- fixation du montant de la réparation)*

- *Dans un contentieux de construction, où le juge dispose d\'un rapport d\'expertise judiciaire, ordonnée soit en référé soit par le juge de la mise en état soit avant dire droit par la juridiction du fond, il peut être utile de résumer en premier lieu les constatations et avis de l\'expert avant d\'examiner, désordre par désordre, la nature de ceux-ci, les responsabilités encourues et les garanties dues puis enfin les réparations. Ainsi, le plan de la motivation peut-être celui-ci:*

A)  *sur la demande de X en réparation des désordres Il résulte du rapport d\'expertise... en date du\... que\...*

> *1°) sur tel désordre*

a)  *sur la garantie due*

b)  *sur la réparation 2°) sur tel autre désordre*

<!-- -->

a)  *sur la garantie due*

b)  *sur la réparation*

    - *Si, toutefois, tous les désordres invoqués sont de la même nature et engagent les mêmes garanties ou responsabilités, le plan de la motivation peut être ainsi construit:*

<!-- -->

A)  *sur la nature des désordres et sur les garanties engagées*

> *Majeure : rappel du texte se rapportant à la nature des désordres en cause et à la garantie qui en*
>
> *résulte*
>
> *Mineure : rappel des conclusions de l\'expert sur la nature des désordres, examen des moyens des*
>
> *parties*
>
> *Conclusion sur les garanties dues par telle ou telle partie*
>
> *B) sur la réparation des désordres*
>
> *Rappel des termes du rapport sur les réparations à envisager et leur coût Examen des moyens des parties*
>
> *Conclusion sur les travaux de réparation à supporter par telle ou telle partie ou sur les sommes à*
>
> *allouer*

# FICHE VI : L\'OFFICE DU JUGE

> **DEFINITION ET CARACTERES**
>
> Dans l'office juridictionnel traditionnel, une ligne de partage existe entre le fait, chose des parties, et le droit, domaine du juge. Toutefois, cette distinction mérite d\'être nuancée. De plus, cet office se décline tantôt en termes de devoir, tantôt en termes de pouvoir, distinction parfois subtile qui sera ici approchée par la présentation de ses aspects les plus essentiels.
>
> **L\'OFFICE DU JUGE DANS LE DOMAINE DES FAITS**
>
> Ce sont les parties qui ont l\'initiative et la charge d\'une part d\'alléguer les faits (article 6 du CPC), d\'autre part d\'en rapporter la preuve (article 9 du CPC).
>
> Dès lors, dans ce domaine des faits, l'office du juge se décline comme suit :

- **La réponse aux faits**

> **\* La notion de faits auxquels peut ou doit répondre le juge**
>
> L\'article 7 du code de procédure civile apporte ainsi des précisions sur les faits sur lesquels peut se fonder le juge,

- En excluant les faits qui ne sont pas dans les débats (résultats de vérifications personnelles du juge qui ne répondraient pas aux exigences des articles 179 et suivants du code de procédure civile^16^, souvenirs du juge, éléments ressortant d\'une note en délibéré non communiquée aux autres parties) ; il n'a pas même à évoquer ces faits et ne doit surtout pas s'y appuyer ;

- En incluant, parmi les éléments du débat, les faits que les parties n\'auraient pas spécialement invoqués au soutien de leurs prétentions, dits faits adventices (art. 7 al. 2 CPC). La prise en compte de faits dits adventices, à la différence des faits spécialement invoqués, n\'est cependant pour le juge qu\'une simple faculté. Ces faits adventices peuvent résulter tant des pièces produites par les parties et que celles-ci n\'exploitent pas, que des conclusions et éléments de la procédure (mesures d\'instruction, pièces de la procédure) dès lors que ce faisant le juge se fonde sur des faits qui sont dans les débats.

> Toutefois, le juge qui soulève un moyen de fait doit, en dépit de la lettre de l'article 12 alinéa 3 du code de procédure civile qui n'évoque que le cas du moyen de droit, respecter le principe de la contradiction et inviter en conséquence les parties à s'expliquer sur ce moyen s'il n'a pas été spécialement invoqué au moins par l'une d'elles^17^.
>
> *Exemple : en matière de responsabilité délictuelle, le juge peut se fonder sur des faits non spécialement invoqués mais contenus dans le débat, faisant apparaître la commission de fautes par la victime elle-même, et décider ainsi d\'un*
>
> ^16^ Les vérifications personnelles, auxquelles peut procéder le juge en application de cet article 179 du CPC, ne peuvent notamment porter que sur des faits litigieux, donc sur les seuls faits allégués par les parties.
>
> ^17^ En ce sens, la fiche thématique sur le principe de la contradiction consultable sur le site de la [[Cour de cassation (dernière mise à]{.underline}](http://intranet-cassation.justice.fr/rpvjcc/Methodologie/recommandation_civil/Principe_Contradiction_201501.pdf) [[jour janvier 2015),]{.underline}](http://intranet-cassation.justice.fr/rpvjcc/Methodologie/recommandation_civil/Principe_Contradiction_201501.pdf) qui souligne que les moyens de fait sont à la fois des moyens de fait et de droit car ils ne peuvent recevoir le qualificatif de « moyen » que s'ils tendent à produire un effet juridique*.*
>
> A l\'inverse, le juge ne peut étendre ses investigations ni son appréciation au-delà des faits tels que déterminés par les parties, qu\'ils soient spécialement invoqués ou simplement allégués. Les autres faits ne sont pas dans les débats et le juge ne peut fonder sa motivation ni en conséquence faire reposer la solution juridique sur ceux-ci.
>
> *Exemple : le juge du divorce saisi d\'une demande de prestation compensatoire ne peut rejeter cette demande en constatant que les ressources de l\'épouse étaient sensiblement équivalentes à celles de son mari et en retenant qu\'elle avait certes été licenciée mais percevait des indemnités chômage, alors que ce dernier fait n\'était pas dans le débat*^19^*.*
>
> Par exception aux développements qui précédent, dans le contentieux du divorce, le juge ne peut prononcer un divorce en se fondant sur des griefs qui, même s\'ils sont présents dans le débat, n\'ont pas été spécialement invoqués par les époux dans leurs conclusions respectives^20^.
>
> **\* La question des faits non contestés**
>
> Délicate est la question des faits invoqués par une partie, non expressément contestés par l'autre partie, et de l'appréciation de ces faits par le juge. Même si la jurisprudence n'est pas unanime sur ce point, il peut être admis que le juge a la faculté d'interpréter de tels faits sans être tenu de les considérer comme constants. Il doit cependant respecter le principe de la contradiction^21^.
>
> *Exemple : soit une action en paiement du coût de travaux du fait d'une pollution d'un étang, engagée par M. et Mme X attribuant la pollution aux eaux de fonds voisins.*
>
> *La lecture du dossier et plus spécialement des pièces révèle au juge que M. et Mme X, demandeurs à l'instance, ont en fait revendu leur propriété et ne sont plus propriétaires de l'étang.*
>
> *Pour autant, aucune des parties ne conteste que ces derniers puissent prétendre au paiement des travaux ni donc leur qualité de propriétaires.*
>
> ^18^ En ce sens Civ. 1, 25 septembre 2013, n° 12-23.541.
>
> ^19^ En ce sens, Civ.1, 11 mars 2009, n° 07-21.383.
>
> ^20^ En ce sens, Civ. 2, 24 février 1988, BC II n° 52, et Civ. 2, 10 janvier 1990, n° 88-18.604.
>
> ^21^ En ce sens, Civ. 2, 10 mai 1991, BC II n° 142 et 11 mai 2006, n° 04-18913.

- **L'invitation possible du juge à fournir des explications de fait**

> Le juge peut enfin, en application de l\'article 8 du code de procédure civile, inviter les parties à fournir les explications de fait nécessaires à la solution du litige, ceci n\'étant qu\'une simple faculté dont l\'exercice est laissé à son pouvoir discrétionnaire.
>
> Si l'on s'en tient à l'emplacement de cet article, situé à la suite de l'article 7 du même code, il ne s'agit que d'éclaircissements sur des faits déjà contenus dans les débats et non sur des faits nouveaux.

- **L\'aide ou la contrainte à la preuve**

> Il appartient aux parties, en application de l\'article 9 du code de procédure civile, de prouver conformément à la loi les faits nécessaires au soutien de leurs prétentions.
>
> Toutefois, même en ce domaine de la preuve, le juge dispose de certains pouvoirs.

- **Le pouvoir d'ordonner une mesure d'instruction**

> Le juge peut ordonner d\'office toutes les mesures d\'instruction légalement admissibles ce, en application de l\'article 10 du code de procédure civile.
>
> Ce n'est là qu\'une simple faculté pour lui et il peut à l'inverse choisir de se prononcer au seul vu des éléments de preuve produits par les parties au litige^22^. Toutefois dans certaines matières (notamment filiation ou action à fin de subsides) l'expertise est de droit, sauf s'il existe un motif légitime de ne pas y procéder^23^.
>
> **\*Le pouvoir d'enjoindre ou de demander la production d\'un élément de preuve détenu par une partie ou par un tiers**
>
> S'agissant à l'inverse de la faculté d'enjoindre à une autre partie qui détient un élément de preuve de le produire, au besoin sous astreinte, ou de demander ou ordonner, sous la même sanction, la production de tous documents détenus par des tiers, le juge ne peut y recourir qu'à la requête d\'une partie en application de l'article 11 du code de procédure civile.
>
> **Le contrôle des éléments de preuve**
>
> Le juge doit veiller d\'une part à la loyauté dans l\'établissement de la preuve et dans son administration en justice, d\'autre part au respect du principe de la contradiction.
>
> Ainsi, en application de l\'article 16 du code de procédure civile, il ne peut retenir dans sa décision notamment les documents invoqués ou produits par les parties que si elles ont été à même d\'en débattre contradictoirement. A défaut, il devra les écarter même d'office.
>
> ^22^ En ce sens, Com, 14 déc.2004, BC IV, n° 224.
>
> ^23^ En ce sens, Civ. 1 , 28 mars 2000, n°98-12806, BC I, n° 103, Civ.1° 14 juin 2005, n° 04-13913, BC I, n° 253 et récemment, Civ.1°, 13
>
> juillet 2016, n°15-22848.
>
> L'exercice de ce pouvoir d'office suppose pour le juge de s'expliquer sur ce qui le conduit à écarter des débats certaines pièces ou certaines conclusions communiquées par les parties, en précisant en quoi le principe de la contradiction a été violé ou en caractérisant un comportement d'une partie contraire à la loyauté des débats^24^.
>
> *Exemple : soit un dossier dans lequel ne figurent pas certaines des pièces sur lesquelles s'appuie une partie, lesquelles sont cependant mentionnées au bordereau de communication annexé aux dernières conclusions tandis que leur communication n'a pas été contestée par la partie adverse. Le juge ne peut, en de telles circonstances, limiter les droits de la partie ni tirer les conséquences d\'une absence de pièces au motif que celles-ci ne sont pas à son dossier, sans*
>
> *inviter cette partie et la partie adverse à s'expliquer sur cette absence*^25^*.*
>
> **L\'OFFICE DU JUGE DANS LE DOMAINE DU DROIT**
>
> **Le fondement textuel et son interprétation jurisprudentielle**
>
> L'article 12 du CPC pose les contours de l\'office du juge, dans la recherche et l\'application de la règle de droit applicable, en ces termes : « Le juge tranche le litige conformément aux règles de droit qui lui sont applicables. Il doit donner ou restituer leur exacte qualification aux faits et actes litigieux sans s'arrêter à la dénomination que les parties en auraient proposée. Toutefois, il ne peut changer la dénomination ou le fondement juridique lorsque les parties, en vertu d'un accord exprès et pour les droits dont elles ont la libre disposition, l'ont lié par les qualifications et points de droit auxquels elles entendent limiter le débat. ».
>
> Il en résulte le [devoir]{.underline} de juger conformément aux règles applicables et un [devoir]{.underline} de qualification ou de requalification des actes et des faits litigieux, sauf l\'hypothèse, rare en pratique, d\'un choix de qualification imposé expressément au juge par les parties.
>
> De plus celui-ci ne peut, sauf dans certaines hypothèses spécifiques, statuer en se bornant à une simple référence à l\'équité^26^.

- **La qualification et la requalification**

> Le devoir de qualification ou de requalification des actes et faits litigieux conduit le juge, sauf si les parties l\'ont expressément lié par une qualification juridique (hypothèse envisagée à l\'article 12 alinéa 3 précité in fine), à ne trancher une question juridique relativement à un fait ou un acte que sous son exacte qualification juridique et non sous une qualification erronée donnée par les parties.
>
> L\'accord des parties sur une qualification, sauf si elles l\'ont expressément lié par celle-ci, n\'est pas un obstacle à ce devoir de requalification.
>
> *Exemple : Le contrat dénommé « bail d\'appartement meublé », produit aux débats par un bailleur pour échapper à certaines dispositions de la loi n° 89-462 du 6 juillet 1989 relatives aux autres locations, doit être requalifié par le juge en contrat de bail d\'habitation sur un local non meublé, si en réalité aucun meuble appartenant au bailleur ne garnissait les lieux loués lors de la remise des clefs.*
>
> *^24^* Dans un arrêt de 2006 (Ch. mixte, 3 fév.2006, n° 04-30.592) , la Cour de cassation fait référence aux seules « constatations souveraines des juges du fond » mais des arrêt récents des chambres civiles se montrent plus exigeants : Civ. 3^ème^ , 17 fév.2009, n°07-20.593 et Civ. 1^ère^ , 20 fév. 2008, n° 07-12.676.
>
> ^25^ En ce sens, Civ. 2 , 11 janvier 2006, BC II, n° 10.
>
> ^26^Civ. 1, 28 juin 2012, n° 11-20,336, cassation au visa de l\'article 12 du CPC de la décision qui condamne le défendeur au paiement de deux factures en motivant par le fait que « l\'équité commande de le condamner\... ».

- **Le changement de fondement juridique**

> Intellectuellement, la requalification est une opération distincte du changement de fondement juridique, la première précédant la seconde.
>
> En pratique toutefois, le changement de qualification juridique entraînera logiquement un changement de fondement juridique à la demande.
>
> *Exemple : envisagée sous la qualification de contrat de bail d'habitation non meublé, la question juridique sera tranchée au regard de dispositions de la loi n° 89-462 du 6 juillet 1989 pour partie différentes de celles invoquées par le bailleur, qui soutenait être signataire d'un contrat de bail sur un logement meublé.*
>
> La jurisprudence est venue préciser la portée des exigences posées dans l\'article 12 précité du code de procédure civile en ce que :

- Les parties ont l\'[obligation]{.underline} de proposer au juge l\'ensemble des moyens de droit pertinents dès la première instance et ne sont plus recevables à engager, sur un nouveau fondement juridique non invoqué dans la première instance et par hypothèse non examiné par le juge, une nouvelle action qui poursuit le même objet et le même but économique ou social qu\'une première action engagée sur d\'autres fondements^27^ ; cette règle processuelle pesant sur les parties à l\'instance répond au principe dit de concentration des moyens ; ce principe, selon la Cour européenne des droits de l'homme, constitue bien une limitation du droit d'accès à un procès équitable mais tend à « assurer une bonne administration de la justice, en ce qu'il vise à réduire le risque de manœuvres dilatoires et à favoriser un jugement dans un délai raisonnable », de sorte qu'il « s'inscrit donc dans un but légitime » et n'est pas contraire au droit garanti par l'article 6 §1 de la Convention européenne des droits de l'homme et des libertés fondamentales^28^ ;

- Le juge a la [possibilité]{.underline} sans y être contraint, sauf règles particulières, de changer la dénomination ou le fondement juridique des demandes^29^.

> **La déclinaison des différents aspects de l\'office du juge**

- **Le cas où les parties n\'ont invoqué aucun fondement juridique au soutien de leur prétention**

> En ce cas d\'absence de fondement juridique invoqué, essentiellement rencontré dans les litiges suivant la procédure orale sans ministère d\'avocat obligatoire ou dans les litiges suivant la procédure écrite mais pour des demandes accessoires, en application de l\'article 12 du CPC le juge tranche le litige selon les règles de droit qui lui sont applicables et donc :

- [Doit]{.underline} examiner les faits sous tous leurs aspects juridiques conformément aux règles de droit applicables ; ne le faisant pas, le juge viole l\'article 12 du code de procédure civile^30^ ; il ne peut donc rejeter la prétention au motif qu\'aucun moyen de droit n\'est invoqué au soutien de celle-ci ;

- Si une règle est identifiée par le juge comme étant susceptible de s\'appliquer et de faire droit à la prétention, le juge construit sa motivation au regard de cette règle, en l\'énonçant dans la majeure et en l\'appliquant aux faits de l\'espèce dans la mineure du syllogisme, pour conclure sur la prétention ;

> ^27^ En ce sens, Ass. plénière, 7 juillet 2006, n° 04-10.672, arrêt connu sous le nom d\'arrêt CESAREO.
>
> ^28^ CEDH avr.2015, BARRAS c. France, req. N° 12686/10.
>
> ^29^ En ce sens, Ass. plénière, 21 décembre 2007, n° 06-11343, arrêt connu sous le nom d\'arrêt DAUVIN.
>
> *^30^* Cass. Soc, 23 nov. 2011, n° 10-24279 et Cass. Soc, 28 sept.2010 n° 09-41276.

- Si la règle identifiée par le juge ne permet pas de faire droit à la prétention, le juge ne peut rejeter cette prétention sans avoir examiné la question qui lui est soumise sous tous les autres aspects juridiques susceptibles d\'être déclinés et conclure au fait que la demande ne peut prospérer par l\'application d\'aucune de ces règles.

> *Exemple : le juge ne peut rejeter une fin de non-recevoir tirée de la prescription, au motif que la partie qui l\'invoque ne vise aucun texte légal fondant sa demande d\'application de la prescription ; en l\'absence de fondement donné par les parties, le juge doit au contraire examiner les faits sous tous leurs aspects juridiques, conformément aux règles de droit qui leur sont applicables*^31^*.*

- **Le cas où les parties ont invoqué un ou plusieurs fondements juridiques au soutien de leur prétention**

> Cette hypothèse est la plus fréquente compte-tenu du principe de concentration des moyens ci-dessus évoqué et imposant aux parties, dès la première instance, d\'invoquer à l\'appui de leurs prétentions tous les moyens de droit susceptibles de trouver application.
>
> En ce cas, aux termes de l\'article 12 du CPC, le juge tranche le litige selon les règles de droit qui lui sont applicables et donc :

- [Doit]{.underline} vérifier si toutes les conditions d\'application de la règle de droit ou des règles de droit invoquées par les parties sont ou non réunies^32^.

> C\'est là le sens de l\'article 12 alinéa 1^er^ du code de procédure civile (« le juge tranche le litige conformément aux règles de droit qui lui sont applicables »).
>
> Quand toutefois ce contrôle suppose le relevé d\'office par le juge de faits dans le débat mais non invoqués spécialement par les parties (faits dits adventices), ce relevé n\'est plus pour le juge qu\'une faculté et non une obligation.
>
> *Exemples : en matière de responsabilité du fait des choses fondée sur l\'article 1384 du code civil, le juge relèvera d\'office le fait que le défendeur n\'était pas, au moment des faits, le gardien de la chose considérée.*
>
> *En matière de preuve des actes juridiques, en réponse à la partie qui entend produire par témoins la preuve d\'une contrelettre, pour apprécier cet élément de preuve le juge appliquera d\'office la règle selon laquelle il ne peut être prouvé contre un écrit que par un autre écrit.*

- [Doit]{.underline} examiner chacune des règles invoquées si plusieurs moyens de droit sont effectivement soutenus par une partie et ce, en respectant la hiérarchie éventuellement donnée par celle-ci à ces moyens (examen du fondement invoqué à titre principal puis ensuite seulement, au cas de non application de ce premier fondement, examen de la demande sur le fondement invoqué à titre subsidiaire voire enfin du fondement invoqué à titre très subsidiaire).

> *Exemple : les époux X agissent en contestation de la vente de l'immeuble acquis auprès de Monsieur Y à raison des désordres structurels affectant ce bien (infiltrations, déformations de façades, présence de mérules) et de l'absence des*
>
> ^31^ Civ. 3, 13 décembre 2011, n° 10-18037.
>
> ^32^ Civ. 1, 13 février 2013, n° 11-22024, où la Cour de cassation rappelle que la cour d\'appel était « tenue de vérifier les conditions d\'application de la règle de droit invoquée ».
>
> *équipements de chauffage pourtant mentionnés dans la fiche descriptive publiée par l'agence immobilière ; ils invoquent l'existence de vices restés cachés au moment de la vente et, à titre subsidiaire, une erreur sur les qualités substantielles du bien.*
>
> *Le juge examine alors successivement l'un et l'autre de ces fondements, en vérifiant en premier lieu l'existence ou non de vices cachés au sens de l'article 1641 du code civil et en recherchant en second lieu, après avoir jugé le premier fondement non pertinent, la caractérisation ou non d'une erreur sur les qualités substantielles du bien vendu.*
>
> Si, dans le domaine de la responsabilité, le demandeur invoque deux fondements (contractuel et délictuel) pour les mêmes faits, le juge doit déterminer quel régime de responsabilité s\'applique et statuer sur ce fondement^33^.

- [Peut]{.underline} soulever d\'office un nouveau fondement invoqué par aucune des parties mais il ne s\'agit là que d\'une faculté^34^, qu\'il n\'exerce le cas échéant qu\'après examen dans la motivation des différents fondements invoqués expressément par les parties.

> *Exemple : dans l'exemple précité donnant lieu à une contestation sur une vente d'immeuble, si le juge estime que ne sont caractérisés ni les vices cachés invoqués à titre principal, ni l'erreur sur les qualités substantielles invoquée à titre subsidiaire, il peut débouter les époux X de leur prétention et n'est pas contraint de rechercher si, sur un autre fondement juridique que les parties ont fait le choix de ne pas exploiter, la demande aurait pu prospérer.*
>
> *Exemple : saisi d\'une demande au titre d\'une créance de salaire différé, fondée sur les dispositions de l\'article 321 -15 du code rural, le juge n\'est pas tenu de rechercher si cette action peut être fondée sur l\'enrichissement sans cause*^35^*.*
>
> *Exemple : saisi de demandes fondées sur la qualification du contrat litigieux en contrat de bail ou en contrat de vente, le juge qui rejette celles-ci n\'est pas tenu de substituer à ces qualifications une autre qualification dès lors qu\'elle aurait eu pour effet de changer le fondement des demandes qui lui étaient présentées*^36^*.*

- **Les cas où le pouvoir du juge dans la recherche de la règle de droit applicable est renforcé**

> Il est certains domaines où soit le législateur soit la jurisprudence ont reconnu au juge un large pouvoir. Il est d\'autres domaines où le relevé d\'office de la règle en cause n\'est plus même un pouvoir mais un devoir du juge.
>
> *Le pouvoir de relever d\'office*
>
> Ainsi, sans être exhaustif^37^, il est possible de donner les quelques illustrations suivantes :

- Le juge peut vérifier d\'office la régularité de sa saisine^38^

- Le juge peut relever d\'office certaines fins de non-recevoir, notamment celles tirées d\'un défaut d\'intérêt, de qualité ou de la chose jugée (art. 125 alinéa 2^ème^ CPC), les exceptions d\'incompétence

> ^33^ Civ. 3, 8 nov. 2011, n° 10.20-898.
>
> ^34^ Voir toutefois civ.2°, 5 juillet 2018, pourvoi n°17 19738, dans lequel la Cour de cassation a statué dans le sens d'une obligation de relever d'office le fondement juridique adéquat, pour les dispositions d'ordre public de la loi n°85-677 du 5 juillet 1985 relatives aux victimes d'accidents de la circulation.
>
> ^35^Arrêt précité Civ. 1 , 29 mai 2013, n° 12-12296, qui renvoie à la même situation juridique que celle tranchée par l\'assemblée plénière de la Cour de cassation dans son arrêt dit CESAREO.
>
> ^36^Civ. 1, 19 juin 2013, n° 12-11767, la Cour de cassation reliant par là même la requalification de l\'acte litigieux au changement de fondement juridique.
>
> ^37^ Pour des exemples plus nombreux, il est renvoyé au fascicule «Fiches de procédure», fiche sur l\'office du juge.
>
> ^38^ Civ. 1, 5 février 2002, n° 99-10925.
>
> sous certaines conditions notamment en cas de défendeur non comparant (92 et 93 CPC)^39^, la nullité pour défaut de capacité d\'ester en justice (art. 120 alinéa 2^ème^ CPC)

- L\'article L. 141-4 du code de la consommation donne au juge le pouvoir de relever d\'office toutes les dispositions de ce code dans les litiges nés de son application^40^.

> *Le devoir de relever d\'office*
>
> Sans faire du présent rappel une liste exhaustive^41^, suivent quelques exemples. Ainsi, dans le domaine du droit processuel, le juge doit relever d\'office :

- L'exception de nullité d\'un acte de procédure fondée sur l\'inobservation de règles de fond lorsque cette nullité a un caractère d\'ordre public (art. 120 alinéa 1^er^ CPC)

- Non pas les autres exceptions de procédure, mais la fin de non-recevoir tirée de leur tardiveté^42^

- Les fins de non-recevoir d\'ordre public, notamment si elles résultent de l\'inobservation des délais dans lesquels doivent être exercées les voies de recours ou de l\'absence d\'ouverture d\'une voie de recours (art. 125 alinéa 1^er^ CPC); ainsi le juge doit relever d\'office la tardiveté et donc l\'irrecevabilité d\'une action en paiement d\'un solde de crédit à la consommation pour cause de forclusion si du moins sont au dossier des éléments en ce sens^43^

- L\'absence de convocation régulière d\'une partie en application de l\'article 14 du code de procédure civile^44^ et, en cas de défaillance d\'une partie, l\'irrecevabilité de demandes incidentes non notifiées à cette dernière avant l\'audience.

> Dans un litige comportant un élément d\'extranéité, le juge doit vérifier d\'office sa compétence au regard des conventions internationales, bilatérales ou des règlements européens applicables à la matière et, s\'il vérifie sa compétence, rechercher la loi applicable au litige.
>
> Sur le fond du droit, le juge national doit appliquer le droit de l\'Union européenne et, au besoin, écarter un texte de droit français qui sanctionne une obligation contraire au droit de l\'Union. Il doit ainsi soulever d\'office le caractère abusif d\'une clause contractuelle^45^ ou encore faire application des règles d'ordre public issues de la directive européenne relative à la responsabilité du fait des produits défectueux^46^.
>
> ^39^ Sur la question plus générale de l'office du juge en cas de défaut de comparution du défendeur, voir la note du SDER et du bureau du contentieux de la 2^ème^ chambre civile consultable sur le site de [[La Cour de Cassation (dernière mise à jour en mars 2019)]{.underline}](http://intranet-cassation.justice.fr/rpvjcc/Reserve/SDE/BDD/C2/201903_c2_office_juge_art_472_cpc.pdf)
>
> ^40^ cf Civ. 1, 22 janvier 2009, n° 05-20.176 (dans le domaine du crédit à la consommation) et Com. 28 avril 2009, n° 08-11.616 (dans le domaine de l\'engagement de caution, pour une faculté de relevé d\'office de l\'article L. 341-2 du code de la consommation).
>
> ^41^ Pour des exemples plus nombreux, il est renvoyé au fascicule précité.
>
> ^42^ Civ. 2, 19 mars 2009, n° 05-18.484.
>
> ^43^ Civ. 1, 18 septembre 2008, n° 07-15473.
>
> ^44^ Civ. 2, 10 mai 1989, BC II n° 105.
>
> *^45^* En ce sens, arrêt CJUE du 4 juin 2009, PANNON C-243/08.
>
> ^46^ Ch. Mixte, 7 juillet 2017, n° 15-25.651 : « (...) si le juge n\'a pas, sauf règles particulières, l\'obligation de changer le fondement juridique des demandes, il est tenu, lorsque les faits dont il est saisi le justifient, de faire application des règles d\'ordre public issues du droit de l\'Union européenne, telle la responsabilité du fait des produits défectueux, même si le demandeur ne les a pas invoquées » (arrêt rendu au visa de la directive 85/374/CEE du Conseil du 25 juillet 1985, des articles 1386-1 et suivants, devenus 1245 et suivants, du code civil, de l\'article 12 du code de procédure civile et des principes de primauté et d\'effectivité du droit de l\'Union européenne).
>
> **Les limites à l\'office du juge**

- **Limites tenant au nécessaire respect du principe de la contradiction**

> Cette limite trouve sa source dans l\'article 16 du CPC imposant au juge de faire respecter et de respecter lui-même le principe de la contradiction. Ainsi,

- Dans le cas où les parties n\'ont invoqué aucun fondement juridique au soutien de leur prétention, tenu de rechercher d\'office les fondements susceptibles de trouver application le juge n\'a pas à rouvrir les débats avant d\'examiner l\'une ou l\'autre des règles identifiées ni de tirer la conclusion tendant soit à faire droit à la prétention soit à la rejeter, dès lors qu\'il ne soulève pas un moyen nouveau^47^

- La vérification par le juge de la réunion des conditions d\'application d\'une règle de droit invoquée par les parties ne lui impose pas une réouverture des débats, puisque la règle de droit est d\'ores et déjà dans le débat^48^

- À l\'inverse le juge qui, après avoir écarté le ou les fondements juridiques invoqués par les parties, soulève d\'office un autre fondement doit ordonner la réouverture des débats pour les inviter, dans le respect du principe de la contradiction, à faire toutes observations sur ce nouveau moyen de droit soulevé d\'office.

> De façon plus générale, le juge ne peut relever d\'office un moyen sans avoir au préalable invité les parties à présenter leurs observations, étant toutefois précisé qu\'en procédure orale les moyens sont présumés, sauf preuve contraire, avoir été débattus contradictoirement à l\'audience^49^.
>
> Cette exigence s'applique à tous les moyens relevés d'office par le juge, y compris un moyen de procédure^50^ et un moyen d'ordre public, de fond ou de procédure^51^.
>
> *Exemple : le juge saisi d'une demande d'un propriétaire en constatation de la résiliation d'un bail et en expulsion ne peut débouter le demandeur de sa prétention en relevant que le commandement délivré préalablement à l'assignation est nul, sans avoir invité les parties à présenter leurs observations*^52^*.*
>
> Toutefois, le juge n'a pas à provoquer les observations des parties lorsqu'il soulève le moyen tiré de la violation des droits de la défense, ainsi notamment lorsqu'il relève l'irrecevabilité de conclusions tardives déposées peu avant ou après l'ordonnance de clôture^53^.

- **Limites tenant à l\'interdiction de modifier l\'objet du litige**

> Cette limite trouve sa source dans l\'article 4 du code de procédure civile et dans le principe de l\'immutabilité de l\'objet du litige, tel que déterminé par les prétentions respectives des parties fixées dans leurs dernières conclusions en procédure écrite ou dans le dernier état des demandes soutenues à l'audience en procédure orale.
>
> ^47^ En ce sens, Civ. 2, 17 novembre 2005, n° 04-10741 et Civ. 2, 5 mai 2011, n° 10-13.841.
>
> ^48^ En ce sens, Civ. 1, 4 avril 1984, n° 83-10.635, Civ. 2, 10 février 2000, n° 98-13.354, Com. 6 mai 2002, n° 98-21.738.
>
> ^49^ En ce sens, Civ. 2, 17 novembre 2011, n° 10-26254.
>
> ^50^ En ce sens pour une fin de non-recevoir, Civ. 2, 11 mai 2006, n° 04-19413.
>
> ^51^ Cass, ch. mixte, 10 juillet 1981, BC n° 6 et 7.
>
> ^52^ Civ. 3, 7 fév. 1990, n° 87-20.094, BC III, n° 46.
>
> ^53^ En ce sens, Civ. 2, 15 mai 2008, n° 07-17.763.
>
> Cet objet du litige est, au regard du juge et dans la jurisprudence actuelle, « la chose demandée au sens de l'ancien article 1351 du code civil, c'est-à-dire le résultat économique et social recherché par les parties, en pratique le demandeur »^54^.
>
> Aussi, l\'exercice de l\'office du juge ne doit pas conduire à un changement du résultat économique et social recherché par les parties ni à une exploitation de faits qui ne seraient pas dans le débat.
>
> *Exemple : saisi d'une demande de pension alimentaire, le juge aux affaires familiales ne peut allouer une prestation compensatoire. En effet, cette requalification aurait modifié l'objet du litige et excédé le pouvoir d'office du juge.*
>
> *Exemple : saisi d'une action fondée sur les mécanismes de la responsabilité contractuelle de l'article 1792-4 du code civil et, subsidiairement, sur le manquement à l'obligation de délivrance pour défaut de conformité du bien livré en violation de l'article 1604 du code civil, le juge peut-il statuer sur le fondement de l'article 1641 du code civil simplement visé dans le dispositif des conclusions d\'une partie ?*
>
> *En fondant expressément son action sur l'article 1792-4 et à défaut sur l'article 1604 du code civil, le demandeur a ôté toute portée au simple visa de l'article 1641 dans le dispositif de ses conclusions de sorte que, en statuant sur les dispositions de cet article 1641 du code civil, le juge modifie l'objet du litige et viole les articles 4 et 12 du code de procédure civile^55^.*
>
> *Il y a lieu à cet égard de relever que le seul visa d'un article au dispositif de conclusions, sans raisonnement juridique articulé sur ce fondement, n'est pas un moyen auquel le juge est tenu de répondre.*
>
> *Exemple : le juge du divorce, saisi d'une demande de dommages et intérêts en raison d'un préjudice distinct de la rupture, lequel doit être réparé en application de l'article 1240 du code civil, modifie à tort l'objet du litige s'il statue sur le fondement de l'article 266 dudit code, ces deux articles réparant des préjudices distincts*^56^*.*

- **Limites tenant à certaines interdictions au relevé d\'office**

> Certaines dispositions, édictées en vue de la seule protection des intérêts particuliers des parties, font échec à l\'office du juge en ce qu\'il ne peut relever de sa propre initiative leur violation, seule la partie que la règle protège ayant cette initiative.
>
> Ainsi, dans le domaine du droit processuel, le juge ne peut relever d\'office certaines fins de non-recevoir, notamment celles tirées de l\'expiration d\'un délai de prescription, du défaut de publication de la demande en matière réelle immobilière, de l\'absence de lien suffisant de la demande reconventionnelle avec la demande principale, de l\'absence de signification d\'une décision rendue par défaut dans le délai de l\'article 478 du code de procédure civile.
>
> **RECOMMANDATIONS**
>
> La question de l\'office du juge est une question délicate qui doit le conduire à s\'interroger constamment sur la possibilité de relever d\'initiative tel élément de fait ou tel moyen de droit et, le cas échéant, à vérifier que ce faisant l\'objet du litige n\'en est pas modifié, que le moyen de fait relevé est bien dans les débats et que le principe de la contradiction n'a pas été violé.
>
> ^54^ C. Chainais, F. Ferrand et S. Guinchard, de même de L. Cadiet et E. Jeuland.
>
> ^55^ En ce sens, Civ. 3, 28 mars 2012, n° 11-11.391.
>
> ^56^ En ce sens, Civ. 1, 18 janv. 2012, n° 11-10.959, 24 oct.2012, n° 11-22.358 et 6 mars 2013 n° 12-12.338.
>
> Sur ce dernier point, le juge doit garder à l\'esprit qu\'il ne doit pas surprendre les parties par sa décision ni par les moyens sur lesquels il s\'appuie pour y parvenir. Le droit à un procès équitable suppose en effet que les parties ne soient pas « prises au dépourvu » par tel moyen dont elles n'auraient pu débattre^57^.
>
> Dans le doute sur la question de la contradiction, il y a lieu d\'inviter les parties à s\'expliquer sur tel élément de fait ou sur tel moyen de droit, soit à l\'audience en procédure orale, soit par une note en délibéré -- communiquée à l'adversaire - en procédure écrite, soit enfin par une réouverture des débats.
>
> ^57^ CEDH, 13 octobre 2005, clinique des Acacias et autres c. France, n° 65399/01, 65406/01, 65405/01 et 65407/01, § 37, 41 et 43 cité notamment [[dans la fiche méthodologique de la Cour de cassation sur le principe de la contradiction, mise à jour en janvier 2015]{.underline}.](http://intranet-cassation.justice.fr/rpvjcc/Methodologie/recommandation_civil/Principe_Contradiction_201501.pdf)

# FICHE VII : LA MOTIVATION

> **FONDEMENT TEXTUEL**
>
> L'obligation de motivation résulte de l\'article 455 du code de procédure civile aux termes duquel le jugement doit être motivé.
>
> L\'exercice de motivation est au cœur du travail intellectuel de rédaction du jugement.
>
> **DEFINITION** :
>
> **C**'est l\'examen par le juge des prétentions et des moyens, il s'agit de l'explication à la fois de la réponse qui sera donnée à ces prétentions et de la décision retenue, laquelle sera énoncée au dispositif, dernière partie du jugement.
>
> Cet examen des prétentions conduit le juge à construire, pour chacune d\'elles, un ou plusieurs syllogismes juridiques, au terme desquels il confronte les faits de l\'espèce à la règle de droit préalablement énoncée et en tire la conséquence juridique, réponse à la prétention examinée.
>
> La motivation, obligation de principe qui supporte quelques rares exceptions, doit répondre à un certain nombre de règles générales (A). Elle épouse, pour chacune des prétentions, un raisonnement particulier (B) et doit respecter un ordre logique dans l\'examen de celles-ci (C).
>
> []{#_bookmark18 .anchor}**A -- LES REGLES GENERALES DE LA MOTIVATION**
>
> **CARACTERES**
>
> **La motivation doit être à la fois :**

- **Complète** en ce sens que chacune des prétentions doit être examinée, sous réserve d\'une prétention qualifiée par une partie de subsidiaire, laquelle devient sans objet s\'il est fait droit à la demande principale.

> *[Exemple]{.underline}*
>
> *Soit une demande principale aux fins de constatation de l'acquisition d'une clause résolutoire d\'un contrat de bail pour défaut de paiement des loyers par le locataire et, à défaut, aux fins de prononcé de la résiliation pour manquement grave dudit locataire à ses obligations contractuelles et une demande aux fins d\'expulsion du même locataire.*
>
> *S\'il est fait droit à la demande principale en constatation de l'acquisition de la clause résolutoire, la demande subsidiaire (que désignent généralement les termes « à défaut » ou « subsidiaire » dans les écritures des parties) tendant au prononcé de la résiliation devient sans objet.*
>
> *A l\'inverse, le seul rejet de la demande principale tendant à la constatation de l'acquisition de la clause résolutoire ne dispense pas le juge de l\'examen de la demande subsidiaire tendant au prononcé de cette résiliation. En conséquence, le juge rejettera après examen l\'une puis l\'autre de ces demandes principale et subsidiaire.*
>
> S\'agissant des moyens, le juge ne peut rejeter une prétention sans avoir, dans sa décision, examiné tous les moyens invoqués au soutien de ladite prétention.
>
> Toutefois, si la partie soutient la demande sur le fondement d\'un texte supposant la réunion de plusieurs conditions cumulatives, cette demande peut être rejetée dès lors qu\'il est constaté, dans la motivation, que l\'une seulement de ces conditions fait défaut, sans que le juge ait à s\'expliquer sur les autres conditions et sur les moyens que peut-être le demandeur aura développés sur ces autres conditions.
>
> *Ainsi, dans une action en dommages et intérêts fondée sur l\'article 1240 du code civil (1382 ancien), le seul constat de l\'absence de préjudice suffit à rejeter la demande sans nécessité pour le juge de se prononcer sur l\'existence ou non de la faute. Il peut choisir, pour renforcer sa motivation, de démontrer qu\'au surplus la faute n\'est pas davantage prouvée mais cette dernière démonstration n\'est pas indispensable dès lors que l\'une des autres conditions d\'application du régime de la responsabilité pour faute fait défaut.*
>
> S\'il fait droit à la prétention, il peut soit ne motiver que sur l\'un seulement des moyens développés par le demandeur, celui qui lui paraît le plus pertinent, soit examiner l\'ensemble des moyens invoqués par l\'auteur de la prétention. Il doit, en toute hypothèse, examiner l\'ensemble des moyens en défense invoqués par l\'autre partie qui sollicite le rejet de cette même prétention.
>
> L\'oubli d\'un chef de prétention pourra être rectifié par la voie de la requête en omission de statuer. L\'oubli d\'un moyen ne pourra être rectifié par le même juge. Il pourra justifier l\'exercice d\'une voie de recours.
>
> *[Exemple]{.underline}*
>
> *Soit la demande précitée aux fins de prononcé de la résiliation du contrat de bail motif pris de manquements graves du locataire dans ses obligations, spécialement un non-paiement des loyers et des charges locatives et un abus de jouissance des lieux.*
>
> *Si le juge a suffisamment d\'éléments au dossier pour caractériser le premier manquement invoqué, il peut conclure sa motivation comme suit : « en conséquence, pour ce seul motif lié au non-paiement des loyers et charges locatives et sans qu\'il y ait lieu d\'examiner l\'autre manquement invoqué, la résiliation du contrat de bail sera prononcée ». Il peut encore toutefois, ayant caractérisé le premier manquement, examiner le second en introduisant ses développements de ce chef par les termes « au surplus, sur le second manquement invoqué en demande, il résulte de ... que\... ».*
>
> *Si, à l\'inverse, après examen des pièces du dossier, il apparaît que le premier manquement n\'est pas caractérisé, nécessairement le second manquement lié à un prétendu abus de jouissance des lieux devra être examiné.*

- **Fidèle** à l\'objet du litige tel que défini par les parties.

> Tel n\'est pas le cas quand notamment le juge fait des écritures des parties une lecture ou une interprétation erronée ou quand il méconnaît le caractère subsidiaire donné par une partie à l\'une de ses prétentions et qu\'il entend tirer des conséquences juridiques qui trahissent le sens et la portée des conclusions et les dénaturent.
>
> *[Exemple]{.underline} :*
>
> *Soit une demande principale en paiement d\'une somme X au titre d\'un solde de prêt entre particuliers, demande à laquelle le défendeur s\'oppose en contestant la réalité du prêt mais en formulant une demande reconventionnelle et subsidiaire de délais de paiement de la somme qui serait mise à sa charge en cas de condamnation prononcée à son encontre.*
>
> *Le juge ne peut tirer de cette demande reconventionnelle de délais de paiement, formulée à titre subsidiaire, un aveu de l\'existence de son obligation par le défendeur, qui précisément et à titre principal conteste la réalité du prêt. Le juge doit en premier lieu rechercher sur la demande principale en paiement si, en application de l\'article 1353 du code civil (1315 ancien) et au regard des pièces versées par le demandeur, indépendamment de l\'hypothèse envisagée à titre subsidiaire par le défendeur, la réalité du contrat faisant naître une obligation au remboursement est établie.*
>
> *[Exemple]{.underline} :*
>
> *Soit la signature d\'un contrat de vente par acte sous seing privé, sous condition suspensive d\'obtention d\'un prêt par les acquéreurs, suivie d\'une assignation par le vendeur en paiement de la clause pénale et de dommages et intérêts, faute de réitération de la vente dans les délais convenus. A cette demande s\'opposent les acquéreurs et défendeurs à l\'instance en invoquant la caducité de l\'acte à raison de la non-réalisation de la condition suspensive et en faisant valoir, à titre subsidiaire, la nullité de la vente pour erreur sur la substance.*
>
> *Le juge ne peut, sans modifier l\'objet du litige, examiner en premier lieu la validité de l\'acte (la nullité de cet acte n\'est en effet invoquée qu\'à titre subsidiaire par les défendeurs). Faire de cette question une question principale revient à modifier l\'objet du litige tel que déterminé par les parties^58^.*

- **Impartiale**

> La partialité peut résulter
>
> \- Soit de l\'emploi de termes irrespectueux voire injurieux à l\'égard d\'une partie ou de son conseil et trahissant, de la part du juge, un positionnement lui faisant perdre son objectivité
>
> *Ainsi d\'une décision employant notamment ces termes : « la piètre dimension de la défenderesse qui voudrait rivaliser avec les plus grands escrocs\... »^59^*
>
> \- Soit d\'une motivation se bornant à reproduire, sur tous les points en litige, les conclusions d\'une partie à laquelle il est donné satisfaction, ou d'une motivation exposant les moyens et les prétentions des parties selon des modalités différentes ^60^; en ce cas, il n\'y a qu\'une « apparence de motivation de nature à faire peser un doute sur l\'impartialité de la juridiction »^61^.
>
> Ces exemples sont extrêmes et il ne s\'agit pas de s\'interdire systématiquement d\'adopter le raisonnement d\'une partie, lequel peut être conforme aux principes juridiques applicables dans la situation soumise à la juridiction. Il convient cependant de s\'approprier le litige pour, en toute objectivité, par ses propres termes, après une analyse personnelle et rigoureuse du dossier, construire sa motivation qui, le cas échéant, se détachera de la lettre des conclusions des parties.

- **Précise et intrinsèque**

> Cette exigence impose de se déterminer d\'après les circonstances particulières du procès et non par voie de référence à des causes déjà jugées ni par référence à des connaissances ou des investigations
>
> ^58^ En ce sens, Civ. 3, 11 mai 2011, n° 10-14651 et 10-15000, arrêt de cassation rendu au visa de l\'article 4 du CPC.
>
> ^59^ Ence sens Civ. 2, 14 sept.2006, n° 04-20524.
>
> ^60^ Civ.1°, 19 déc. 2018, n°17-22056, dans lequel l'arrêt s'était contenté de viser les dernières écritures de l'appelante au motif qu'elles étaient particulièrement longues et confuses mais avait pris soin de les exposer sur onze pages concernant les intimées.
>
> ^61^ En ce sens, Civ.1, 17 mars 2011, n° 10-10583 et Civ. 1, 25 juin 2014, n° 13-16.940.
>
> personnelles (sauf vérifications personnelles prévues aux articles 179 et suivants du code de procédure civile auxquelles le juge procède, le cas échéant, contradictoirement^62^).
>
> Le juge doit par ailleurs réaliser un examen des pièces versées aux débats par les parties, au soutien de leurs prétentions ou contestations respectives. Un simple visa de pièces, suivi d\'aucune analyse même sommaire de celles-ci ni d\'aucun motif précisant en quoi la demande en cause est fondée ou ne l\'est pas, est insuffisant.
>
> *Ainsi, est contestable en sa motivation le jugement qui, sur opposition à contrainte, se borne à énoncer qu\'au vu des explications du demandeur initial il y a lieu de valider la contrainte, sans analyse des pièces produites ni autre motif notamment sur la nature des sommes sollicitées, sur les périodes auxquelles elles étaient dues et sur l\'opposition*^63^*.*
>
> De même, dans l\'exploitation des pièces, il importe d\'être suffisamment précis et d\'en indiquer la nature, la date et l\'auteur, notamment s\'il s\'agit d\'une attestation ou d\'un autre écrit, de même que le contenu soit en le résumant soit en rapportant un passage in extenso.
>
> Pour autant, le juge n\'est pas tenu d\'exploiter toutes les pièces produites par les parties. S\'il doit particulièrement examiner celles qui sont au cœur de la discussion et sont spécialement invoquées pour soutenir tel moyen, il peut ne pas faire état d\'autres pièces non déterminantes. Il lui est possible à l\'inverse, en application de l\'article 7 alinéa 2 du code de procédure civile, d\'appuyer sa motivation sur des éléments de fait non spécialement invoqués dès lors qu\'ils résultent cependant de pièces régulièrement produites aux débats, il s'agit de la notion de faits adventices. Dans cette hypothèse, il doit néanmoins respecter le principe du contradictoire et inviter les parties à s'expliquer sur ce fait dont elles n'avaient pas spécifiquement débattu.

- **Pertinente**

> N\'est notamment pas pertinente la motivation qui se révèle être soit contradictoire, soit hypothétique ou qui repose sur des termes dubitatifs.
>
> *[Exemple de motivation contradictoire]{.underline} :*
>
> La contradiction peut exister soit entre le rappel de la règle de droit et son application aux faits de l\'espèce, soit dans les analyses successives de mêmes faits et/ou éléments de preuve. Dans tous les cas, la contradiction trahit un défaut de rigueur dans le raisonnement et rend la motivation non pertinente.
>
> *Ainsi, statuer sur une action en responsabilité du fait des choses, en rappelant que ce régime ne repose pas sur la démonstration d\'une faute du gardien, et retenir cependant, dans l\'examen des éléments de la cause, que X gardien a commis telle faute et sera en conséquence tenu pour responsable en application de l\'article 1242 du code civil (1384 ancien)*, est une motivation qui repose sur une contradiction.
>
> *[Exemple de motivation hypothétique]{.underline} :*
>
> *Soit une action en responsabilité et en indemnisation engagée par la victime d\'une chute de cheval au cours d\'une randonnée, à l\'encontre des sociétés ayant respectivement fabriqué puis vendu les étrivières et étriers utilisés lors de la randonnée.*
>
> ^62^ Ainsi d\'une vérification d\'écriture que le juge peut opérer lui-même, par comparaison avec les pièces produites par les parties voire avec une pièce de la procédure, notamment un accusé de réception de convocation signé et retourné au greffe, sauf à le porter à la connaissance des parties et à les inviter à s\'en expliquer.
>
> ^63^ En ce sens, Civ. 2 , 16 fév. 2012, n° 11-12570 ; également pour une motivation construite par voie de simples affirmations, Com. 9 juin 2015, n° 14-15.781.
>
> *Le juge qui retient la responsabilité du fabricant sur le fondement de l\'article 1245 du code civil (1386-1 ancien) et en ces termes : « on ne peut écarter l\'hypothèse selon laquelle (la victime) aurait placé la boucle de l\'étrivière entre le rabat de la selle prévue à cet effet et l\'étrier, éventualité envisagée par le rapport d\'expertise »,* se détermine par des motifs hypothétiques impropres à caractériser un lien de causalité entre le défaut de l\'étrivière et la chute^64^. Soit l\'hypothèse envisagée est établie et il faut la présenter comme telle, en évitant les termes d\'« hypothèse » et d\'« éventualité », soit cette hypothèse n\'est pas vérifiée et elle doit être écartée.
>
> *[Exemple de motivation dubitative]{.underline} :*
>
> *Dire irrecevable une demande de traitement d\'une situation de surendettement d\'un particulier, au motif que celui-ci a souscrit des engagements de caution auprès de plusieurs sociétés pour des montants manifestement excessifs et que sa bonne foi « semble » contestable,* est statuer par des termes impropres à caractériser la mauvaise foi^65^. La bonne foi se présume et la mauvaise foi doit être démontrée et reposer sur des faits vérifiés.
>
> C\'est généralement l\'emploi de termes impropres, qui soit introduisent le doute (il « semble », il « paraît »\...) soit conduisent à se déterminer sur ce qui ne serait qu\'une hypothèse et non un fait établi (« il est vraisemblable que\... »), qui rendent la motivation soit dubitative soit hypothétique et donc non pertinente. Aussi, le choix du vocabulaire est loin d\'être neutre en ce qu\'il peut trahir le caractère imparfait du raisonnement juridique qui est au cœur de la motivation.
>
> *[Autre exemple de motivation non pertinente :]{.underline}*
>
> *Décider de la réduction des obligations résultant pour le débiteur d\'une clause pénale, motif pris du comportement de ce débiteur ou de sa situation financière, n\'est pas pertinent, une telle révision ne pouvant être ordonnée qu\'à raison du caractère « manifestement excessif ou dérisoire » de la clause au sens de l\'article 1231-5 du code civil (1152 ancien) et de la disproportion entre le montant de la peine conventionnellement fixé et celui du préjudice effectivement subi par le créancier^66^.*
>
> **EMPLACEMENT** :
>
> **L**ogiquement, la motivation est une partie du jugement située entre l\'exposé du litige, où le juge prête sa voix à celle des parties pour en rapporter les prétentions et moyens de façon neutre, et le dispositif, où le juge énonce sa décision. Partie intermédiaire, il est important de l\'introduire par un titre «Motivation»,
>
> «Motifs», «Sur ce,» ou encore «Sur quoi», afin d\'éviter toute ambiguïté sur le fait qu\'à ce stade du jugement, le juge s\'exprime dans une partie non plus expositive mais démonstrative.
>
> **STYLE ET TEMPS** :
>
> **L**a motivation est rédigée au présent de l\'indicatif, sous réserve des passages contenant le rappel d\'événements passés pour lequel sera employé de préférence le passé composé.
>
> Le style indirect où chacune des subordonnées est introduite par « Attendu que » (introduction de la majeure et de la mineure) ou par « Que » (introduction de la conclusion et des subordonnées autres que celles introduisant majeure ou mineure) et les fins de phrases terminées par un point-virgule, est de moins en moins usité par les juridictions du fond.
>
> ^64^ En ce sens, Civ. 2, 9 juillet 2009, n° 08-17007.
>
> ^65^ En ce sens, Civ. 2, 31 mai 2011, n° 09-72819.
>
> ^66^ En ce sens, Com. 11 février 1997, BC IV, n° 47.
>
> Le style direct est, en effet, privilégié précisément pour ne pas imposer une difficulté supplémentaire de lecture au justiciable parfois non assisté ni représenté par un avocat. De plus, le style indirect suppose que le juge en maîtrise parfaitement les règles (bon usage des « attendus », ponctuation).
>
> L\'analyse des jugements révèle, néanmoins, que la clarté de la motivation ne tient pas tant au choix du style qu\'à la logique et la rigueur du raisonnement et aux efforts de présentation du plan adopté.
>
> Aussi, dans un dossier complexe ou de difficulté moyenne, comportant notamment des questions de procédure et plusieurs chefs de prétentions au fond, il est préférable d\'introduire l\'examen de chacune des questions en litige par un -titre *(exemples :*
>
> *demande en résolution du contrat, Sur la demande de dommages et intérêts, Sur les dépens, l'article 700 du CPC et l'exécution provisoire.*
>
> Au sein même de l\'examen d\'une demande, des subdivisions éventuellement numérotées peuvent être apparentes *(ex : Sur la demande principale en réparation A/ sur l\'inexécution du contrat B/ sur le montant de la réparation C/ sur la garantie de l\'assureur).*
>
> **RECOMMANDATIONS :**
>
> La présentation du processus d\'analyse et de raisonnement, objet d\'une fiche à suivre, est de nature à aider le rédacteur du jugement dans l\'étape de construction puis de rédaction de la motivation.
>
> Toutefois, il convient d\'ores et déjà de relever que, pour s\'assurer du respect des caractères ci-dessus exposés que doit revêtir la motivation, notamment de son caractère complet, il importe pour le juge de procéder à une relecture attentive de sa décision et, au regard de l\'exposé des prétentions et des moyens, de s\'assurer qu\'il y est répondu en tout dans la motivation.
>
> Cette relecture permettra de même,

- Soit de relever une possible contradiction entre la partie exposé du litige, où tel fait est présenté comme constant, et la partie motivation où est pointée la contestation dont il fait l\'objet

- Soit de réaliser que tel fait porté dans les faits constants ne s\'avère pas pertinent car non utile à la solution du litige

- Soit enfin de relever les imperfections de la seule partie motivation à raison de l\'emploi d\'un vocabulaire du doute ou de l\'hypothèse ou d\'une contradiction entre deux développements.

#### B -- LE SYLLOGISME JURIDIQUE

> Dans le respect du principe dispositif le juge doit s\'attacher, en motivant le jugement, à répondre successivement à chacune des prétentions des parties, à examiner pour chacune d\'elles les différents moyens invoqués pour conclure, sur chaque prétention, dans des termes qui seront repris au dispositif de la décision.
>
> La démarche intellectuelle du juge dans la motivation de sa décision doit nécessairement le conduire, pour une prétention donnée et sous les réserves apportées plus loin, à :

- S'appuyer sur une règle de droit, prioritairement celle invoquée par les parties et, si elles sont au cœur de la discussion ou sont utiles à la solution du litige, en préciser soit les conditions d\'interprétation ou d\'application, soit le régime de preuve, cette partie du syllogisme étant **la prémisse majeure**

- Confronter cette règle ou ces règles aux faits et éléments de l\'espèce et répondre aux moyens soutenus par les parties, à l\'appui de la prétention ou en réplique à celle-ci, cette partie du syllogisme étant **la prémisse mineure**

- En tirer une conclusion qui sera la réponse ou un élément de réponse à la prétention, cette partie étant **la conclusion du syllogisme**.

- ​

> Pour la construction de la motivation, qui n\'est pas une construction abstraite mais un raisonnement qui s\'appuie sur un litige dont le juge est tenu de respecter les termes, les questions à garder à l\'esprit, que déjà l\'exposé du litige aura permis de repérer, sont notamment celles-ci :

##### Pour la prémisse majeure

> Un fondement juridique est-il invoqué par le demandeur ? Dans l\'affirmative, le juge doit en premier lieu s\'expliquer sur ce fondement et donc construire sur cette base un syllogisme. Dans la négative, donc à défaut de fondement invoqué, tenu de « trancher le litige conformément aux règles de droit qui lui sont applicables » (art. 12 alinéa 1^er^ du CPC), le juge doit rechercher à l\'application de quelle(s) règle(s) juridique(s) renvoie la question soumise à la juridiction.
>
> Quelles sont précisément les conditions d\'interprétation, d\'application et/ou de preuve qui sont au cœur de la discussion et sont déterminantes pour la solution du litige ?
>
> La prémisse majeure consistera en effet à poser la règle de droit et, si elles sont au cœur de la discussion ou sont utiles à la solution du litige, à préciser l\'interprétation qu\'il convient de lui donner, les composantes essentielles de la règle, spécialement celles sur lesquelles la discussion est ouverte, afin dans la mineure de vérifier leur application aux faits de l\'espèce et de répondre aux moyens.
>
> Aussi, la prémisse majeure sera construite :

- Soit sur un article issu du code civil ou d\'un autre texte légal ou réglementaire, article cité expressément et introduit par ces termes : *«Aux termes de tel article\...» ;*

- Soit sur le résumé que fait le juge d\'un article et de ses conditions d\'application : *« En application de tel(s) article(s)\... »* ; *« il résulte de la combinaison de tels articles\... »* ; s\'agissant de ce résumé, il a l\'avantage de laisser au juge une plus grande liberté de rédaction, sans être dépendant de la lettre du texte, mais l\'inconvénient, en cas de mauvaise qualité de rédaction, d\'être peu fidèle au texte et d\'en faire une mauvaise interprétation ; aussi, cette forme de rédaction est à manier avec précaution et suppose rigueur et qualité de rédaction ;

- Soit sur le rappel d\'un principe dégagé par la jurisprudence (ex : notions d\'enrichissement sans cause, de troubles anormaux de voisinage) qui, le cas échéant, est énoncé dans les termes dégagés par cette jurisprudence et que le juge reprend à son compte *(ex : « Le droit de propriété tel que défini à l\'article 544 du code civil est limité par le principe selon lequel nul ne doit causer à autrui un trouble excédant les troubles anormaux de voisinage »*).

> La majeure pourra donc être composée de plusieurs phrases, l\'une pour énoncer la règle ou le principe en cause, l\'autre ou les autres pour en préciser telle ou telle condition d\'application ou telle règle de preuve.
>
> Si les conditions d\'application de la règle en cause ont été définies par une jurisprudence constante, il est préférable de reprendre à son compte les termes de cette jurisprudence. Il est alors majoritairement admis
>
> que, sauf hypothèse particulière (ex : choix du juge de s\'en tenir à une jurisprudence encore minoritaire ou très récente, supposées moins connues, ou de s\'appuyer sur une décision de la CEDH ou de la CJUE), les références jurisprudentielles n\'ont pas à être mentionnées dans le jugement.
>
> [Exemple :]{.underline} soit *une action en paiement d\'une somme au titre d\'un prétendu prêt passé entre particuliers, prêt invoqué par un demandeur X contre son débiteur Y, lequel conteste la remise des fonds et fait valoir que la preuve du prétendu contrat de prêt n\'est pas rapportée en demande.*
>
> *Ce qui est au cœur des débats porte sur les conditions auxquelles un tel contrat de prêt de somme d\'argent entre particuliers doit répondre pour être formé et sur le point de savoir comment il doit être prouvé par celui qui l\'invoque. L\'examen de la jurisprudence sur la preuve du contrat de prêt permet de vérifier que le contrat de prêt entre particuliers est un contrat qualifié de contrat réel qui donc se forme par la remise de la chose. La preuve de cette remise, outre celle de la convention, seront à rapporter par celui qui invoque un tel contrat.*
>
> *La majeure peut alors être rédigée en ces termes :*
>
> *« Le contrat de prêt, s\'il n\'est pas consenti par un établissement de crédit, est un contrat réel qui se forme par la remise de la chose prêtée. Aussi, il appartient à la partie qui l\'invoque de rapporter non seulement la preuve de la convention mais encore celle de la remise de la chose qui en est l\'objet ».*
>
> *L\'application de cette règle de preuve suppose enfin de s\'interroger sur les modes de preuve admissibles pour chacun de ces éléments et donc sur leur nature, acte ou fait juridique, afin de vérifier, dans la mineure, si la preuve suffisante et de la convention et de la remise est ou non rapportée. Aussi, la majeure sera de préférence complétée comme suit en sa seconde phrase : « Il appartient à la partie qui l\'invoque de rapporter non seulement la preuve*
>
> *écrite de la convention en application de l\'article 1359 du code civil (article 1341 ancien) mais encore la preuve par tous moyens, s\'agissant d\'un fait juridique, de la remise de la chose objet de ladite convention ».*
>
> C\'est donc au juge, une fois réalisée l\'analyse du dossier, de dégager les éléments de fond, de qualification et/ou de preuve qui sont utiles à énoncer dans la majeure soit en réponse aux moyens des parties soit pour la solution au litige, sans toutefois excéder son office, ni violer le principe de la contradiction.
>
> C\'est dans ce domaine du droit que l\'office du juge est le plus grand. Pour une présentation détaillée de cette question essentielle mais complexe, il est renvoyé à la fiche relative précisément à l\'office du juge.

##### Pour la prémisse mineure

> Quels sont, après analyse, les éléments de fait que le dossier permet de tenir pour établis (éléments non contestés ou éléments contestés mais prouvés au regard des pièces produites par les parties ou éléments non expressément invoqués par les parties mais résultant des mêmes pièces) ?
>
> Quelle-est, au regard de ces éléments de fait et des principes juridiques en cause préalablement repérés et énoncés dans la majeure, la pertinence des moyens soutenus par les parties ?
>
> En conséquence, les conditions d\'application de la règle juridique en cause sont-elles ou non réunies ?
>
> La prémisse mineure consistera en effet à vérifier l\'application de la règle de droit aux faits de l\'espèce, en analysant les pièces, en appliquant les règles de preuve (charge de la preuve, mode de preuve) éventuellement énoncées dans la majeure s\'il est utile au raisonnement, enfin en répondant aux moyens des parties soit pour les déclarer fondés soit pour les rejeter.
>
> Aussi, elle sera souvent introduite par les termes : *« En l\'espèce, \... »*.
>
> Dans ce domaine du fait, le juge doit s\'en tenir aux éléments de fait produits aux débats, sauf à ordonner même d\'office une mesure d\'instruction (art. 143 du CPC). Une telle mesure ne doit toutefois pas tendre à pallier la carence d\'une partie dans l\'administration de la preuve (art. 146 du CPC).
>
> La qualité des développements consacrés à la mineure dépend très étroitement :

- De l\'analyse préalable du juge qui a dû notamment s\'interroger sur la qualification des actes et faits juridiques invoqués, sur les règles de preuve en cause et sur les composantes de la règle principale invoquée; il est donc essentiel, pour la pertinence du raisonnement, que les deux prémisses majeure et mineure se répondent parfaitement

- De l\'analyse des pièces par le juge qui doit éviter la dénaturation, par une interprétation maladroite notamment d\'un écrit. Pour cette analyse, il est essentiel d\'être très précis dans la motivation et très fidèle au contenu des pièces produites par les parties. Ainsi, le juge n\'hésitera pas à citer in extenso des passages d\'attestations importantes, de constats ou de rapports d\'expertise. Il n\'est pas utile au contraire, sauf dossier particulier, de mentionner les références de la pièce portées sur le bordereau de communication de pièces de l\'avocat qui la produit pour le compte d\'une partie.

##### Pour la conclusion du syllogisme

> Quelles conséquences juridiques tirer de cette confrontation des éléments de la cause aux règles juridiques dont dépend le cas d\'espèce ?
>
> La conclusion sera la réponse donnée par le juge soit directement à la prétention, soit à l\'une des questions juridiques soulevées par ladite prétention lorsque l\'examen de celle-ci suppose un raisonnement en plusieurs étapes qui seront autant de syllogismes successifs.
>
> Aussi, la conclusion sera nécessairement concise, se réduira généralement à une phrase unique débutant par ces termes : « En conséquence\... ».
>
> Il convient d\'être extrêmement rigoureux en posant la conclusion en ce qu\'elle doit être en parfaite cohérence avec les prémisses majeure et mineure mais également avec le titre choisi pour introduire le syllogisme dans le plan de motivation.
>
> *Ainsi, s\'il est saisi en procédure orale d\'une exception d\'incompétence non soulevée in limine litis, le juge construit sa motivation comme suit :*
>
> *Sur la recevabilité de l'exception d'incompétence soulevée par X*
>
> *Majeure : rappel des termes de l\'article 74 du code de procédure civile (les exceptions doivent, [à peine]{.underline} [d\'irrecevabilité]{.underline},* ê*tre soulevées avant toute défense au fond ou fin de non-recevoir) et complément sur l\'application de cette condition à la procédure orale (en procédure orale, c\'est l\'ordre de présentation à l\'audience, par la partie en cause, des exceptions, fins de non-recevoir et défenses au fond qui permet d\'apprécier la recevabilité des exceptions qu\'elle entend soulever)*
>
> *Mineure : en l\'espèce, soulevée à l\'audience du tribunal d\'instance par le défendeur, l\'exception l\'a été après seulement que cette partie a développé oralement ses défenses au fond ; aussi, cette [exception n\'a pas été soulevée in]{.underline} [limine litis]{.underline} conclusion : l\'exception d\'incompétence soulevée par X est [irrecevable]{.underline}*
>
> *A l\'inverse, conclure au rejet de cette exception ou au fait qu\'elle est mal fondée relèverait d\'une erreur de raisonnement puisque, dans les prémisses majeure et mineure, seule la recevabilité de l\'exception a été examinée.*

## *EXEMPLES DE SYLLOGISMES SIMPLES*

> **Exemple 1 dans un litige faisant appel aux règles du dépôt (cas évoqué dans la fiche sur les faits constants)**
>
> Soit la demande en réparation soutenue par le propriétaire d\'un véhicule, déposé chez un garagiste aux fins d\'intervention et n\'ayant pu être restitué à son propriétaire à raison d\'un vol commis à l\'occasion de ce dépôt dans les locaux du professionnel. Le vol est un fait établi et non contesté. Le défendeur conteste toutefois toute responsabilité dans la survenance du dommage dont se plaint son client et demandeur à l\'instance.
>
> *Le moyen de droit* invoqué en demande porte sur les obligations du dépositaire et sur sa responsabilité en cas d\'impossibilité de restitution du bien déposé.
>
> *Le moyen de fait* consiste pour le demandeur à soutenir l\'existence d\'un vol sur le temps du dépôt et donc l\'impossibilité de restitution du véhicule par le dépositaire.
>
> *Le moyen en réplique* consiste à contester toute responsabilité dans ce vol dont le défendeur n\'est ni l\'auteur ni le complice mais qu\'il a lui-même subi.

1)  **La construction de la majeure**

> Si le contrat liant les parties n\'est pas qualifié ou est mal qualifié par celles-ci, il est utile de débuter la motivation par la définition du contrat puis de s\'attacher à vérifier que les éléments de la cause permettent précisément de caractériser ce contrat.
>
> Lorsque, comme en l\'espèce, cette qualification est invoquée, n\'est pas contestée et qu\'elle est effectivement l\'exacte qualification (art. 12 CPC), la règle peut être énoncée sans autre explication liminaire. En effet, le fait de déposer le véhicule sur un temps déterminé et de le laisser à la garde du dépositaire caractérise un contrat de dépôt ici invoqué par le demandeur.
>
> Cette qualification permet facilement de restituer les obligations respectives des parties et les règles de preuve applicables.
>
> *(majeure: exposé de la règle de droit)*
>
> *Il résulte de l\'article 1915 du code civil que le dépositaire a la charge de garder la chose d\'autrui et de la restituer en nature à la fin du dépôt.*
>
> *De la combinaison des articles 1927 et 1933 du même code il ressort qu\'il doit, en cas de perte ou de détérioration de la chose déposée, prouver qu\'il y est étranger en établissant qu\'il a donné à cette chose les mêmes soins que ceux donnés à la garde des choses lui appartenant.*
>
> N.B: le seul rappel des termes de l\'article 1915 précité rendrait insuffisamment compte des obligations pesant sur le dépositaire. En effet, les articles 1927 et 1933 le complètent en indiquant que c\'est sur ce dépositaire que pèse la charge de prouver avoir rempli son obligation de bons soins dans la garde de la chose déposée et que pèsent les conséquences de toute détérioration ou disparition auxquelles il ne serait pas étranger.
>
> Il permet de répondre au moyen en réplique du dépositaire. Ces deux articles sont donc utiles l\'un et l\'autre à la construction du raisonnement juridique et à la recherche de la solution, tendant à savoir si en l\'espèce le dépositaire peut être tenu d\'indemniser le demandeur à raison de la non restitution du véhicule par le fait d\'un vol.

2)  **La construction de la mineure**

> La règle de droit étant identifiée et énoncée et les conditions de son application précisées, la démarche ultérieure du juge consiste à **réunir les éléments de constatation et d\'appréciation utiles à l\'application de cette règle**.
>
> *(mineure : confrontation des faits de l'espèce avec la règle de droit)*
>
> *En l\'espèce, il ressort des énonciations du procès-verbal de police, constatant le vol en date du ... commis dans les locaux de la société ..., que ceux-ci n\'ont subi aucune effraction. Il en résulte que le véhicule des demandeurs, confié quelques jours plus tôt pour une intervention, était entreposé sans aucune fermeture ni dispositif de sécurité particulier, ce qui caractérise une négligence manifeste de la part du gardien.*
>
> Ce faisant le juge s\'attache à vérifier si le défendeur a apporté, à la garde du véhicule déposé, les mêmes soins que ceux donnés à la garde des choses lui appartenant au sens des articles précités.
>
> C\'est l\'analyse des pièces, en l\'espèce des constatations contenues au procès-verbal de police, qui permet de procéder à cette vérification. Si toutefois le défendeur avait contesté les termes dudit procès-verbal et apporté des éléments de preuve contraire, s\'il avait encore invoqué telle ou telle autre mesure de sécurité prise par ses soins, il revenait au juge d\'y répondre dans sa motivation avant de conclure à un éventuel manquement du dépositaire à son obligation de garde de la chose confiée. En l\'espèce, faute de précautions élémentaires de sécurité, le défendeur n\'a pas rempli ses obligations de dépositaire et ne peut être tenu pour totalement étranger au vol du véhicule.

3)  **La conclusion**

> La conclusion de ce premier syllogisme est bien une conclusion portant sur la responsabilité, étape nécessaire du raisonnement qui, en ce domaine de responsabilité, qu\'elle soit délictuelle ou contractuelle, se décomposera souvent en deux temps, le premier sur le principe de la responsabilité, le second sur le montant de la réparation.
>
> Cette conclusion peut s\'énoncer comme suit :
>
> *(conclusion)*
>
> *La société doit être déclarée responsable du dommage subi par ....*
>
> Cette seule conclusion ne suffit certes pas à donner la réponse à la prétention principale du demandeur, lequel sollicite réparation par le versement d\'une somme à titre de dommages et intérêts. Le syllogisme précité, construit pour l\'examen de la responsabilité contractuelle du dépositaire, doit en conséquence être suivi, si cette responsabilité est retenue, d\'une recherche du dommage invoqué et, le cas échéant, de la détermination du montant de la réparation.
>
> Pour ce second temps du raisonnement, un syllogisme complet peut être conclu notamment quand, dans le régime de responsabilité en cause, s\'appliquent des règles spécifiques d\'indemnisation ou quand, en réponse à un moyen, il est utile de rappeler les règles générales d\'évaluation ou de réparation du dommage. En ce cas, les deux temps du raisonnement seront de préférence marqués par deux sous-titres intitulés « Sur la responsabilité du dépositaire » puis « Sur la réparation ». En dehors de ces hypothèses, les éléments de nature à caractériser le dommage invoqué (en l\'espèce, valeur du véhicule et préjudice de jouissance) peuvent être analysés sans autre rappel préalable et permettre de conclure sur la demande chiffrée en réparation.
>
> Ainsi, dans l\'exemple précité, les premiers éléments de motivation sur la responsabilité peuvent être suivis des autres motifs suivants :
>
> *Du fait du vol, X a perdu un véhicule dont la valeur vénale, basée sur la cote Argus régulièrement justifiée par la photocopie de la carte grise, par l\'attestation d\'assurance et par la production d\'une page de la revue Argus en date du\..., est de \....*
>
> *Ne disposant plus de son véhicule pour son séjour en ..., X justifie, par diverses factures en date du ... , avoir dû procéder à la location d\'un autre véhicule pour le montant de ....*
>
> *Sa demande en réparation, égale à l\'addition de ces deux sommes, est justifiée pour le montant de \..., au paiement duquel Y sera condamné avec intérêts au taux légal à compter du....*
>
> **Exemple 2 : action en dommages et intérêts pour résiliation unilatérale d\'un contrat**
>
> Soit une demande en paiement de dommages et intérêts pour résiliation unilatérale d\'un contrat de vente de véhicule automobile d\'occasion passé entre particuliers, ayant pris la forme d'un écrit par lequel Y... s'engageait à verser au plus vite à X, vendeur, un acompte de z euros et à prendre possession du véhicule avec paiement du solde du prix au plus tard à telle date déterminée.
>
> A cette date, Y a fait connaître à son vendeur ne pas entendre donner suite à son engagement faute d\'avoir pu réunir le financement nécessaire. Le demandeur soutient avoir manqué une nouvelle occasion de vente et demande réparation de son préjudice par l\'octroi de la somme que Y s\'était engagé à verser à titre d\'acompte, tandis que Y s\'oppose à cette prétention.
>
> *Le moyen* du demandeur consiste à soutenir que, par le fait du défendeur, le contrat n\'a pu s\'exécuter et qu\'il en est résulté des conséquences dommageables dont il entend obtenir réparation.
>
> *Le moyen en réplique* du défendeur porte sur une absence de financement nécessaire au paiement du prix et, donc, sur une absence de toute obligation de sa part au titre de ce contrat.
>
> Le contrat liant les parties n\'est pas contesté en sa qualification. C\'est effectivement un contrat de vente. Aussi, il importe de rappeler à quelle(s) condition(s) se forme le contrat de vente et, s\'il apparaît que le contrat a en l\'espèce été régulièrement formé, dans quelles conditions il pouvait être résilié.
>
> Deux syllogismes distincts peuvent être construits, l\'un sur la formation du contrat (rappel du principe et application au cas d\'espèce pour conclure à la réalité d\'un contrat de vente formé en l\'espèce), l\'autre sur la résiliation fautive ou non (rappel du principe et application au cas d\'espèce). Toutefois, dans une espèce
>
> simple comme celle ci-dessus exposée, ces deux étapes du raisonnement peuvent donner lieu à la construction d\'un seul syllogisme :
>
> *(majeure: exposé de la règle de droit)*
>
> *Aux termes de l\'article 1583 du code civil, la vente est parfaite entre les parties et la propriété est acquise de droit à l\'acheteur à l\'égard du vendeur, dès qu\'on est convenu de la chose et du prix, quoique la chose n\'ait pas encore été livrée ni le prix payé. En application des dispositions de l'article 1103 du même code, les conventions ne peuvent être révoquées que du consentement mutuel de ceux qui les ont faites.*
>
> *(mineure: confrontation des faits de l'espèce avec la règle de droit)*
>
> *Il ressort de l\'écrit en date du ... que Y\... a acquis le véhicule de X\... pour le prix de z euros. Aucune condition suspensive ou résolutoire de recours à un crédit n\'a été stipulée.*
>
> *(conclusion)*
>
> *Y\... ne pouvait donc renier son engagement et résilier unilatéralement le contrat. X\... est dès lors en droit d\'obtenir réparation du préjudice que lui cause cette rupture.*
>
> Comme dans l\'exemple précédent, pour répondre à la demande de dommages et intérêts, ce syllogisme devra être suivi d\'un examen des éléments de nature à caractériser le dommage invoqué et à se déterminer sur la réparation sollicitée.
>
> **Exemple 3 : action liée à des réparations locatives**
>
> *Soit une action en réparations locatives engagée par le bailleur à l\'encontre du locataire sortant dans le cadre d\'un bail d\'habitation soumis au régime de la loi n° 89-462 du 6 juillet 1989 ; le bailleur se plaint du mauvais état des revêtements des murs et sols constaté lors de l\'état des lieux de sortie ; le locataire sortant s\'oppose à la demande en réparation en faisant valoir que les lieux étaient déjà vétustes à son entrée douze ans plus tôt et que l\'usure naturelle du temps a encore fait son œuvre.*
>
> *La majeure doit être construite au regard des obligations du locataire quant à l\'entretien des lieux loués et peut être complétée par les conditions d\'application, en jurisprudence, de cette obligation.*
>
> *La mineure sera une application des principes ainsi dégagés aux faits de l\'espèce, au regard de l\'état des lieux à la sortie mais encore à l\'entrée et de la durée de la location.*
>
> *La conclusion permettra de dégager la solution donnée à la prétention tendant à mettre à la charge du locataire le coût de la remise en état.*
>
> *(majeure : exposé de la règle de droit = le locataire n\'est pas tenu de répondre d\'un état de vétusté du logement loué ; complément = une usure normale de plusieurs années sur les revêtements, sans remise à neuf par le bailleur, est assimilable à la vétusté)*
>
> *L\'article 7 de la loi n° 89-462 du 6 juillet 1989 prévoit notamment que le locataire est obligé de prendre à sa charge l\'entretien courant du logement et l\'ensemble des réparations locatives, sauf si elles sont occasionnées par vétusté, malfaçon, vice de construction, cas fortuit ou force majeure.*
>
> *L\'usure normale des peintures, papiers peints et parquets est assimilable à la vétusté lorsque aucune remise à neuf de ces éléments n\'a été faite depuis de nombreuses années.*
>
> *(mineure : application aux faits de l\'espèce = au cas d\'espèce, c\'est la vétusté qui est à l\'origine de l\'état des revêtements dont se plaint le bailleur)*
>
> *En l\'espèce, si l\'établissement de l\'état des lieux de sortie, établi contradictoirement le\..., a mis en évidence l\'état défraîchi des peintures et papiers peints et l\'usure de la moquette plus spécialement dans le couloir d\'entrée, le séjour et l\'une des chambres, ce constat est intervenu après douze années de location. L\'état d\'entrée dans les lieux, établi le\..., ne mentionnait déjà, s\'agissant des revêtements des murs et sols dans l\'ensemble du logement et notamment dans les pièces précitées, qu\'un état moyen.*
>
> *Le constat de sortie, dont se prévaut le bailleur et demandeur à la présente instance, ne révèle donc pas un manquement du preneur à son obligation d\'entretien mais une dégradation due à la vétusté, de telle sorte que la remise en état ne doit pas être mise à la charge du locataire sortant.*
>
> *(conclusion: la demande du bailleur n\'est pas fondée et doit être rejetée)*
>
> *En conséquence la demande de X, bailleur, aux fins de prise en charge par Y de la somme de Z au titre de réparations locatives, sera rejetée.*

## *EXEMPLE DE SYLLOGISME PLUS COMPLEXE*

> Certaines prétentions, complexes en ce qu\'elles supposent l\'examen de plusieurs questions juridiques dépendantes les unes des autres, pourront conduire à construire plusieurs syllogismes juridiques successifs ou à l\'intégration, dans un syllogisme principal, d\'une nouvelle majeure et d\'une nouvelle mineure.
>
> ***[Sur la servitude de passage]{.underline}** (cas évoqué dans les fiches consacrées à l\'exposé des éléments de procédure)*
>
> *(majeure : exposé de la règle de droit)*
>
> *En application des dispositions de l\'article 685-1 du code civil, la cessation de l\'enclave fait disparaître la servitude légale de passage instituée par l\'article 682 du même code. Cette cessation laisse toutefois subsister la servitude conventionnelle, même établie pour cause d\'enclave, dès lors que la convention ne s\'est pas contentée d\'entériner une mesure légale mais a organisé au profit du fonds dominant un droit réel particulier tel que son utilité demeure en cas de cessation de l\'état d\'enclave.*
>
> *(mineure : confrontation des faits de l'espèce avec la règle de droit)*
>
> *En l\'espèce, l\'acte notarié en date du ... prévoyait à la fois la conservation, par le propriétaire du fonds dominant, de la moitié indivise du chemin cadastré\..., qui relie le fonds servant des époux ... à la voie publique, et une servitude de passage sur ce dernier fonds permettant d\'accéder audit chemin indivis.*
>
> *Il s\'ensuit que la servitude ainsi créée revêtait un intérêt particulier pour son bénéficiaire, indépendamment de tout état d\'enclave, en ce qu\'elle autorisait l\'accès non pas à la voie publique mais à un chemin resté propriété indivise du titulaire de la servitude et qui, sans cet accès, perdrait manifestement toute utilité pour lui.*
>
> *La servitude litigieuse doit dès lors s\'analyser en une servitude conventionnelle, que l\'acquisition par la défenderesse de parcelles contiguës dotées d\'un accès séparé à la voie publique ne peut faire disparaître.*

###### *Au surplus, le propriétaire d\'un fonds peut prétendre à l\'existence d\'une servitude par destination du* père de famille, si le propriétaire commun a révélé, par l\'état dans lequel il a mis lui-même les lieux, son intention d\'asservir l\'un des deux fonds d\'une charge au profit de l\'autre. Tel est bien le cas en l\'espèce.

###### (*avec ce paragraphe, on insère une nouvelle majeure et une mineure au sein du syllogisme, pour* renforcer la motivation, mais la conclusion ci-dessous est commune)

> *(conclusion) Les demandes des époux \... ne peuvent donc qu\'être rejetées.*

## *EXEMPLE DE SYLLOGISME SIMPLIFIE*

> Certains syllogismes, tels ceux construits pour l\'examen des dépens, des demandes formées au titre de l'article 700 du CPC et de l'exécution provisoire, lorsqu\'elles sont évoquées dans la motivation, peuvent être présentés en des formes très condensées (on met ainsi dans une seule phrase majeure, mineure et conclusion) mais la logique juridique de base est toujours la même.
>
> **[Sur les dépens]{.underline}**
>
> *En application des dispositions de l'article 696 du code de procédure civile, Y, partie perdante, sera condamnée aux dépens de l\'instance.*
>
> (*Syllogisme abrégé : la majeure, réputée connue, se réduit à un rappel de l'article 696 du code de procédure civile et une seule phrase englobe d\'une part la majeure qu\'est le visa de l\'article, d\'autre part la mineure qu\'est la désignation de la partie perdante et enfin la conclusion qui est la condamnation de cette partie aux dépens)*
>
> *Le même syllogisme complet serait celui-ci :*
>
> *(majeure): En application de l\'article 696 du code de procédure civile, la partie perdante est condamnée aux dépens de l\'\'instance.*
>
> *(mineure): En l\'espèce, Y est la partie perdante du litige.*
>
> *(conclusion): Elle sera en conséquence condamnée aux dépens de l\'instance.*

## *EXEMPLE DE SYLLOGISME IMPLICITE OU INVERSE*

> Il est encore possible pour le juge d\'inverser la construction du syllogisme, en énonçant la conclusion avant le rappel du texte et avant son application aux faits de l\'espèce ou en se contentant d\'un simple visa du texte dans la conclusion du syllogisme.
>
> *Proposition de rédaction : La responsabilité décennale, telle que résultant de l\'application de l\'article 1792 du code civil, de la SA X sera retenue à l\'égard de Monsieur et Madame Y, maîtres de l\'ouvrage, dans la mesure où les désordres constatés par l\'expert judiciaire compromettent effectivement la solidité de l\'immeuble situé à \...* (suit alors l'analyse des pièces justifiant cette conclusion)

#### C- L\'ORDRE D\'EXAMEN DES PRETENTIONS

> L\'ordre logique d\'examen des questions juridiques est celui-ci :

- Les mesures d\'administration judiciaire si le juge, dans sa décision, est conduit à en ordonner (ex : jonction d\'instances qui n\'aurait été préalablement ordonnée ni en cours de mise en état ni à l\'audience)

- Les exceptions de procédure et prioritairement les exceptions d\'incompétence en ce que l\'incompétence éventuelle du juge, si elle devait être constatée, ne lui permettrait de statuer sur aucune autre question dans le litige en cause et doit en conséquence, lorsqu\'elle est soulevée, être examinée en premier lieu

- Les fins de non-recevoir

- Les prétentions du ou des demandeurs au fond (prétention principale puis, s\'il n\'est pas fait droit à celle-ci, et s'il y en a, prétentions subsidiaires)

- Les prétentions au fond du ou des défendeurs (demandes reconventionnelles)

- Les dépens,l' indemnité au titre de l\'article 700 du CPC et l'exécution provisoire si elle est sollicitée ou si le juge entend l\'ordonner d\'office^67^.

> Cet ordre sera très généralement celui qui se retrouvera dans le dispositif^68^ et qui aura été repris dans l\'exposé du litige et spécialement dans le rappel des prétentions des parties.
>
> Toutefois, un tel ordre comme la stricte cohérence dans l\'ordonnancement des questions juridiques entre les trois parties de la décision, exposé du litige, motivation et dispositif, ne seront pas toujours respectés.
>
> Ainsi,

- Si une partie soulève une exception de procédure non pas in limine litis comme l\'impose l\'article 74 du code de procédure civile mais après une défense au fond ou une fin de non-recevoir, l\'exposé du litige devra reproduire l\'ordre adopté par cette partie ; à l\'inverse, dans sa motivation, le juge procédera nécessairement à l\'analyse de cette exception avant toute fin de non-recevoir et toute question de fond

- Le juge peut être amené, pour statuer sur une exception de compétence, à trancher une question de fond, hypothèse prévue expressément à l\'article 95 du code de procédure civile et qui, le cas échéant, conduit dans la motivation à traiter simultanément la question de fond et la question de compétence

- Une fin de non-recevoir peut se rattacher exclusivement à une demande incidente, soit reconventionnelle soit additionnelle ; ainsi, s\'il est soutenu par le demandeur au principal l\'irrecevabilité d\'une demande reconventionnelle en application de l\'article 70 du code de procédure civile et en raison de l\'absence de lien suffisant entre celle-ci et la demande originaire, le juge motivera sur cette fin de-non-recevoir au stade de l\'examen de ladite demande reconventionnelle, soit après l\'examen au fond des demandes principales du demandeur à l\'instance

- Certains dossiers peuvent justifier exceptionnellement l\'examen d\'une demande reconventionnelle avant celui de la demande principale ; ainsi dans le contentieux familial et notamment pour les divorces, les textes peuvent imposer que la prétention du défendeur soit traitée avant celle du demandeur. C\'est ce que

> ^67^ Il est à noter, s\'agissant des mesures relatives aux dépens, à l\'indemnité au titre de l\'article 700 du CPC et de l\'exécution provisoire que, s\'agissant de l\'exercice d\'un pouvoir discrétionnaire du juge qui les ordonne (sauf dépens mis à la charge d\'une partie gagnante), elles peuvent être ordonnées au dispositif de la décision sans mention particulière dans les motifs. L\'ordre d\'examen des dépens et de l\'indemnité au titre de l\'article 700 du CPC dans les motifs peut également être inversé ; toutefois, la logique des textes permet de mieux raisonner sur l\'indemnité une fois désignées la partie perdante et la partie condamnée aux dépens et donc une fois examinée la question des dépens.
>
> ^68^ Sous réserve de ce qui sera indiqué sur la fiche « dispositif » concernant les dépens*.*
>
> prévoit l\'article 246 du code civil en posant comme principe que, si une demande pour altération définitive du lien conjugal et une demande pour faute sont concurremment présentées, le juge examine en premier lieu la demande pour faute. Et, s\'il rejette celle-ci, le juge statue sur la demande en divorce pour altération définitive du lien conjugal.

# FICHE VIII : LE DISPOSITIF

> **FONDEMENT TEXTUEL**
>
> L'obligation de formuler sous forme de dispositif l\'ensemble des solutions, données par le juge aux différentes questions litigieuses qui lui sont soumises dans une affaire donnée, résulte de l\'article 455 du Code de procédure civile, aux termes duquel le jugement énonce la décision sous forme de dispositif.
>
> Le dispositif est la dernière partie du jugement et la dernière étape de sa rédaction. Plus simple dans sa construction que les autres parties, notamment la partie motivation, elle n\'en est pas moins fondamentale car y est attachée l\'autorité de la chose jugée. La qualité de rédaction de cette dernière partie est en conséquence essentielle en ce qu\'elle conditionne la bonne exécution de la décision.
>
> **DÉFINITION**
>
> C'est la réponse donnée par le juge aux prétentions respectives des parties, préalablement exposées dans la partie exposé du litige puis examinées dans la motivation, et le rappel des conclusions ayant clôturé les syllogismes juridiques construits sur chacune des prétentions.
>
> Aussi, le dispositif doit être en parfaite cohérence avec les autres parties du jugement, tant avec l\'exposé du litige, en ce sens qu\'à chacune des prétentions rappelées dans cet exposé doit répondre un énoncé au dispositif de la décision, qu\'avec la motivation en ce que les solutions dégagées en fin de syllogisme juridique pour chacune des prétentions doivent se retrouver dans le dispositif de la décision.
>
> **CARACTÈRES GÉNÉRAUX**
>
> **Le dispositif doit être à la fois :**

- **Complet** dans la mesure où chaque prétention doit trouver sa solution en cette dernière partie du jugement.

> A la relecture du jugement, le juge doit donc veiller à ce que le dispositif fasse écho à l\'exposé des prétentions réalisé en première partie de jugement et aux solutions dégagées pour chacune d\'elles dans la motivation. La grille d\'analyse du dossier, présentée plus haut et comportant notamment en une première colonne les différentes prétentions des parties et en une dernière colonne les solutions pour chacune de ces prétentions, peut être utilement exploitée pour éviter tout oubli lors de la rédaction du dispositif et de la relecture du jugement. Un tel oubli pourrait justifier une requête en omission de statuer de la part d\'une partie.
>
> Une solution qui ne serait pas reproduite au dispositif, quand bien même la demande aurait été examinée dans les motifs et la solution dégagée en fin de syllogisme juridique, serait une prétention sur laquelle le juge n\'aurait pas statué. En effet, la jurisprudence ne reconnaît plus de valeur aux motifs décisoires et seules les mentions portées au dispositif de la décision ont autorité de la chose jugée^69^.
>
> *^69^ En ce sens, Ass.plén., 13 mars 2009, n° 08-16033*
>
> Aussi si le juge, ayant reconnu une partie X tenue à réparation, ordonne une mesure d\'instruction telle une expertise avant dire droit sur le préjudice subi par Y et sur la créance de réparation, il doit mentionner au dispositif de sa décision l\'obligation à réparation de la partie X. Le seul énoncé de la condamnation de la partie X à réparer le préjudice dans les motifs serait insuffisant pour revêtir de l\'autorité de la chose jugée cette obligation, dès lors qu'elle n'est pas précisée dans le dispositif. La rédaction de ce dispositif, dans une telle hypothèse, comportera ces mentions :
>
> *« Dit X tenu à réparation des conséquences dommageables de l\'accident dont Y a été victime le.. ;*
>
> *Avant dire droit sur le préjudice, ordonne une expertise confiée à ... avec pour mission de\... ».*
>
> C\'est encore au dispositif que les mesures prononcées par le juge en vertu d\'un pouvoir discrétionnaire^70^, mesures que par hypothèse le juge n\'est pas tenu d\'examiner dans la motivation, doivent être énoncées. Il en est ainsi de l\'opportunité d\'un sursis à statuer, hors les cas où cette mesure est prévue par la loi, ou de l\'opportunité d\'une mesure d\'instruction autre que l\'expertise, hors les cas où elle est prescrite par la loi, du prononcé d\'une astreinte ou du rejet d\'une demande d\'astreinte par le juge qui statue sur l\'obligation^71^, du rejet d\'une demande de délais de grâce sur le fondement soit de l\'article 1343-5 du code civil (ancien 1244-1 du code civil) soit des textes relatifs à l\'expulsion, du refus de modifier une clause pénale contractuelle pour la modérer ou l\'augmenter^72^, de la fixation du point de départ des intérêts au taux légal sur une indemnité à une autre date que celle de la décision en application de l\'article 1231-7 du code civil (ancien 1153-1 du code civil), de l\'allocation d\'une indemnité au titre de l\'article 700 du code de procédure civile quand une telle indemnité est sollicitée, de la condamnation aux dépens d\'une partie qui succombe au moins partiellement en ses prétentions^73^, du prononcé de l\'exécution provisoire.
>
> Toutes ces décisions seront en conséquence portées au dispositif de la décision sans qu\'il y ait nécessité pour le juge de s\'en expliquer préalablement dans la motivation.
>
> Le dispositif doit être complet, y compris en ce que chaque solution énoncée doit être suffisamment explicitée en tous ses effets.
>
> Ainsi, une annulation d\'une vente ou sa résolution^74^ emportent différents effets que doit énoncer le dispositif de la décision. En cas d\'annulation d\'une vente, s\'il est ordonné au vendeur de restituer à l\'acheteur le prix de la vente, il devra également être ordonné à ce dernier de restituer au vendeur la chose objet de la vente litigieuse. Aussi, il sera indiqué :
>
> ^70^ Le pouvoir discrétionnaire se caractérise notamment par le fait que le juge, exerçant ce pouvoir, n\'est pas tenu de motiver spécialement sa décision ni de répondre aux moyens des parties, à la différence du pouvoir souverain, qui échappe au contrôle de la Cour de cassation quant à la valeur de la motivation mais non quant à un éventuel vice intellectuel (contradiction de motifs, motifs dubitatifs et hypothétiques) susceptible de l\'affecter. Dans l\'exercice d\'un pouvoir souverain, le juge doit donc motiver sa décision. Dans un exercice discrétionnaire, il n\'y est pas tenu et les éventuels motifs erronés qu\'il pourrait réserver à sa décision seront considérés par la Cour de cassation comme surabondants et ne donneront pas lieu à cassation.
>
> ^71^ Le juge de l\'exécution qui statue sur une demande d\'astreinte susceptible d\'assortir l\'obligation prononcée par un autre juge statue pour sa part en vertu d\'un pouvoir souverain et non discrétionnaire.
>
> ^72^ A l\'inverse, s\'il entend modérer ou augmenter la clause pénale, le juge doit motiver sur son caractère manifestement excessif ou dérisoire au sens de l\'article 1231-5 du code civil (ancien1152 du code civil).
>
> ^73^ La condamnation aux dépens d\'une partie non perdante suppose quant à elle, ainsi qu\'il est dit à l\'article 696 du CPC, une décision motivée.
>
> ^74^ Deux termes à ne pas confondre et qui, notamment au dispositif, ne pourront pas être employés l\'un pour l\'autre en ce que le premier sanctionne l\'absence d\'une condition de validité du contrat au moment de la conclusion et le second un défaut d\'exécution d\'une obligation prévue au contrat.
>
> *« Prononce l\'annulation du contrat de vente de... (désignation du bien objet de la vente) intervenue le\... (date de l\'acte de vente) entre X et Y (désignation des parties à la vente) ;*
>
> *Condamne X (vendeur) à payer à Y (acheteur) la somme en principal de... (prix de vente) avec intérêts au taux légal à compter du\... (point de départ des intérêts) ;*
>
> *Condamne Y (acheteur) à restituer à X (vendeur) le\... (bien objet de la vente) ; »*
>
> En matière familiale, où les difficultés d\'exécution peuvent être multiples et sources de nombreuses controverses susceptibles d\'alimenter de nouveaux contentieux entre les parties, parfois promptes à interpréter la décision et à discuter le moindre détail, avec plus ou moins de bonne foi, nombreuses peuvent être les précisions apportées au dispositif, accessoirement aux condamnations au paiement d\'une pension alimentaire (modalités de paiement, indexation) ou aux dispositions constatant ou ordonnant les modalités d\'exercice de l\'autorité parentale sur l\'enfant ou octroyant l\'exercice d\'un droit de visite et d\'hébergement. Le dispositif d\'une décision constatant un exercice conjoint de l\'autorité parentale peut en conséquence être ainsi rédigé :
>
> *« Dit que les parents exercent en commun l\'autorité parentale à l\'égard des deux enfants mineurs (prénoms et dates respectives de naissance des enfants), ;*
>
> *Rappelle que, pour l\'exercice de l\'autorité parentale en commun, le père et la mère doivent prendre ensemble et d\'un commun accord toutes les décisions importantes concernant la vie des enfants et notamment la scolarité et l\'orientation professionnelle, les sorties du territoire national, la religion, la santé, les autorisations à pratiquer des sports dangereux ;*
>
> *Dit que le parent chez lequel résident effectivement les enfants pendant la période de résidence à lui attribuée est habilité à prendre toute décision nécessitée par l\'urgence (intervention chirurgicale notamment) ou relative à l\'entretien courant des enfants ; »*
>
> Pour autant, le dispositif doit se réduire à son seul objet, à savoir comporter l\'énoncé des décisions prises par le juge dans l\'affaire en cause. La motivation n\'a pas sa place dans le dispositif. Ainsi, si telle partie X est condamnée au paiement de telle somme à titre de dommages et intérêts en inexécution d\'un contrat, il suffit d\'énoncer au dispositif *« Condamne X à payer à Y la somme de z avec intérêts ....»* et il est inutile et à éviter de poursuivre par des précisions sur les motifs de la condamnation (*« en ce qu\'il a\... »).*
>
> De telles précisions font l\'objet de la motivation et n\'ont pas lieu d\'être reprises au dispositif de la décision. De même, en début de dispositif, le visa des articles appliqués n\'est pas utile et n\'a pas lieu d\'être.
>
> **\* Cohérent avec la motivation**
>
> Le dispositif ne doit pas comporter de contradiction avec les solutions dégagées en fin de syllogisme juridique dans la motivation, lors de l\'examen de chacune des prétentions respectives des parties. Une éventuelle erreur ne pourrait être rectifiée par le même juge par la voie de la rectification d\'erreur matérielle que si elle s\'avérait être effectivement une erreur ou une omission purement matérielle au sens de l\'article 462 du code de procédure civile.
>
> Ainsi, si le juge saisi d\'une fin de non-recevoir a, au terme de sa motivation, entendu la déclarer irrecevable ou la rejeter, le dispositif de la décision doit très exactement retraduire le sens de la solution
>
> dégagée dans les motifs et déjà énoncée dans la conclusion du syllogisme qui lui a été consacré. Il en résulte que,

- En cas de fin de non-recevoir irrecevable, le dispositif doit énoncer *« Déclare [irrecevable]{.underline} la fin de non-recevoir soulevée par\... et tirée de\... »*

- En cas de fin de non-recevoir non fondée, le dispositif doit énoncer *« [Rejette]{.underline} la fin de non-recevoir soulevée par\... et tirée de\...»* ou *«Déclare recevable l\'action engagée par\... »*

> Cette exigence de cohérence entre la motivation et le dispositif trouve une autre traduction.
>
> En effet, l\'autorité de la chose jugée ne s\'attache qu\'aux seuls énoncés du dispositif qui trouvent leur soutien nécessaire dans la motivation^75^. Aussi, la mention *« Rejette toutes autres ou plus amples demandes*
>
> *»* contenue au dispositif ne doit pas induire en erreur sur sa portée. L\'autorité de la chose jugée ne peut s\'attacher à une telle décision de rejet que dans la mesure où elle porte sur des prétentions examinées dans la motivation. A l\'inverse, le juge ne peut être tenu pour avoir statué sur une prétention ainsi rejetée dans le dispositif si ce rejet ne trouve pas son soutien nécessaire et donc des explications dans la motivation. L\'emploi de la mention précitée est en conséquence à éviter.
>
> De même, il est inutile de déclarer telle demande *« recevable »* ou *« régulière en la forme »* si, ni la régularité, ni la recevabilité n\'ont été contestées.
>
> En outre, le juge qui fait droit à une exception de nullité affectant l\'acte introductif d\'instance ou à une fin de non-recevoir affectant l\'action, ou qui dit telle opposition à jugement, à contrainte ou à ordonnance d\'injonction de payer irrecevable, ne doit au dispositif énoncer que cette décision soit de nullité de l\'acte, soit d\'irrecevabilité de l\'action, soit d\'irrecevabilité de l\'opposition. En aucun cas il ne peut dire la même demande ou la même opposition *« au surplus mal fondée »* puisqu\'en effet, par nature, sa décision ne lui permet pas de statuer au fond sauf à commettre un excès de pouvoir, motif de cassation.

- **Précis**

> Dans la mesure où il est le siège de l\'autorité de la chose jugée, le dispositif de la décision doit être en tous points complet et précis, notamment :

- **Quant à l\'identité des parties** (une partie personne physique doit y être désignée par son prénom et son nom et les termes d\'*« époux X »* ou de « *consorts Y »* doivent être évités en ce qu\'ils ne permettent pas une identification suffisante des parties concernées ; une personne morale doit être désignée par sa forme juridique et sa raison sociale)

> Certes, les identités sont rappelées sur la première page du jugement, rédigée par le greffier sous le contrôle du juge. Toutefois, le dispositif doit énoncer tout ce qui est nécessaire à l\'exécution de la décision et une identité incomplète au dispositif risque de compromettre cette exécution, a fortiori dans les affaires opposant tels membres de la famille à tels autres, où donc plusieurs parties portent le même nom.
>
> De même, si le terme d\'indivision suivi du nom donné à celle-ci peut être utile à employer dans le corps de la motivation, au dispositif ce sont les noms et prénoms de chacun des membres de cette indivision qui doivent être repris, une indivision n\'ayant pas de personnalité juridique et une exécution de la décision ne
>
> ^75^ En ce sens, Ass. Plén. 2 nov. 1999, pourvoi n° 97-17107.
>
> pouvant être engagée contre ou pour l\'entité « indivision » mais seulement contre ou pour chacun de ses membres.
>
> Enfin, si une partie est condamnée en raison d\'une qualité particulière (ex : en qualité de caution ou de tuteur du débiteur principal), il est utile de mentionner cette qualité. Ainsi, le dispositif énoncera : *« Condamne X, ès qualités de caution (ou ès qualités de tuteur de\...), à payer à W ».*

- **Quant aux biens, objet de la décision**, spécialement en cas d\'action en contestation d\'un droit réel immobilier :il convient de préciser la nature de l\'immeuble, le lieu précis de situation, et les références cadastrales compte-tenu des exigences de publicité à la conservation des hypothèques résultant du décret du n° 55-22 du 4 janvier 1955

- **Quant à la nature même de la condamnation**, en ce qu\'une annulation de vente n\'est pas une résolution, une condamnation au paiement des loyers n\'est pas à confondre avec une condamnation au paiement d\'une indemnité d\'occupation (due une fois seulement que l\'occupant des lieux a perdu tout titre d\'occupation de ceux-ci), une pension alimentaire n\'est pas une prestation compensatoire ; aussi, les termes employés au dispositif de la décision doivent être parfaitement exacts et correspondre à la solution préalablement dégagée dans la motivation

- **Quant aux condamnations pécuniaires portant intérêts** :il y a lieu de préciser la nature de ces intérêts (au [taux]{.underline} légal ou au taux conventionnel), le taux en question si c\'est un taux conventionnel, [le point]{.underline} [de départ et l\'assiette]{.underline}.

> La mention « *intérêts de droit »* est à éviter, la mention exacte étant celle d\'intérêts au taux légal et, lorsque le juge décide de porter ceux-ci à un point de départ autre que la date du prononcé de la décision ainsi que le permet l\'article 1231-7 du code civil (ancien 1153-1 du code civil), il doit préciser ce point de départ au dispositif.
>
> Ainsi, en cas de condamnation au paiement d\'une indemnité, l\'énoncé du dispositif peut être celui-ci : *« Condamne X (prénom, nom) à payer à Y (prénom, nom) la somme z (en l\'absence d\'autre précision et en application de l\'article 1231-7 précité du code civil, ces intérêts courent au taux légal à compter de la décision) ou la somme z avec intérêts au taux légal à compter de\... (telle date antérieure à la décision)*. »
>
> En cas de condamnation au paiement d\'une somme résultant soit de la loi soit du contrat des parties, l\'énoncé du dispositif peut être celui-ci : *« Condamne X (prénom, nom) à payer à Y (prénom, nom) la somme z avec intérêts (non pas de droit mais) au taux légal à compter de\...(telle date correspondant à la date de la mise en demeure ou de tout acte valant interpellation suffisante du débiteur au sens de l\'article 1231-6 du code civil ) ou au taux conventionnel de... (taux prévu au contrat) sur (assiette) à compter du\... (point de départ à déterminer au regard du contrat en cas de taux conventionnel) ».*

- **Quant aux éventuelles condamnations** à une obligation de payer, de faire ou de ne pas faire

> **assorties d\'une astreinte**, il convient de préciser :

- la nature exacte de l'obligation ou de l'interdiction^76^,

- la [nature de l\'astreinte]{.underline} à savoir provisoire ou définitive étant précisé que dans le silence de la décision l\'astreinte est qualifiée de provisoire et qu\'une astreinte ne peut être initialement que provisoire,

> ^76^ Ainsi, condamner sous astreinte à prendre « toutes mesures nécessaires » à la poursuite d'une activité est trop imprécis (en ce sens, Civ. 2^ème^, 14 octobre 2004, n° 02-15.639.

- le [montant de l\'astreinte et]{.underline} sa [périodicité,]{.underline}

- [la durée]{.underline} sur laquelle court l\'astreinte même si cette mention de la durée n\'est pas impérative pour l'astreinte provisoire mais préférable pour éviter que des astreintes ne courent sur des durées très longues et ne conduisent à des liquidations pour des montants importants et hors de mesure avec la valeur de l\'obligation principale,

- le [point de départ de l\'astreinte]{.underline} étant précisé qu\'elle ne peut courir avant la signification de la décision mais peut être décidée pour un point de départ postérieur notamment à l\'expiration de tel délai donné au débiteur de l\'obligation pour s\'exécuter,

- la [mention éventuelle aux termes de laquelle la juridiction qui prononce l\'astreinte se réserve le]{.underline} [pouvoir]{.underline} [de la liquider]{.underline} étant précisé qu\'à défaut de cette mention expresse c\'est le juge de l\'exécution qui sera seul compétent pour connaître de la liquidation^77^

> Ainsi, une condamnation sous astreinte à une obligation notamment de démolir un mur qui empiète sur le terrain du voisin, peut être rédigée comme suit au dispositif de la décision :
>
> *« Condamne X (débiteur de l\'obligation) à abattre sur (telle longueur ou en sa totalité) le mur en briques (tous éléments utiles de désignation du mur) situé à l\'Est de sa propriété (emplacement du mur à abattre) sise\... (lieu de situation de la propriété du débiteur de l\'obligation et propriétaire du mur) et qui empiète sur la propriété de Y sise\... en sa partie... ce, dans un délai de trois mois à compter de la signification de la présente décision et sous astreinte provisoire de z (montant de l\'astreinte journalière) par jour de retard passé ce délai pendant une durée de X mois ;*
>
> *« Dit que le présent tribunal se réserve le pouvoir de liquider l\'astreinte »* (disposition facultative, en l\'absence de laquelle le juge de l\'exécution sera compétent pour la liquidation)
>
> En cas d\'interdiction de faire, l\'astreinte sera prononcée à un montant z par infraction constatée à ladite interdiction *(« ... sous astreinte provisoire de z par infraction constatée à compter de la signification de la présente décision et pendant une durée de X mois »).*

- **Quant aux éventuels délais de paiement** accordés par le juge au débiteur condamné au paiement d\'une somme d\'argent, sur le fondement de l\'article 1343-5 du code civil (ancien 1244-1 du code civil) ou en application des textes sur les expulsions, il y a lieu de préciser :

> **-la** [nature du délai]{.underline} (soit un fractionnement du paiement soit un report de paiement),
>
> **-la** [durée accordée,]{.underline}
>
> **-**[la périodicité des paiements en cas de fractionnement et,]{.underline} même si elle n\'est pas impérative mais utile pour éviter que le créancier ne doive à défaut attendre l\'expiration totale du délai pour se prévaloir de l\'exigibilité de la totalité de sa créance en cas de non-paiement d\'une ou plusieurs échéances, une [clause de]{.underline} [déchéance du terme]{.underline}, outre le rappel éventuel de certains textes et notamment de l\'article 1343-5 al 4 du
>
> ^77^ La formule tendant à dire qu'il « lui sera référé de toutes difficultés » est à cet égard insuffisamment explicite et ne permet pas de considérer que le juge s'est effectivement réservé le pouvoir de liquidation (Civ. 2^ème^, 15 janvier 2009, n° 07-20.955). Pour toutes références et précisions complémentaires sur l'astreinte, se référer à la fiche méthodologique mise en [[ligne sur le site intranet de la]{.underline}](http://intranet-cassation.justice.fr/rpvjcc/Methodologie/recommandation_civil/fiche_astreinte_201411.html) [[Cour de cassation, mise à jour en novembre 2014.]{.underline}](http://intranet-cassation.justice.fr/rpvjcc/Methodologie/recommandation_civil/fiche_astreinte_201411.html)
>
> code civil (ancien 1244-2 du code civil) prévoyant, sur la durée de la suspension ou du report, une suspension des voies d\'exécution qui auraient été engagées contre le débiteur et des majorations de retard.
>
> Ainsi, une condamnation assortie de délais de paiement au profit du débiteur peut être rédigée comme suit au dispositif de la décision : *« Condamne X (débiteur de l\'obligation) au paiement de la somme de... avec intérêts au taux de... à compter du... ; [Dit que X pourra se libérer de ladite somme]{.underline} [par mensualités de]{.underline} (montant de la mensualité, étant précisé que toute autre périodicité est envisageable) [payables le X de]{.underline} chaque mois à compter du mois suivant la signification de la présente [décision]{.underline} (les délais de paiement peuvent courir à compter de la décision si elle est contradictoire et à défaut à compter de sa signification) ; [Dit qu\'à défaut de paiement d\'une seule échéance à sa date et]{.underline} [quinze jours après mise en demeure restée]{.underline} [infructueuse,]{.underline} la totalité de la somme restant due sera [immédiatement exigible]{.underline} (clause de déchéance du terme, facultative mais conseillée) ; Rappelle qu\'aux termes de l\'article 1343-5 al 4 du code civil ces délais suspendent les voies d\'exécution\... (rappel facultatif mais conseillé des termes de l\'article précité) »*.
>
> En cas de délais consistant non pas en un fractionnement du paiement de la dette mais en un report du paiement de celle-ci, la rédaction du dispositif peut être celle-ci : *« Condamne X (débiteur de l\'obligation) au paiement de la somme de... avec intérêts au taux de... à compter du... ; [Dit que X pourra se libérer de ladite]{.underline} [somme à l\'issue d\'un délai de deux ans (]{.underline}délai maximum prévu par l\'article 1343-5 du code civil mais que le juge peut décider d\'octroyer pour une durée plus courte) à compter de la signification de la présente décision*
>
> *; Dit qu\'à l\'expiration de ce délai, la dette sera immédiatement exigible ; Rappelle qu\'aux termes de l\'article 1343-5 al 4 du code civil ces délais suspendent les voies d\'exécution\... (rappel facultatif mais conseillé) ».*
>
> Cette dernière modalité consistant en un report est à privilégier lorsque le débiteur justifie avoir la perspective de percevoir un capital à une date ou sur une période déterminées, d\'un montant permettant de solder tout ou partie substantielle de la dette. Le délai accordé devra le cas échéant être fixé au regard de la date à laquelle le capital pourra être versé au débiteur.

- **Quant à la nature de la condamnation prononcée à l\'encontre de plusieurs débiteurs**, soit conjointe, soit solidaire, soit in solidum, étant précisé que :

<!-- -->

- Dans le silence de la décision et notamment du dispositif, la condamnation sera conjointe,

- Une demande de condamnation « *conjointe et solidaire »* formulée par une partie ne peut donner lieu à une condamnation en ces termes antinomiques, la condamnation étant soit conjointe (chaque débiteur ne peut être poursuivi par le créancier que pour sa part), soit solidaire (chaque débiteur solidaire peut être recherché par le créancier pour le paiement de la totalité de la créance),

- La condamnation peut éventuellement être prononcée in solidum entre plusieurs débiteurs, notamment entre co-auteurs d\'un même dommage ou entre assuré et assureur, étant précisé que si une partie sollicite une condamnation solidaire alors que seule peut-être ordonnée, au regard de la nature de la créance, une condamnation in solidum, le juge n\'est pas tenu par les termes de la demande et peut d\'office restituer l\'exacte qualification.

> **EMPLACEMENT :**
>
> Le dispositif est placé en fin de jugement et introduit par ces termes « PAR CES MOTIFS » suivis de « le tribunal, statuant\... » et de la qualification de la décision (\...publiquement ou en chambre du conseil ou
>
> publiquement après débats en chambre du conseil/ par jugement contradictoire, réputé contradictoire ou par défaut^78^ , en premier ou en dernier ressort).
>
> Ainsi, le dispositif d\'un jugement de condamnation au paiement de diverses sommes, d\'une indemnité au titre de l\'article 700 du code de procédure civile, le tout sous le bénéfice de l\'exécution provisoire et alors que le tribunal a été saisi d\'une demande préalable de révocation de l\'ordonnance de clôture, peut être ainsi rédigé :
>
> *PAR CES MOTIFS,*
>
> *Le tribunal, statuant publiquement, par jugement contradictoire et en premier ressort^79^,*
>
> *Rejette la demande de révocation de l\'ordonnance de clôture en date du... ;*
>
> *Déclare irrecevables les conclusions de X signifiées le... et déposées au greffe le\... ;*
>
> *Condamne X à payer à Y la somme de....avec intérêts au taux de...à compter du\... ; Rejette les demandes de X ;*
>
> *Condamne X à payer à Y la somme de... au titre de l\'article 700 du code de procédure civile ;*
>
> *Condamne X aux dépens de l\'instance en ceux compris le coût de l\'expertise judiciaire réalisée par... ; Ordonne l\'exécution provisoire de la présente décision.*
>
> De cet exemple simple il ressort que :

- Le dispositif est constitué d\'une phrase unique, qui trouve son sujet dans « le tribunal », ses verbes dans les dispositions successives énoncées dans ce dispositif et son point final en fin de phrase, les phrases intermédiaires se terminant par un point-virgule. En cas d\'emploi du style indirect dans la motivation, les différentes sous-parties qui la composent, introduites par des « Attendu » (en début de majeure et en début de mineure du syllogisme juridique) ou par des « Que » (développements intermédiaires, au sein de la majeure puis de la mineure, et conclusion du syllogisme) ne sont qu\'une succession de subordonnées rattachées à la phrase principale que constitue le dispositif ;

- L\'ordre de présentation du dispositif est le suivant, proche de celui employé dans la motivation^80^ : 1°) les mesures d\'administration judiciaire (ex: jonction de deux instances)

> 2°) la décision sur la compétence
>
> 3°) la décision sur les autres exceptions de procédure 4°) la recevabilité de l\'action
>
> 5°) les décisions sur le fond des prétentions (mises hors de cause/condamnations/décisions de rejet)
>
> ^78^ Étant rappelé, qu\'à la différence du jugement pénal, la qualification est unique pour l\'ensemble des parties à l\'instance même si leurs voies de recours peuvent différer spécialement en cas de jugement par défaut, susceptible d\'opposition par le seul défaillant en application de l\'article 571 du CPC.
>
> ^79^ Ou autre qualification, en fonction du régime de publicité applicable à la nature de l\'affaire, de la comparution ou non des parties, des modes de délivrance de l\'assignation à l\'égard des défaillants cf art. 467, 468, 473 et 474 du CPC, et du ressort cf art. 34 et s., 473 et 474 du CPC, sachant que le tribunal peut parfois statuer en 1^er^ ressort sur un chef de prétention et en dernier ressort sur un autre, précision que le cas échéant devra comporter le dispositif.
>
> ^80^ Avec une réserve concernant l\'ordre d\'examen des dépens et de l\'indemnité de l\'article 700 du CPC : dans la motivation, il peut être préférable, pour respecter la logique des textes, d\'aborder les dépens avant l\'indemnité et, dans le dispositif, d\'inverser cet ordre pour statuer sur toutes les demandes des parties, y compris l\'indemnité, avant de statuer sur les dépens, sur le sort desquels le juge doit nécessairement se prononcer même sans demande spécifique des parties.
>
> 6°) les décisions sur les mesures accessoires (indemnité au titre de l\'article 700 du CPC/ dépens/ exécution provisoire).
>
> **STYLE ET TEMPS**
>
> Le dispositif se rédige logiquement au présent et conduit le juge à employer des verbes qui tranchent chacune des questions qui lui sont soumises, plus rarement des verbes de l\'ordre du constat (constater une caducité de la promesse de vente) ou du rappel (notamment pour rappeler une diligence qui sera effectuée à la suite du prononcé de la décision, telle une mention de la décision en marge de l\'acte d\'état civil ou une publicité) ou une mesure applicable de plein droit (ainsi d\'une exécution provisoire de plein droit en raison de la nature de l\'affaire).
>
> Le choix des termes et spécialement des verbes est important en ce qu\'il conditionne la bonne exécution du jugement.

###### *PRECISIONS SUR LES MESURES ACCESSOIRES*

> Dans la partie motivation, il est possible de statuer sur les mesures accessoires dans lesquelles on intègre les dépens, les frais irrépétibles de l\'article 700 du code de procédure civile ainsi que l\'exécution provisoire. Mais cela n\'est pas obligatoire, dès lors que le juge statue discrétionnairement sur ceux-ci, qu\'il n\'a donc ni à motiver spécialement sa décision de ce chef (sauf pour les dépens, lorsque le juge entend les mettre à la charge d\'une partie gagnante, art. 696 CPC) ni à répondre aux moyens que les parties pourraient soutenir sur ces demandes.
>
> Si néanmoins il est fait choix de présenter ces dispositions dans la motivation (ce qui, au stade notamment de l\'apprentissage de la méthodologie de rédaction du jugement civil, peut être préférable pour bien assimiler la logique des textes applicables à ces mesures et ne pas omettre d\'y statuer), elles sont à évoquer en toute fin de motivation dans cet ordre :
>
> -le sort des dépens,
>
> -les demandes au titre de l\'article 700 du code de procédure civile
>
> -l\'exécution provisoire.
>
> Dans le dispositif, l\'ordre peut être le même que celui suggéré pour la motivation mais aussi celui-ci (fréquemment rencontré en juridiction pour les raisons évoquées précédemment ; cf note bas de page n°11) :
>
> -Les demandes au titre de l\'article 700 du code de procédure civile
>
> -Le sort des dépens,
>
> -L\'exécution provisoire.
>
> Reprenons chacune de ces mesures accessoires.
>
> **[Les dépens]{.underline}**
>
> [Le texte]{.underline} : l\'article 696 du code de procédure civile prescrit que la partie perdante est condamnée aux dépens, à moins que le juge, par décision motivée, n\'en mette la totalité ou une fraction à la charge d\'une autre partie. Les conditions dans lesquelles il peut être mis à la charge d\'une partie qui bénéficie de l\'aide juridictionnelle tout ou partie des dépens de l\'instance sont fixées par les dispositions de la [[loi n° 91-647 du]{.underline}](http://www.legifrance.gouv.fr/affichTexte.do%3Bjsessionid%3DE7D4B5FEB92B25E0C7D0373A74748C4B.tpdjo09v_3%26dateTexte%3D?cidTexte=JORFTEXT000000537611&categorieLien=cid) [[10 juillet 1991](http://www.legifrance.gouv.fr/affichTexte.do%3Bjsessionid%3DE7D4B5FEB92B25E0C7D0373A74748C4B.tpdjo09v_3%26dateTexte%3D?cidTexte=JORFTEXT000000537611&categorieLien=cid)]{.underline} [e](http://www.legifrance.gouv.fr/affichTexte.do%3Bjsessionid%3DE7D4B5FEB92B25E0C7D0373A74748C4B.tpdjo09v_3%26dateTexte%3D?cidTexte=JORFTEXT000000537611&categorieLien=cid)t du [[décret n° 91-1266 du 19 décembre 1991]{.underline}.](http://www.legifrance.gouv.fr/affichTexte.do%3Bjsessionid%3DE7D4B5FEB92B25E0C7D0373A74748C4B.tpdjo09v_3%26dateTexte%3D?cidTexte=JORFTEXT000000721124&categorieLien=cid)
>
> [L\'application de ce texte :]{.underline} ce n\'est qu\'à défaut de condamner la partie perdante que le juge devra motiver sa décision.
>
> Dans les autres cas, il répartit comme il le souhaite ces frais mais, en cas de partage de leur charge entre plusieurs parties, il doit indiquer à proportion de combien chaque partie sera condamnée (soit à proportion par exemple de moitié ou du tiers chacune, si elles sont deux ou trois à les supporter, soit par type de dépens).
>
> Dans le cas où la partie gagnante (Y) serait bénéficiaire de l\'aide juridictionnelle et la partie condamnée (X) non bénéficiaire, il est possible de préciser :
>
> *« Condamne X aux dépens, lesquels seront recouvrés conformément à la loi sur l\'aide juridictionnelle ».*
>
> Il est toutefois proscrit de dire « Fait masse des dépens » ou « Laisse à la charge de chacune des parties les dépens par elle engagés », lorsque l'une des parties est bénéficiaire de l'aide juridictionnelle car cette formulation empêche le recouvrement de la part avancée par l'Etat au titre de cette aide juridictionnelle^81^.
>
> ^81^ Sur cette question des dépens et sur les formules à privilégier, cf la note de Monsieur Michel Defix réservée à cette question et disponible sur le site intranet de l'ENM « documentation pédagogique », « siège civil TGI » ou « siège civil TI », « accès à la documentation», « ressources pédagogiques », « fascicules », les dépens.
>
> Dans les procédures écrites, les avocats peuvent demander à bénéficier du droit de recouvrement direct des dépens lequel renvoie aux dispositions de l\'article 699 du code de procédure civile et leur permet de recouvrer directement, contre la partie condamnée aux dépens, ceux dont ils ont fait l\'avance sans avoir reçu provision. Il faut être vigilant car :

- Il convient de répondre à cette demande quand elle est formulée

- Il n\'est cependant possible d\'y faire droit que dans les procédures avec ministère d\'avocat obligatoire.

> Aussi, si une demande de condamnation aux dépens de telle partie est sollicitée par telle autre avec droit de recouvrement direct au profit de tel avocat, le juge fait droit à cette demande si la procédure est une procédure avec ministère d\'avocat obligatoire et ce, en ces termes *« Condamne X aux dépens qui seront recouvrés par Maître... conformément aux dispositions de l'article 699 du code de procédure civile »*.
>
> En tout état de cause, le principe est que le juge statue nécessairement sur le sort des dépens de l\'instance, quand bien même les parties n\'auraient rien sollicité à cet égard. A ce principe, il est deux réserves.
>
> Lorsque la décision ne met pas fin à l\'instance (ex : décision ordonnant une mesure d\'instruction avant dire droit sur la décision du même tribunal à intervenir au fond, décision d\'incompétence au profit de telle autre juridiction), le juge doit réserver les dépens. En référé, une erreur est fréquemment commise, tendant pour le juge des référés à dire que *« les dépens de l\'instance suivront le sort des dépens de l\'instance au fond »*. Or, disant cela, le juge ne décide pas du sort des dépens de l\'instance de référé, pourtant distincte de l\'instance au fond, et anticipe au surplus sur une telle instance au fond qui peut-être ne sera pas engagée par les parties. Le juge des référés doit, en conséquence, statuer sur les dépens de l\'instance en référé.
>
> De plus, il est quelques rares matières où un texte spécifique prévoit que le juge statue « sans forme ni frais » (ex :contentieux douanier). En ces cas, il est préférable de le rappeler au dispositif de la décision: *« Rappelle qu\'il est statué sans frais »*.
>
> Les dépens de l\'instance sont limitativement énumérés à l\'article 695 du code de procédure civile. Aussi, il n\'y a pas lieu pour le juge de détailler la composition des dépens dans sa décision puisque la seule condamnation aux dépens de l\'instance et la seule référence à cet article permettra ensuite de déterminer, au stade de l\'exécution, quels frais y sont inclus.
>
> Il peut toutefois être précieux pour l\'exécution de la décision de préciser, en cas d\'expertise judiciaire ou de demande expresse d\'une partie tendant à dire que le coût de tel acte doit être inclus dans les dépens :
>
> *« Condamne X aux dépens en ceux compris le coût de l\'expertise judiciaire » ou (en cas d\'opposition à injonction de payer) « \... en ceux compris les frais de la procédure d\'injonction de payer » ou (en cas d\'action en constatation de la résiliation de plein droit d\'un bail d\'habitation) « \... en ceux compris le coût du commandement préalable de payer délivré le\...*^82^ *».*
>
> *^82^ Il est toutefois à noter que le coût de certains actes, notamment celui d\'une sommation de payer délivrée à la requête du créancier avant l\'introduction de l\'instance donc sans titre exécutoire et dont l\'accomplissement n\'est pas prévu par la loi, reste à la charge de ce dernier en application de l\'article L. 111-8 du code des procédures civiles d\'exécution. Ce coût, non inclus dans les dépens, doit faire l\'objet d\'une demande d\'indemnité au titre de l\'article 700 du code de procédure civile.*
>
> **Les frais irrépétibles**
>
> [Le texte]{.underline} : il est rappelé à l\'article 700 du code de procédure civile que « le juge condamne la partie tenue aux dépens ou qui perd son procès à payer 1°) à l\'autre partie la somme qu\'il détermine, au titre des frais exposés et non compris dans les dépens 2°) et, le cas échéant, à l'avocat du bénéficiaire de l'aide juridictionnelle partielle ou totale une somme au titre des frais, non compris dans les dépens, que le bénéficiaire aurait exposés s'il n'avait pas eu cette aide. Dans ce cas, il est procédé comme il est dit aux alinéas 3 et 4 de l'article 37 de la loi n° 91-647 du 10 juillet 1991.
>
> Dans tous les cas, le juge tient compte de l\'équité ou de la situation économique de la partie condamnée. Il peut, même d\'office, pour des raisons tirées des mêmes considérations, dire qu\'il n\'y a pas lieu à ces condamnations. Néanmoins, s'il alloue une somme au titre du 2° du présent article, celle-ci ne peut être inférieure à la part contributive de l'Etat ».
>
> [L\'application de ce texte]{.underline} : dès lors qu\'une partie sollicite une indemnité au titre de l\'article 700 du code de procédure civile, le juge n\'a pas d\'autre choix que de faire application de ces dispositions, que ce soit pour accueillir la demande ou la rejeter. Aussi, il est juridiquement inexact de dire « dit n\'y avoir lieu à application de l'article 700 du Code de procédure civile ».
>
> A l\'inverse, le juge ne pourrait d\'office accorder une indemnité au titre de cet article à une partie, si cette dernière ne formulait pas une telle prétention^83^.
>
> Le juge peut accorder une indemnité au titre de l\'article 700 du code de procédure civile y compris dans les quelques rares contentieux où il statue sans forme ni frais^84^.
>
> Une lecture attentive de l\'article permet de rappeler que :
>
> -par principe, la partie condamnée aux dépens ou qui succombe (sur une ou plusieurs de ses prétentions) pourra être condamnée au paiement d'une indemnité
>
> -le juge fait appel à l\'équité lorsqu'il fixe le montant de cette indemnité ou lorsqu\'il rejette la demande formulée sur ces dispositions.
>
> [La rédaction pourra être celle-ci]{.underline} :
>
> *En cas de condamnation à une indemnité*
>
> *Dans les motifs : « M. X, qui succombe en ses prétentions, sera condamné aux dépens outre à verser à Y une somme au titre de l\'article 700 du code de procédure civile, que l\'équité commande de fixer à\... » ou « X, condamné aux dépens, devra payer à Y une somme au titre de l\'article 700 1° du code de procédure civile, que l\'équité commande de fixer à\... »*
>
> *Dans le dispositif : « Condamne X à verser à Y une somme de... au titre de l\'article 700 du code de procédure civile »*
>
> *En cas de rejet de la demande d\'indemnité*
>
> *Dans les motifs : « L\'équité commande de rejeter la demande d\'indemnité au titre des frais irrépétibles » Dans le dispositif « Rejette la demande d\'indemnité formulée au titre de l\'article 700 du code de procédure civile » ou « Dit n\'y avoir lieu à indemnité au titre de l\'article 700 du code de procédure civile »*
>
> L\'indemnité au bénéfice de l'adversaire de la partie perdante peut, si cette partie perdante n'est pas bénéficiaire de l'aide juridictionnelle, se cumuler avec une indemnité au bénéfice de l'avocat du bénéficiaire de l'aide juridictionnelle partielle ou totale au titre des frais, non compris dans les dépens, que ce bénéficiaire aurait exposés s'il n'avait pas eu cette aide.
>
> ^83^ Il est à noter que la demande d\'indemnité au titre de l\'article 700 du CPC ne constitue pas une demande incidente au sens de l\'article 68 du CPC, de sorte qu\'elle peut notamment être formulée oralement par une partie à une audience à laquelle ne comparaît pas la partie adverse ; elle sera pour autant recevable (en ce sens, Ch. mixte, 13 mars 2009, pourvoi n° 07-17670).
>
> ^84^ En ce sens, Civ. 2, 6 mars 2003, pourvoi n° 02-60835*.*
>
> Cette demande d'indemnité peut être sollicitée sur le fondement de l'article 700 2° du code de procédure civile, dans sa rédaction issue du décret n° 2013-1280 du 29 décembre 2013, qui tend à favoriser la connaissance du dispositif de l'article 37 de la loi n° 91-647 du 10 juillet 1991 et à systématiser l'application de ce dispositif lorsque la partie qui succombe n'est pas bénéficiaire de l'aide juridictionnelle. Il appartient le cas échéant à l'avocat de demander au juge cette indemnité de l'article 700 2° du code de procédure civile en justifiant de sa demande et en précisant le montant de la part contributive de l'Etat, qui constitue le montant minimum de l'indemnité qui sera allouée. Le juge garde toutefois un pouvoir d'appréciation puisqu'en application de l'alinéa 2^ème^ de l'article 700 du code de procédure civile il « tient compte de l'équité ou de la situation économique de la partie perdante (et) peut, même d'office, pour des raisons tirées des mêmes considérations, dire n'y avoir lieu à cette condamnation ».
>
> En application des alinéas 3 et 4 de l'article 37 de la loi n° 91-647 du 10 juillet 1991, si l'avocat du bénéficiaire de l'aide recouvre cette somme, il renonce à percevoir la part contributive de l'Etat. S'il n'en recouvre qu'une partie, la somme recouvrée vient en déduction de la part contributive de l'Etat. Si, à l'issue du délai de douze mois à compter du jour où la décision est passée en force de chose jugée, l'avocat n'a pas demandé le versement de tout ou partie de la part contributive de l'Etat, il est réputé avoir renoncé à celle-ci.
>
> En cas de condamnation au titre de l'article 700 2° du code de procédure civile et de l'article 37 de la loi du 10 juillet 1991, il sera énoncé au dispositif de la décision :
>
> *« Condamne Y à payer à Maître\..., avocat de X bénéficiaire de l\'aide juridictionnelle, la somme de z en application de l\'article 700 2° du code de procédure civile ;*
>
> *Rappelle qu'en application de l'article 37 de la loi du 10 juillet 1991, Maître\... dispose d'un délai de 12 mois à compter du jour où la présente décision est passée en force de chose jugée pour demander le versement de tout ou partie de la part contributive de l'Etat et qu'à défaut il est réputé avoir renoncé à celle-ci ».*
>
> **L\'exécution provisoire**
>
> [Le texte]{.underline} : aux termes de l\'article 515 du code de procédure civile, hors les cas où elle est de droit, l\'exécution provisoire peut être ordonnée, à la demande des parties ou d\'office, chaque fois que le juge l\'estime nécessaire et compatible avec la nature de l\'affaire, à condition qu\'elle ne soit pas interdite par la loi. Elle peut être ordonnée pour tout ou partie de la condamnation.
>
> [L\'application de ce texte]{.underline} :
>
> Saisi d\'une demande d\'exécution provisoire ou désireux de la prononcer d\'office, le juge doit s\'assurer qu\'aucune disposition légale particulière ne l\'interdit dans le cas d\'espèce (ainsi, une disposition d\'un jugement de divorce condamnant un époux au versement d\'une prestation compensatoire au profit de l\'autre ne peut être en principe assortie d\'une telle exécution provisoire).
>
> Hors ce cas, le juge vérifie qu\'elle est nécessaire et compatible avec la nature de l\'affaire. Lorsque le juge entend s\'expliquer dans sa motivation (ce qu\'il n\'est pas contraint de faire, exerçant en cela un pouvoir discrétionnaire) sur le prononcé de l\'exécution provisoire, il peut notamment relever l\'ancienneté de la créance, objet de la condamnation qui sera donc assortie de cette exécution provisoire. Le dispositif sera ainsi rédigé :
>
> *« Ordonne l\'exécution provisoire de la présente décision » (auquel cas, l\'exécution provisoire portera sur toutes les dispositions énoncées plus haut dans le dispositif)* ou
>
> *« Ordonne l\'exécution provisoire de la condamnation au paiement de la somme de Z à hauteur de*
>
> *50.000 euros » ou « \... à hauteur des deux tiers de ladite somme en principal » (ou en toute autre proportion)*
>
> L\'exécution provisoire est parfois de plein droit en vertu de textes particuliers (ex : art. 514 CPC pour les ordonnances de référé notamment ; art. 1074-1 CPC pour certaines dispositions en matière familiale). Auquel cas, il est préférable en fin de dispositif de préciser :
>
> *« Rappelle que l\'exécution provisoire est de plein droit ».*
>
> **RECOMMANDATIONS**
>
> Cette partie du jugement étant le siège de l\'exécution, il est essentiel de procéder, après sa rédaction, à sa relecture complète au regard :

- De l\'en-tête de la décision préparé par le greffe, pour s\'assurer notamment que la qualification de la décision mentionnée en en-tête est celle rappelée au dispositif, de même pour l\'identité des parties

- De l\'exposé des prétentions et des moyens, pour s\'assurer qu\'il est répondu au dispositif à chacune des prétentions des parties (sauf celles devenues sans objet, à raison de la réponse à l\'une ou l\'autre des prétentions principales ou à telle exception de procédure ou à telle fin de non-recevoir)

- De la motivation, pour s\'assurer qu\'à chacune des dispositions de la dernière partie du jugement (sous réserve des mesures accessoires) correspondent un ou plusieurs syllogismes dans la motivation et que les conclusions de ces syllogismes sont en concordance avec les termes du dispositif.

# FICHE IX : LA FORME ET LE STYLE DES JUGEMENTS

> Le code de procédure civile donne peu d\'indications quant à la forme que doit prendre une décision. Il se borne en effet à disposer, en son article 455, que le jugement (entendu en son sens le plus large) doit exposer succinctement les prétentions respectives des parties et leurs moyens, qu\'il doit être motivé et énoncer la décision sous forme de dispositif. Encore l\'exposé peut-il revêtir la forme d\'un simple visa des conclusions des parties, avec l\'indication de leur date.
>
> Toute latitude étant ainsi laissée au rédacteur pour formaliser sa décision, il en résulte que les jugements peuvent adopter des présentations variables.
>
> Une circulaire du ministre de la Justice, déjà ancienne puisque datée du 31 janvier 1977, est venue apporter quelques recommandations, en préconisant notamment l\'abandon du style indirect dans l\'exposé du litige, mais sa force contraignante est relative. Elle rappelle en effet que chaque juridiction demeure libre de maintenir les « attendus » dans toutes les parties de la décision ou, à l\'inverse, de les éliminer en totalité^85^.
>
> Plus récemment, la Cour de cassation a diffusé un manuel de « Normes de saisie » relatif à la présentation des arrêts, dont la plupart des préconisations peuvent être transposées aux autres décisions de justice rendues en matière civile et auquel il est renvoyé pour davantage de précisions^86^.
>
> Enfin, un groupe de travail sur la méthodologie des décisions civiles constitué au tribunal de grande instance de Paris a procédé, courant 2012-2013, à l'analyse d'une centaine de décisions, dont les résultats ont permis de dégager des critères de lisibilité, de clarté et de bonne compréhension du jugement civil et nourri la réflexion menée pour la rédaction des présentes fiches méthodologiques.
>
> Mais c\'est le plus souvent dans l\'usage et les exemples tirés des précédents, dans l'emploi de trames, que le rédacteur trouve ses modèles, avec le risque inhérent, qui tient à la reproduction des impropriétés.

### A -- LE CHOIX DU STYLE DIRECT OU INDIRECT

> Les jugements entièrement rédigés en style indirect ayant pratiquement disparu, on peut principalement distinguer deux sortes de décisions rendues en matière civile : celles intégralement rédigées au style direct et celles adoptant la présentation dite « mixte », mêlant style direct, retenu pour l\'exposé du litige, et indirect, maintenu pour les motifs. Le rédacteur qui opte pour le style indirect doit alors respecter les contraintes résultant de son choix et veiller à ne pas mêler les deux formes rédactionnelles.
>
> **Le style direct.** La présentation en style direct appelle peu de commentaires puisqu\'il s\'agit d\'une rédaction usuelle, composée d\'une suite de phrases séparées par un point, dont la dernière commence par l\'expression « *Par ces motifs* », que la circulaire précitée recommande d\'écrire en lettres capitales, suivie du sujet (*le tribunal, le juge* ou *la cour*) puis d\'une proposition subordonnée comportant la qualification de la décision (*statuant publiquement, contradictoirement, en premier/dernier ressort)* et des différents verbes par lesquels la juridiction tranche le litige (*déclare, ordonne, dit que, condamne*, *etc.*), qui introduisent autant de propositions principales, et se termine par un point.
>
> ^85^ Circulaire du 31 janvier 1977 relative à la présentation des jugements -- Journal officiel du 11 février 1977 p. 886.
>
> ^86^ Service de documentation, des études et du rapport de la Cour de cassation - « Normes de saisie de la Cour de cassation ».
>
> Ex :
>
> *L\'article X dispose que\... .*
>
> *En l\'espèce, il est constant que\... . Il ressort des pièces produites aux débats spécialement de\... que... . En conséquence,\... .*
>
> *PAR CES MOTIFS,*
>
> *Le tribunal, statuant publiquement, par jugement contradictoire et en premier ressort : Condamne\...*
>
> *Dit que\... Rejette\...*
>
> *Condamne... aux dépens.*
>
> **Le style indirect**. La rédaction dite « mixte », où seul l\'exposé du litige est rédigé en style direct, alors que le reste du jugement est présenté en style indirect, est plus exigeante puisque, réserve faite de l\'exposé du litige, le jugement ne comportera qu\'une seule phrase qui commence avec la première locution « *Attendu que...* » et qui se termine par le point suivant le dernier mot du dispositif.
>
> Dans cette présentation, la motivation du jugement est composée d\'une suite de propositions subordonnées commençant toutes par « *Attendu que...* », si elles introduisent une étape du raisonnement, ou par « *que...* », si elles viennent en complément de l\'idée précédemment introduite, et séparées par un point-virgule (lui-même précédé d\'une espace fine^87^, selon les règles typographiques), puisqu\'il s\'agit d\'une phrase unique. Aussi, la majeure du syllogisme puis la mineure sont logiquement introduites par « *Attendu que...* », tandis que la conclusion du syllogisme peut être introduite soit par « *Attendu que...* » soit par « *que... ».*
>
> Ex :
>
> *Attendu que l\'article X dispose que\... ; Attendu en l\'espèce que\... ; que\... ; que\... ; Qu'en conséquence,\... ;*
>
> *PAR CES MOTIFS,*
>
> *Le tribunal, statuant publiquement, par jugement contradictoire et en premier ressort : Condamne\...*
>
> *Dit que\... Rejette\...*
>
> *Condamne... aux dépens.*
>
> Dire que la motivation et le dispositif du jugement ne comportent qu\'une seule phrase emporte plusieurs conséquences.
>
> Tout d\'abord, il y a lieu de bannir toute incise qui serait rédigée en style direct et qui viendrait briser la phrase unique, les propositions subordonnées précédant cette incise étant alors dépourvues de proposition principale. Le rédacteur devra donc veiller à introduire toutes ses propositions subordonnées par la conjonction « *que*... ».
>
> Ensuite, rien n\'interdit (et il est même recommandé) d\'introduire, dans la motivation, des sous-titres, qui correspondent par exemple aux différentes prétentions, à la condition toutefois qu\'ils soient eux-mêmes rédigés sous la forme de propositions subordonnées.
>
> Ex :
>
> *Sur la fin de non-recevoir : Sur le moyen pris de... :*
>
> *^87^* L\'espace fine insécable s\'obtient en appuyant simultanément sur les touches Ctrl+Maj+barre d\'espace sous OpenOffice® et Word® et Ctrl+barre d\'espace sous Wordperfect®.
>
> *Sur la demande de dommages-intérêts :*
>
> Enfin, aucun point, autre que le point final, ne doit apparaître entre le premier « *Attendu que...* » et le dernier mot du dispositif, les seuls signes de ponctuation utilisables alors étant la virgule, le point-virgule et les deux points.
>
> **Recommandations sur le choix du style direct ou indirect**
>
> Si, pour un professionnel du droit, le style indirect, autant que le style direct, peut parfaitement restituer la pertinence du raisonnement tenu par le rédacteur de la décision, pour le non juriste à l'inverse le style indirect est un style moins directement accessible.
>
> Aussi, dans les contentieux où le ministère d'avocat n'est pas obligatoire (assistance éducative, affaires familiales notamment), les motivations des décisions sont très largement rédigées en style direct de sorte que les parties, même non assistées d'un avocat, peuvent aisément en faire la lecture.
>
> Même dans les autres contentieux à ministère d'avocat obligatoire, spécialement en première instance, il convient de veiller à rendre sa décision compréhensible y compris par le justiciable en personne, ce qui participe de l'acceptation de cette décision et du sentiment pour la partie d'avoir été entendue à défaut d'avoir été suivie en sa demande. A la complexité de nombre de questions juridiques traitées dans la motivation, il convient en effet de ne pas ajouter d'autres obstacles de forme et le choix du style indirect peut en être un.
>
> Du point de vue du rédacteur, le style indirect peut a priori être séduisant et paraître source de rigueur en ce que le raisonnement y est scandé par la succession de propositions subordonnées introduites par les « Attendu » ou par les « Que » (« Attendu qu'en application de (tel) article... » pour la majeure, « Attendu qu'en l'espèce... » pour la mineure, « Qu'en conséquence... » pour la conclusion).
>
> Toutefois, en style direct, il suffit de marquer très simplement les étapes principales de la motivation par les mêmes termes « En application de (tel) article » (majeure), « En l'espèce » (mineure) et « En conséquence » (conclusion), non précédés des « Attendu » ni des « Que », et les étapes intermédiaires par l'emploi de mots de liaison adaptés (« Aussi », « Cependant », « En effet »...). En définitive, le raisonnement s'y construit tout aussi aisément et sa logique est tout aussi bien restituée.
>
> Enfin, le style direct peut faciliter l'emploi de phrases plus courtes. Or, la concision des phrases comme des développements de la motivation est un critère supplémentaire de lisibilité de la décision.
>
> Aussi, en tous types de contentieux, le style direct devra être adopté car il libère le rédacteur de la motivation des contraintes précitées de ponctuation et de construction des phrases, propres au style indirect, et contribue par ailleurs, comme indiqué ci-dessus, à faciliter la lecture de la décision, donc sa compréhension directe par le justiciable, laquelle est un critère de sa qualité.

### B -- LE CHOIX DU VOCABULAIRE

> Le même souci de clarté de la décision conduit à s'interroger sur le choix du vocabulaire par le juge rédacteur et sur l'emploi ou non de locutions latines.
>
> Ainsi, sans renoncer aux exigences d'exactitude et de précision du vocabulaire juridique, il convient d'éviter l'emploi de termes désuets, par exemple : *« il échet* », *« il appert* », et de préférer aux locutions
>
> latines la traduction en Français au risque, à défaut, de priver un peu plus le justiciable de la possibilité d'accéder au sens de la motivation^88^.
>
> De plus, le vocabulaire ne doit traduire ni l'indignation, ni l'agacement du juge à l'égard d'un justiciable. La mauvaise foi, l'entêtement, le comportement désagréable d'une partie à l'audience ne justifient pas l'emploi dans la décision de justificatifs ni d'adjectifs injurieux ou excessifs. C'est une condition essentielle de sérénité de la justice et d'objectivité du juge qui, à défaut, ne ferait qu'une « apparence de motivation de nature à faire peser un doute sur l'impartialité de la juridiction »^89^. Les termes familiers sont par ailleurs à proscrire.
>
> Enfin, l'usage d'un terme très technique peut utilement être précédé de sa définition ceci, afin de lever toute ambiguïté.

### C- L'ADOPTION D'UN PLAN DE MOTIVATION APPARENT

> Au nombre des critères de lisibilité et de compréhension d'une décision figurent en bonne place^90^ les exigences de clarté, de structuration et de présentation aérée et par paragraphes ou numérotation.
>
> Pour ne pas perdre son lecteur et se faire comprendre du justiciable, du conseil de ce dernier comme de la juridiction supérieure susceptible de connaître du jugement à l'occasion d'un recours, le juge doit avoir le souci d'une présentation de la motivation qui soit organisée et qui rende visibles les différentes étapes du raisonnement et les éléments de structuration.
>
> Aussi, à l'exception de dossiers simples, où seul un chef de prétention est soumis au tribunal, ou des décisions, où le juge fera droit à une exception de procédure ou une fin de non-recevoir sans avoir à analyser les autres questions juridiques, il est important d'organiser la motivation autour d'un plan détaillé et de restituer ce plan par des sous-titres, éventuellement numérotés ou précédés de lettres.
>
> Ex : **I / Sur la demande principale**

A.  Sur la qualification de contrat

B.  Sur l'inexécution contractuelle

C.  Sur la sanction de cette inexécution

> **II/ Sur la demande reconventionnelle III -- Sur les mesures accessoires**
>
> A l'intérieur des différentes sous-parties, si le raisonnement nécessite des développements importants, il est préférable d'adopter une présentation aérée, marquée par des paragraphes correspondant aux différentes étapes du raisonnement.
>
> ^88^ Déjà dans une Conférence prononcée le 25 octobre 1979 à la 145 session de formation permanente des magistrats, sur la formulation des décisions de justice, Raymond LINDON, premier avocat général honoraire à la Cour de cassation, soulignait le nécessaire souci de clarté et faisait observer que « la meilleure référence était le code civil » dont les rédacteurs n'avaient jamais parlé de servitude « non edificandi », ni du « de cujus » mais du défunt » (« La formation et la formulation des décisions de justice », Association d'Etudes et de Recherches, p. 259).
>
> ^89^ En ce sens, Civ.1, 17 mars 2011, n° 10-10583, arrêt précité dans la fiche V « Motivation » - A.
>
> ^90^ En ce sens, les résultats de l'analyse d'une centaine de décisions civiles menée en 2012-2013 par le groupe de travail constitué au sein du tribunal de grande instance de Paris.
>
> Pour plus de précisions et pour des illustrations sur les règles d'ordonnancement des questions juridiques et sur les méthodes d'élaboration d'un plan détaillé et apparent, il est renvoyé à la fiche méthodologique VI (Le processus d'analyse et de raisonnement) spécialement en sa partie C.
>
> Le choix rédactionnel étant fait, il convient encore de veiller à la qualité de la présentation de la décision, son exactitude formelle contribuant à l\'autorité du jugement. S\'il est inutile d\'insister sur le respect des règles orthographiques, il peut en revanche être opportun de rappeler quelques règles de saisie et de typographie.

### D -- LE RESPECT DES RÈGLES DE SAISIE ET DE TYPOGRAPHIE

> Ainsi, s\'agissant de la désignation des parties, le nom patronymique des personnes physiques doit être précédé d\'une civilité^91^ (et de leur prénom, s\'il existe un risque de confusion entre plusieurs parties à l\'instance, comme ce peut être le cas en matière d\'indivision successorale). Les particules sont toujours écrites en minuscules.
>
> Ex :
>
> *M. Dupont (et non Mr Dupont, Mr étant l\'abréviation du mot anglais « Mister ») MM. Pierre et Jean Martin*
>
> *Mme Dupont Vve Martin*
>
> *M. de La Chapelle*
>
> S\'agissant des défunts et des personnes mineures, la règle impose de les désigner par leur prénom suivi de leur nom, sans civilité.
>
> *Ex : Jules Durand*
>
> La Cour de cassation recommande d\'écrire les noms et prénoms des parties en caractères minuscules, avec l\'initiale en capitale, mais force est de constater que l\'usage des juridictions est contraire.
>
> S\'agissant des personnes morales, il convient de les désigner sous leur raison sociale développée lors de la première mention dans le jugement (en annonçant, le cas échéant, l'abréviation qui sera utilisée dans la suite de la décision) et il est recommandé de faire de même dans le dispositif, afin de prévenir toute éventuelle difficulté d\'exécution forcée.
>
> Ex :
>
> *La société BNP Paribas (la banque)*
>
> *Le Fonds d\'indemnisation des victimes de l\'amiante (le FIVA)*
>
> Seule la première lettre de la raison sociale est écrite en majuscule, le reste l\'étant en minuscules, sauf si le premier mot de la raison sociale est un article, auquel cas le mot suivant l\'article commencera aussi par une majuscule.
>
> *Ex : La société Transports express méridionaux la société Les Chargeurs réunis*
>
> Toutefois, les sociétés anglo-saxonnes reçoivent une majuscule à chaque mot composant leur raison sociale, conformément à leur règle typographique nationale.
>
> Ex : la société American Airlines
>
> ^91^ La Cour de cassation a renoncé à la règle qu\'elle a longtemps observée et qu\'elle tirait de l\'article 18 du décret des 27 novembre et 1^er^ décembre 1790 portant institution d'un tribunal de cassation et réglant sa composition, son organisation et ses attributions, qui disposait que : « Aucune qualification ne sera donnée aux plaideurs dans l'intitulé des jugements ; On n'y inscrira que leurs noms patronymiques et de famille et celui de leurs fonctions ou de leur profession », de laquelle elle inférait que l\'on devait bannir toute civilité dans les jugements.
>
> En ce qui concerne la désignation des organismes publics, administratifs et juridictionnels, la règle veut que seuls ceux qui sont uniques reçoivent une capitale initiale, les autres devant s\'écrire en minuscules.
>
> Ex :
>
> *Le Conseil constitutionnel La Cour de cassation*
>
> *Le Conseil d\'État*
>
> *La cour d\'appel de Bastia*
>
> *Le tribunal de grande instance de Bordeaux Le juge des référés*
>
> *La caisse de sécurité sociale de l\'Isère*
>
> *La commune de Nantes le maire de Strasbourg le préfet de l\'Orne L\'académie de Reims (mais l\'Académie française)*
>
> Les nombres ordinaux reçoivent les abréviations suivantes :
>
> *Premier : 1^er^*
>
> *Deuxième : 2e (et non 2ème, ni 2ième) Second : 2nd*
>
> *Troisième 3e etc.*
>
> Les signes de ponctuation doubles ( ; : ? !) sont précédés et suivis d\'une espace, alors que les signes simples (, .) sont accolés au mot qui les précède et suivis d\'une espace. Le trait d\'union n\'est ni précédé, ni suivi d\'une espace. Les parenthèses sont accolées au mot qu\'elles renferment mais précédées et suivies d\'une espace.
>
> Il est recommandé d\'utiliser les guillemets français « \... », qui sont toujours précédés et suivis d\'une espace, les guillemets anglais \"\...\", qui sont accolés aux mots qu\'ils renferment mais sont précédés et suivis d\'une espace, pouvant être utilisés à l\'intérieur des guillemets français.
>
> *Ex : Par attestation en date du 25 février 2012, Mme Dupont déclare : « J\'ai entendu M. X dire à M. Y \"Je te retrouverai\" ».*
>
> Les nombres inférieurs à dix s\'écrivent en chiffres,^92^ bien que la Cour de cassation recommande de les écrire en lettres. Les nombres reçoivent une espace insécable entre chaque tranche de trois chiffres (sauf pour les années, la pagination d\'un ouvrage, *etc.*) La Cour de cassation recommande également de ne pas utiliser le symbole €, mais de développer l\'unité monétaire.
>
> *Ex : 1 234 567,89 1 180 euros.*
>
> Quand un article de code comporte une lettre, elle doit être suivie d\'un point, puis d\'une espace insécable et enfin du numéro de l\'article.
>
> *Ex : l\'article L. 311-7-1 du code de l\'organisation judiciaire*

### E - RAPPEL DES PRINCIPALES RECOMMANDATIONS

> Les exigences de forme, de style et de présentation, loin d'être accessoires, participent assurément de la lisibilité de la décision et de sa compréhension, de sorte que le juge ne peut s'en désintéresser et qu'elles doivent guider ses choix notamment de style, précisément de style direct ici préconisé, et de vocabulaire.
>
> ^92^ Yves Perrousseaux « Manuel de typographie française élémentaire » - 7 édition - Atelier Perrousseaux éditeur.
>
> De plus, le respect de ces exigences facilite pour le juge lui-même la relecture de sa décision avant sa signature et le repérage à cette occasion des éventuelles incohérences au sein de la motivation ou des contradictions entre les différentes parties du jugement.
>
> Enfin, s'agissant du plan de motivation détaillé et apparent de la motivation, il n'est jamais que la restitution d'une réflexion organisée et d'un raisonnement structuré que doit mener le juge en amont de la rédaction.
>
> Aussi, plus que de simples exigences de forme, elles participent en partie de la qualité même de la décision.
