# Mode Non-Comparant (art. 472 CPC)

## Déclencheur

Ce mode simplifié s'applique lorsque :
- Le défendeur a été régulièrement assigné
- Le défendeur n'a pas constitué avocat / n'a pas comparu
- Pas de demande reconventionnelle à traiter

## Principe directeur

**Article 472 CPC** : « Si le défendeur ne comparaît pas, il est néanmoins statué sur le fond. Le juge ne fait droit à la demande que dans la mesure où il l'estime régulière, recevable et bien fondée. »

→ Le juge n'est pas lié par les demandes : il doit les vérifier.

---

## Workflow simplifié - Grille unique

```
═══════════════════════════════════════════════════════════════════
GRILLE NON-COMPARANT - Art. 472 CPC
Dossier [Demandeur] c/ [Défendeur]
═══════════════════════════════════════════════════════════════════

1. RÉGULARITÉ DE L'ASSIGNATION
   ─────────────────────────────────────────────────────────────────
   □ Date de l'assignation : [date]
   □ Délai de comparution respecté : [oui/non - calcul]
   □ Mentions obligatoires présentes : [oui/non]
   □ Mode de signification : [personne / domicile / art. 659 CPC]
   
   → Qualification décision : [RÉPUTÉ CONTRADICTOIRE / PAR DÉFAUT]
   → Motivation : [cité à personne / signifié domicile + premier ressort...]

2. RECEVABILITÉ (vérifications d'office)
   ─────────────────────────────────────────────────────────────────
   □ Compétence TC : [acte de commerce / société commerciale]
   □ Qualité à agir du demandeur : [vérifiée - motif]
   □ Intérêt à agir : [vérifié - motif]
   □ Prescription : [non acquise - délai applicable / point de départ]

3. BIEN-FONDÉ - VÉRIFICATION DES DEMANDES
   ─────────────────────────────────────────────────────────────────
   
   ┌────┬─────────────────────┬────────────┬─────────────────┬─────────┐
   │ N° │ DEMANDE             │ MONTANT    │ PIÈCES          │ VALIDÉ  │
   ├────┼─────────────────────┼────────────┼─────────────────┼─────────┤
   │ D1 │ Principal           │ [X] €      │ Facture n°...   │ □ / ✅  │
   │    │                     │            │ Contrat...      │         │
   ├────┼─────────────────────┼────────────┼─────────────────┼─────────┤
   │ D2 │ Intérêts            │ Légaux /   │ Mise en demeure │ □ / ✅  │
   │    │                     │ TX [%]     │ du [date]       │         │
   ├────┼─────────────────────┼────────────┼─────────────────┼─────────┤
   │ D3 │ Clause pénale       │ [Y] €      │ CGV art. X      │ □ / ✅  │
   │    │ (indemnité)         │            │                 │         │
   └────┴─────────────────────┴────────────┴─────────────────┴─────────┘
   
   Observations :
   • [Montant conforme aux pièces / écart identifié]
   • [Calcul des intérêts vérifié / à recalculer]

4. ARTICLE 700 CPC
   ─────────────────────────────────────────────────────────────────
   □ Montant demandé : [Z] €
   □ Éléments d'appréciation : [simplicité/complexité dossier]
   □ Proposition retenue : [montant] €

═══════════════════════════════════════════════════════════════════
SYNTHÈSE - DÉCISIONS À RENDRE
═══════════════════════════════════════════════════════════════════

┌────┬─────────────────────┬────────────┬─────────────┐
│ N° │ CHEF                │ DEMANDÉ    │ RETENU      │
├────┼─────────────────────┼────────────┼─────────────┤
│  1 │ Principal           │ [X] €      │ [X] €       │
│  2 │ Intérêts légaux     │ Oui        │ Oui / Non   │
│  3 │ Clause pénale       │ [Y] €      │ [Y] €       │
│  4 │ Article 700         │ [Z] €      │ [montant] € │
│  5 │ Dépens              │ Défendeur  │ Défendeur   │
└────┴─────────────────────┴────────────┴─────────────┘

→ Validation requise avant rédaction
═══════════════════════════════════════════════════════════════════
```

---

## Formulations types

**Mention liminaire (après identification parties) :**
> La société [DÉFENDEUR], régulièrement assignée par acte d'huissier du [date], n'a pas constitué avocat.

**Motifs - structure allégée :**

```
Sur la demande en paiement :

Cadre juridique :
Aux termes de l'article 472 du Code de procédure civile, si le défendeur 
ne comparaît pas, il est néanmoins statué sur le fond ; le juge ne fait 
droit à la demande que dans la mesure où il l'estime régulière, recevable 
et bien fondée.

En l'espèce :
La créance de [montant] € résulte de la facture n°[X] en date du [date] 
(pièce n°1 du demandeur), établie conformément au contrat du [date] 
(pièce n°2). Cette facture est demeurée impayée malgré mise en demeure 
du [date] (pièce n°3).

Le tribunal retient :
La demande, régulière en la forme, recevable et justifiée par les pièces 
produites, sera accueillie.
```

---

## Attention - Pas de pièces défendeur

Ne jamais faire référence à des "pièces du défendeur". Il n'y en a pas.

---

## Checklist allégée

```
═══════════════════════════════════════════════════════════════════
✓ VÉRIFICATION NON-COMPARANT
═══════════════════════════════════════════════════════════════════
□ Assignation régulière mentionnée
□ Qualification correcte (réputé contradictoire / par défaut)
□ Art. 472 CPC visé dans les motifs
□ Aucune thèse défendeur attribuée
□ Pas de renvoi à des pièces défendeur
□ Montants conformes aux pièces demandeur
□ Dispositif = demandes vérifiées (pas d'ultra petita)
═══════════════════════════════════════════════════════════════════
```
