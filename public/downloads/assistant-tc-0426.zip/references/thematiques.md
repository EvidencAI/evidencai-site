# Thématiques fréquentes - Points de vigilance

## Table des matières
1. Cautionnement
2. Rupture brutale des relations commerciales
3. Responsabilité du dirigeant
4. Clause pénale
5. Procédure collective
6. Impayés et intérêts
7. Réformes récentes à connaître

---

## 1. Cautionnement (personne physique)

### Textes applicables

**Attention aux dates :**
- Cautionnements signés avant le 01/01/2022 : Code de la consommation (L. 332-1, L. 343-4)
- Cautionnements signés à compter du 01/01/2022 : Code civil (art. 2288 et suivants, réforme ordonnance 15/09/2021)

### Points de contrôle

| Point | Texte | Vérification |
|-------|-------|--------------|
| Formalisme | Art. 2297 C. civ. | Mention manuscrite conforme |
| Information annuelle | Art. 2302 C. civ. | Créancier a-t-il informé ? |
| Proportionnalité | Art. 2300 C. civ. | Engagement / patrimoine au moment de la signature |
| Bénéfice de discussion | Art. 2305 C. civ. | Caution simple ou solidaire ? |

### Proportionnalité - Grille d'analyse

L'engagement est disproportionné si, au moment de sa conclusion, il excède manifestement les capacités financières de la caution.

Éléments à examiner :
- Revenus de la caution
- Patrimoine (immobilier, épargne)
- Charges et endettement existant
- Montant cautionné

**Sanction** : Le créancier ne peut se prévaloir du cautionnement (art. 2300 al. 2 C. civ.)

---

## 2. Rupture brutale des relations commerciales

### Texte applicable

**Art. L. 442-1, II C. com.** (anciennement L. 442-6, I, 5°)

« Engage la responsabilité de son auteur et l'oblige à réparer le préjudice causé le fait, par toute personne exerçant des activités de production, de distribution ou de services, de rompre brutalement, même partiellement, une relation commerciale établie, en l'absence d'un préavis écrit qui tienne compte notamment de la durée de la relation commerciale. »

### Points de contrôle

| Élément | Question |
|---------|----------|
| Relation établie | Durée ? Régularité ? Intensité ? |
| Brutalité | Préavis donné ? Durée suffisante ? |
| Préjudice | Perte de marge ? Investissements perdus ? |

### Calcul du préavis

Jurisprudence indicative [À VÉRIFIER] : environ 1 mois par année de relation, avec plafonnement selon les usages du secteur.

Facteurs aggravants (préavis plus long) :
- Dépendance économique
- Investissements spécifiques réalisés
- Difficultés de reconversion

---

## 3. Responsabilité du dirigeant

### Faute de gestion (art. L. 651-2 C. com.)

**Conditions :**
1. Procédure collective ouverte
2. Insuffisance d'actif
3. Faute de gestion du dirigeant
4. Lien de causalité faute / insuffisance

**Exemples de fautes :**
- Poursuite abusive d'exploitation déficitaire
- Absence de comptabilité régulière
- Détournement d'actifs
- Non-déclaration de cessation des paiements

### Faute détachable / non détachable

| Type | Conséquence |
|------|-------------|
| Faute non détachable | Responsabilité de la société seule |
| Faute détachable | Responsabilité personnelle du dirigeant |

Critère : faute intentionnelle d'une particulière gravité incompatible avec l'exercice normal des fonctions sociales.

---

## 4. Clause pénale

### Texte applicable

**Art. 1231-5 C. civ.** (ancien art. 1152)

« Le juge peut, même d'office, modérer ou augmenter la pénalité ainsi convenue si elle est manifestement excessive ou dérisoire. »

### Pouvoir modérateur du juge

| Critère | Éléments d'appréciation |
|---------|-------------------------|
| Manifestement excessive | Disproportion flagrante avec le préjudice réel |
| Manifestement dérisoire | Pénalité symbolique sans effet dissuasif |

**Attention** : Le juge PEUT modérer d'office. Il n'y est pas obligé. La modération doit être motivée.

### Formulation type

```
Sur la clause pénale :

Cadre juridique :
Aux termes de l'article 1231-5 du Code civil, le juge peut, même d'office, 
modérer la pénalité si elle est manifestement excessive.

En l'espèce :
La clause pénale prévue à l'article X des conditions générales stipule une 
indemnité de [montant]. Le préjudice effectivement subi par le créancier 
s'établit à [montant] selon [pièces].

Le tribunal retient :
[Faire droit à l'intégralité / Modérer à hauteur de X €, la pénalité 
apparaissant manifestement excessive au regard du préjudice démontré.]
```

---

## 5. Procédure collective

### Vocabulaire obligatoire

Voir `vocabulaire-juge.md` section "Procédure collective".

### Vérifications systématiques

| Point | Question |
|-------|----------|
| Déclaration de créance | Créance déclarée dans les délais ? |
| Arrêt des poursuites | Action engagée avant ou après jugement d'ouverture ? |
| Qualité de l'organe | Mandataire ou liquidateur ? |

### Relevé de forclusion

**Art. L. 622-26 C. com.**

Conditions :
- Créancier n'a pas été avisé personnellement de l'ouverture
- Créance née régulièrement
- Demande dans les 6 mois du jugement d'ouverture

---

## 6. Impayés et intérêts

### Point de départ des intérêts

| Situation | Point de départ |
|-----------|-----------------|
| Mise en demeure | Date de la mise en demeure (art. 1231 C. civ.) |
| Assignation | Date de l'assignation si pas de mise en demeure |
| Facture avec date d'échéance | Date d'échéance (si clause contractuelle) |

### Taux applicable

| Type | Taux |
|------|------|
| Intérêt légal | Taux BCE + 10 points (entre commerçants) |
| Intérêt conventionnel | Selon contrat (vérifier l'usure) |
| Pénalités de retard B2B | Taux BCE + 10 points minimum (art. L. 441-10 C. com.) |

### Anatocisme (capitalisation)

**Art. 1343-2 C. civ.** : Les intérêts échus peuvent produire intérêt, soit par demande judiciaire, soit par convention, pourvu qu'il s'agisse d'intérêts dus au moins pour une année entière.

---

## 7. Réformes récentes à connaître

### Droit des obligations

**Ordonnance 10 février 2016** (vigueur 1er octobre 2016)
- Contrats conclus avant : ancien Code civil (art. 1134, 1147, 1382...)
- Contrats conclus après : nouveau Code civil (art. 1103, 1104, 1231...)

### Droit des sûretés

**Ordonnance 15 septembre 2021** (vigueur 1er janvier 2022)
- Refonte du cautionnement
- Nouveaux articles 2288 et suivants C. civ.

### Procédures collectives

**Ordonnance 15 septembre 2021**
- Modifications procédurales
- Classes de parties affectées

---

## Réflexes de vérification

### Avant de citer un article

1. Vérifier l'existence dans la codification actuelle
2. Attention aux réformes : quel texte applicable selon la date du contrat/fait générateur ?
3. Code de commerce : numérotation L./R./A.

### Avant de citer une jurisprudence

1. Ne jamais inventer de référence précise
2. Format acceptable : "Cass. com., [principe dégagé] - [À VÉRIFIER SUR LÉGIFRANCE]"
3. Ou : "Jurisprudence constante sur [sujet] - références à confirmer"

### Avant d'énoncer un principe

L'ancrer systématiquement dans un texte :
- Bonne foi contractuelle → art. 1104 C. civ.
- Force obligatoire → art. 1103 C. civ.
- Réparation intégrale → art. 1231-2 C. civ.
- Proportionnalité cautionnement → art. 2300 C. civ.
