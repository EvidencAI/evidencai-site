# Vocabulaire du juge - Formulations interdites et correctes

## Principe fondamental

Le juge constate, il ne commente pas. Le jugement reste factuel même face à une partie de mauvaise foi.

---

## Formulations interdites

| ❌ Formulation problématique | Pourquoi | ✅ Alternative |
|------------------------------|----------|----------------|
| « Le tribunal s'étonne » | Le juge ne s'étonne pas | « Le tribunal relève » / « constate » |
| « Le tribunal reste perplexe » | Commentaire personnel | « Le tribunal constate que » |
| « n'hésite pas à demander » | Commentaire sur l'attitude | « demande » (neutre) |
| « contre-attaque » | Vocabulaire guerrier | « soutient que » / « fait valoir » |
| « se positionne en victime » | Jugement de valeur | À supprimer |
| « n'apparaît pas très sérieux » | Appréciation morale | Supprimer ou « n'est pas justifié » |
| « tente de » | Connotation péjorative | « indique que » / « fait valoir » |
| « prétend » (péjoratif) | Connotation négative | « indique » / « expose » |
| « de mauvaise foi » | Jugement de valeur | « ne justifie pas de » |
| « manifestement abusif » | Excessif sauf art. 700 | « non fondé » / « injustifié » |
| « il est évident que » | Dispense de motivation | Motiver explicitement |
| « comme chacun sait » | Non juridique | Citer la source |

---

## Formulations correctes pour rapporter les thèses

**Pour le demandeur :**
- « expose que... »
- « fait valoir que... »
- « soutient que... »
- « indique que... »

**Pour le défendeur :**
- « réplique que... »
- « oppose que... »
- « fait valoir en défense que... »
- « conteste en indiquant que... »

---

## Pour qualifier les pièces et arguments

| Situation | Formulation |
|-----------|-------------|
| Pièce produite | « il résulte de la pièce n°X que... » |
| Pièce absente | « le demandeur ne produit aucune pièce établissant que... » |
| Argument non étayé | « cette affirmation n'est pas corroborée par les pièces versées aux débats » |
| Contradiction | « cette affirmation est contredite par la pièce n°X dont il ressort que... » |

---

## Pour les conclusions du tribunal

| Type de conclusion | Formulation |
|--------------------|-------------|
| Accueil demande | « Il y a lieu de faire droit à la demande » |
| Rejet demande | « La demande sera rejetée » / « Il convient de débouter... » |
| Accueil partiel | « La demande sera accueillie dans la limite de... » |
| Modération clause pénale | « Le tribunal, faisant usage de son pouvoir modérateur, réduit la pénalité à... » |

---

## Vocabulaire procédure collective

| ❌ À éviter | ✅ À utiliser |
|-------------|---------------|
| « Condamne X à payer à Y » | « Fixe la créance de Y au passif de X à la somme de... » |
| « Condamne aux dépens » | « Dit que les dépens seront employés en frais privilégiés de procédure collective » |
| « Condamne au titre de l'article 700 » | « Fixe au passif la somme de X € au titre de l'article 700 du CPC » |
| « Ordonne le paiement » | « Dit que la créance est admise au passif pour... » |

---

## Latinismes à utiliser avec parcimonie

| Expression | Signification | Usage |
|------------|---------------|-------|
| Ultra petita | Au-delà de ce qui est demandé | Erreur à éviter |
| Infra petita | En deçà de ce qui est demandé | Omission de statuer |
| In limine litis | Au seuil du procès | Exceptions de procédure |
| A fortiori | À plus forte raison | Raisonnement juridique |
| A contrario | Par le raisonnement inverse | Interprétation |
| Sui generis | De son propre genre | Qualification atypique |

---

## Formules dispositif

**Verbes toujours en MAJUSCULES :**
- DÉBOUTE
- CONDAMNE
- DIT
- ORDONNE
- REJETTE
- DÉCLARE
- PRONONCE
- FIXE (procédure collective)
- CONSTATE
- DONNE ACTE

**Formulation type :**
```
DÉBOUTE la société X de sa demande de [objet] ;
CONDAMNE la société Y à payer à la société X la somme de [montant] € au titre de [fondement] ;
DIT n'y avoir lieu à [mesure] ;
ORDONNE [mesure] ;
REJETTE toutes autres demandes.
```
